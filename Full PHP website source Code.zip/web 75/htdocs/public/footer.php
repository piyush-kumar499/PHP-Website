<!DOCTYPE html>
<html>
<head>
    <style>
    /* Scoped Footer Styles - Using more specific selectors to prevent conflicts */
    .ai-tools-footer {
        background: linear-gradient(to right, #242853, #384497);
        color: #ffffff;
        padding: 4rem 0;
        font-family: 'Inter', 'Arial', sans-serif;
    }

    .ai-tools-footer .footer-columns {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 2.5rem;
        max-width: 1300px;
        margin: 0 auto;
        text-align: center;
        padding: 0 1.5rem;
    }

    .ai-tools-footer .footer-column {
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .ai-tools-footer .footer-column h4 {
        font-weight: 700;
        margin-bottom: 1.5rem;
        position: relative;
        text-transform: uppercase;
        letter-spacing: 1.5px;
        font-size: 1.1rem;
    }

    .ai-tools-footer .footer-column h4::after {
        content: '';
        position: absolute;
        bottom: -0.5rem;
        left: 50%;
        transform: translateX(-50%);
        width: 40px;
        height: 3px;
        background-color: #9663ff;
    }

    .ai-tools-footer .footer-column ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .ai-tools-footer .footer-column ul li {
        margin-bottom: 0.75rem;
    }

    .ai-tools-footer .footer-column a {
        color: #f0f0f0;
        text-decoration: none;
        transition: all 0.3s ease;
        position: relative;
        font-weight: 400;
    }

    .ai-tools-footer .footer-column a::before {
        content: '';
        position: absolute;
        width: 0;
        height: 2px;
        bottom: -3px;
        left: 50%;
        background-color: #5da2ff;
        transition: all 0.3s ease;
    }

    .ai-tools-footer .footer-column a:hover {
        color: #5da2ff;
        font-weight: 500;
    }

    .ai-tools-footer .footer-column a:hover::before {
        width: 100%;
        left: 0;
    }

    .ai-tools-footer .footer-bottom {
        max-width: 1300px;
        margin: 3rem auto 0;
        padding: 1.5rem;
        border-top: 1px solid rgba(255, 255, 255, 0.2);
        text-align: center;
    }

    .ai-tools-footer .footer-links {
        display: flex;
        justify-content: center;
        gap: 1.5rem;
        margin-bottom: 1.5rem;
    }

    .ai-tools-footer .footer-links a {
        color: #c4d0ff;
        text-decoration: none;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 1px;
        transition: color 0.3s ease;
        position: relative;
    }

    .ai-tools-footer .footer-links a::before {
        content: '';
        position: absolute;
        width: 0;
        height: 2px;
        bottom: -3px;
        left: 50%;
        background-color: #5da2ff;
        transition: all 0.3s ease;
    }

    .ai-tools-footer .footer-links a:hover {
        color: #5da2ff;
        font-weight: 600;
    }

    .ai-tools-footer .footer-links a:hover::before {
        width: 100%;
        left: 0;
    }

    .ai-tools-footer .footer-bottom p {
        font-weight: 400;
        color: #c4d0ff;
    }

    /* Responsive Design */
    @media (max-width: 1024px) {
        .ai-tools-footer .footer-columns {
            grid-template-columns: repeat(4, 1fr);
        }
    }

    @media (max-width: 640px) {
        .ai-tools-footer .footer-columns {
            grid-template-columns: 1fr;
        }
    }

    /* Subtle Animation */
    @keyframes ai-tools-subtle-glow {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.8; }
    }

    .ai-tools-footer .footer-column a:hover {
        animation: ai-tools-subtle-glow 1.5s infinite;
    }

    .ai-tools-footer .footer-links a:hover {
        animation: ai-tools-subtle-glow 1.5s infinite;
    }
    </style>
</head>
<body>
<footer class="ai-tools-footer">
    <div class="footer-columns">
        <div class="footer-column">
            <h4>Company</h4>
            <ul>
                <li><a href="/page/about">About</a></li>
                <li><a href="#">Blog</a></li>
                <li><a href="/page/disclaimer">Disclaimer</a></li>
                <li><a href="/pricing">Pricing</a></li>
                <li><a href="/page/careers">Careers</a></li>
            </ul>
        </div>
        <div class="footer-column">
            <h4>Use Cases</h4>
            <ul>
                <li><a href="#">Marketing</a></li>
                <li><a href="#">Social Media</a></li>
                <li><a href="#">YouTube</a></li>
                <li><a href="#">SEO</a></li>
                <li><a href="/page/FAQs">FAQs</a></li>
            </ul>
        </div>
        <div class="footer-column">
            <h4>Tools</h4>
            <ul>
                <li><a href="#">AI Article Writer</a></li>
                <li><a href="#">AI Image Generator</a></li>
                <li><a href="#">AI Email Generator</a></li>
                <li><a href="#">AI Logo Generator</a></li>
                <li><a href="#">AI Text Generator</a></li>
            </ul>
        </div>
        <div class="footer-column">
            <h4>Support</h4>
            <ul>
                <li><a href="#">Live Webinar</a></li>
                <li><a href="/page/contact">Contact us</a></li>
                <?php if (!isset($_SESSION['user_id'])): ?>
                <li><a href="/register">Register</a></li>
                <li><a href="/login">Login</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="footer-links">
            <a href="/page/terms">Terms & Conditions</a>
            <a href="/page/privacy">Privacy Policy</a>
            <a href="#">Refund Policy</a>
        </div>
        <p>&copy; <?php echo date('Y'); ?> AI Tools Platform. All rights reserved.</p>
    </div>
</footer>
<script src="/assets/js/main.js"></script>
</body>
</html>