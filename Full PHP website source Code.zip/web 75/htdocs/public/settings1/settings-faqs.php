<?php
// Common FAQs for the settings section
$faqs = [
    [
        'question' => 'How do I change my profile picture?',
        'answer' => 'You can change your profile picture from the Profile page. Click on the "Change Photo" button under your profile image.'
    ],
    [
        'question' => 'How do I upgrade to a Premium account?',
        'answer' => 'To upgrade to Premium, go to the "Upgrade Account" section on this page and click on the "Upgrade Now" button.'
    ],
    [
        'question' => 'What happens when I delete my account?',
        'answer' => 'When you schedule account deletion, your account will remain active for 30 days. After that period, all your data will be permanently deleted from our systems.'
    ],
    [
        'question' => 'How can I enable two-factor authentication?',
        'answer' => 'To enable two-factor authentication, go to the "Security Settings" section and click on "Set Up 2FA".'
    ],
    [
        'question' => 'How can I contact support?',
        'answer' => 'For additional help, please contact our support team using the contact form in the "Help & Support" section.'
    ]
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Settings FAQs</title>
  <!-- Font Awesome from CDN -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    /* Scoped styles with unique prefix to avoid conflicts */
    .custom-faq-section {
      padding: 4rem 0;
      background-color: #F8FAFC; /* Matching settings light color */
      width: 100%;
      box-sizing: border-box;
      border-radius: 8px; /* Match settings border radius */
      overflow: hidden;
    }

    .custom-faq-container {
      width: 100%;
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 15px;
      box-sizing: border-box;
    }

    /* Section Header Styles */
    .custom-section-header {
      text-align: center;
      margin-bottom: 3rem;
      width: 100%;
    }

    .custom-section-title {
      font-size: 2.5rem;
      font-weight: 700;
      margin-bottom: 0.5rem;
      color: #1E293B; /* Match settings dark color */
      position: relative;
      display: inline-block;
      padding-bottom: 0.5rem;
      line-height: 1.2;
    }

    .custom-section-title::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 50%;
      transform: translateX(-50%);
      width: 80px;
      height: 3px;
      background: linear-gradient(to right, #4F46E5, #7C3AED); /* Match settings gradient */
      border-radius: 3px;
    }

    .custom-section-subtitle {
      font-size: 1.1rem;
      color: #64748B;
      max-width: 700px;
      margin: 0.5rem auto 0;
      line-height: 1.6;
      padding: 0 15px;
    }

    /* FAQ Container Styles */
    .custom-faq-wrapper {
      max-width: 900px;
      margin: 0 auto;
      width: 100%;
      box-sizing: border-box;
      padding: 0 15px;
    }

    /* FAQ Item Styles */
    .custom-faq-item {
      margin-bottom: 1rem;
      border-radius: 8px; /* Match settings border radius */
      background-color: #fff;
      box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05); /* Match settings box shadow */
      overflow: hidden;
      transition: all 0.3s ease;
      width: 100%;
    }

    .custom-faq-item:hover {
      transform: translateY(-5px); /* Match settings hover effect */
      box-shadow: 0 15px 20px -5px rgba(0, 0, 0, 0.15);
    }

    /* FAQ Question Styles */
    .custom-faq-question {
      padding: 1.25rem 1.5rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      cursor: pointer;
      font-weight: 600;
      color: #1E293B; /* Match settings dark color */
      background-color: #fff;
      transition: background-color 0.3s ease;
      width: 100%;
      box-sizing: border-box;
      border-radius: 8px 8px 0 0;
      background: linear-gradient(to right, rgba(79, 70, 229, 0.05), transparent); /* Match settings gradient background */
    }

    .custom-faq-question:hover {
      background-color: #F8FAFC;
    }

    .custom-faq-question span {
      flex: 1;
      text-align: left;
      padding-right: 20px;
    }

    .custom-faq-question i {
      transform: rotate(0deg);
      transition: transform 0.3s ease;
      color: #4F46E5; /* Match settings primary color */
      font-size: 0.9rem;
      flex-shrink: 0;
    }

    /* FAQ Answer Styles */
    .custom-faq-answer {
      height: 0;
      overflow: hidden;
      transition: height 0.3s ease;
      width: 100%;
      box-sizing: border-box;
    }

    .custom-faq-answer-inner {
      padding: 0 1.5rem 1.5rem 1.5rem;
      color: #64748B; /* Match settings text color */
      line-height: 1.6;
      font-size: 1rem;
      text-align: left;
    }

    /* Active State Styles */
    .custom-faq-item.active {
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    }

    .custom-faq-item.active .custom-faq-question {
      background-color: #F8FAFC;
      border-radius: 8px 8px 0 0;
    }

    .custom-faq-item.active .custom-faq-question i {
      transform: rotate(180deg);
      color: #4F46E5; /* Match settings primary color */
    }
    
    .custom-faq-item:not(.active) .custom-faq-question {
      border-radius: 8px;
    }

    /* Responsive Styles */
    @media (max-width: 1200px) {
      .custom-faq-container {
        max-width: 95%;
      }
    }

    @media (max-width: 992px) {
      .custom-faq-wrapper {
        max-width: 90%;
      }
      
      .custom-section-title {
        font-size: 2.2rem;
      }
    }

    @media (max-width: 768px) {
      .custom-faq-section {
        padding: 3rem 0;
        border-radius: 8px;
      }
      
      .custom-faq-container {
        padding: 0 10px;
      }
      
      .custom-section-title {
        font-size: 1.8rem;
      }
      
      .custom-section-subtitle {
        font-size: 1rem;
        max-width: 90%;
      }
      
      .custom-faq-wrapper {
        padding: 0 10px;
      }
      
      .custom-faq-question {
        padding: 1.1rem 1.25rem;
      }
      
      .custom-faq-answer-inner {
        padding: 0 1.25rem 1.25rem 1.25rem;
      }
    }

    @media (max-width: 576px) {
      .custom-faq-section {
        padding: 2.5rem 0;
        border-radius: 8px;
      }
      
      .custom-section-title {
        font-size: 1.6rem;
      }
      
      .custom-section-title::after {
        width: 60px;
      }
      
      .custom-section-subtitle {
        font-size: 0.9rem;
        padding: 0 10px;
      }
      
      .custom-faq-wrapper {
        max-width: 100%;
      }
      
      .custom-faq-item {
        border-radius: 8px;
      }
      
      .custom-faq-question {
        padding: 0.9rem 1rem;
        font-size: 0.95rem;
        border-radius: 8px 8px 0 0;
      }
      
      .custom-faq-item:not(.active) .custom-faq-question {
        border-radius: 8px;
      }
      
      .custom-faq-question span {
        padding-right: 10px;
      }
      
      .custom-faq-answer-inner {
        padding: 0 1rem 1rem 1rem;
        font-size: 0.9rem;
      }
      
      .custom-faq-btn {
        padding: 0.7rem 1.8rem;
        font-size: 0.95rem;
      }
    }

    @media (max-width: 375px) {
      .custom-section-title {
        font-size: 1.4rem;
      }
      
      .custom-faq-question {
        font-size: 0.9rem;
        padding: 0.8rem 0.9rem;
      }
      
      .custom-faq-answer-inner {
        font-size: 0.85rem;
      }
      
      .custom-faq-btn {
        padding: 0.6rem 1.5rem;
        font-size: 0.9rem;
      }
    }

  </style>
</head>
<body>
  <!-- Custom FAQ Section with unique class names (kept original) -->
  <section class="custom-faq-section">
    <div class="custom-faq-container">
      <div class="custom-section-header">
        <h2><i class="fas fa-question-circle"></i> Frequently Asked Questions</h2>
        <p class="custom-section-subtitle">Find answers to common questions about managing your account settings</p>
      </div>
      
      <div class="custom-faq-wrapper">
        <?php foreach ($faqs as $index => $faq): ?>
        <!-- FAQ Item <?php echo $index + 1; ?> -->
        <div class="custom-faq-item">
          <div class="custom-faq-question">
            <span><?php echo $faq['question']; ?></span>
            <i class="fas fa-chevron-down"></i>
          </div>
          <div class="custom-faq-answer">
            <div class="custom-faq-answer-inner">
              <?php echo $faq['answer']; ?>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- Isolated script with unique ID to avoid conflicts (kept original) -->
  <script>
    // Use IIFE to keep variables scoped and avoid conflicts
    (function() {
      document.addEventListener('DOMContentLoaded', function() {
        // Use specific selectors to only target our custom FAQ elements
        const customFaqItems = document.querySelectorAll('.custom-faq-item');
        
        customFaqItems.forEach(item => {
          const question = item.querySelector('.custom-faq-question');
          question.addEventListener('click', () => {
            item.classList.toggle('active');
            
            const answer = item.querySelector('.custom-faq-answer');
            if (item.classList.contains('active')) {
              answer.style.height = answer.scrollHeight + 'px';
            } else {
              answer.style.height = '0';
            }
          });
        });
        
        // Set the first FAQ item as active by default
        if (customFaqItems.length > 0) {
          customFaqItems[0].classList.add('active');
          const firstAnswer = customFaqItems[0].querySelector('.custom-faq-answer');
          firstAnswer.style.height = firstAnswer.scrollHeight + 'px';
        }
      });
    })();
  </script>
</body>
</html>