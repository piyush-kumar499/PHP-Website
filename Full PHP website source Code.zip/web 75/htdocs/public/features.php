<?php
include 'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include_once ('../private/favicon.php'); ?>
    <title>Features</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
:root {
    --primary-color: #4F46E5;
    --secondary-color: #7C3AED;
    --dark-color: #1E293B;
    --light-color: #F8FAFC;
    --accent-color: #06B6D4;
    --success-color: #10B981;
    --warning-color: #F59E0B;
    --border-radius: 8px;
    --box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
}

body {
    background-color: var(--light-color);
    color: var(--dark-color);
    line-height: 1.6;
}

.container {
    width: 100%;
    max-width: 1200px;
    margin: 0 auto;
    padding: 2rem;
}

header {
    margin-bottom: 3rem;
    text-align: center;
}

h1 {
    font-size: 3rem;
    margin-bottom: 0.5rem;
    background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    text-fill-color: transparent;
}

.subtitle {
    font-size: 1.2rem;
    color: #64748B;
    margin-bottom: 1.5rem;
    max-width: 800px;
    margin-left: auto;
    margin-right: auto;
}

.features-hero {
    position: relative;
    background-color: #fff;
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
    overflow: hidden;
    margin-bottom: 4rem;
}

.hero-image {
    width: 100%;
    min-height: 400px;
    height: auto;
    object-fit: cover;
    background: linear-gradient(135deg, #4F46E5, #7C3AED);
    position: relative;
}

.hero-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(30, 41, 59, 0.7);
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    text-align: center;
    padding: 2rem;
}

.hero-title {
    color: white;
    font-size: 2.5rem;
    margin-bottom: 1rem;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
}

.hero-subtitle {
    color: rgba(255, 255, 255, 0.9);
    font-size: 1.25rem;
    max-width: 800px;
}

.section {
    margin-bottom: 4rem;
}

.section-title {
    font-size: 2rem;
    margin-bottom: 1.5rem;
    color: var(--dark-color);
    position: relative;
    padding-bottom: 0.5rem;
    display: inline-block;
}

.section-title::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 60%;
    height: 3px;
    background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
    border-radius: 3px;
}

.section-content {
    background-color: #fff;
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
    padding: 2rem;
}

.feature-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
    gap: 2rem;
    margin-top: 2rem;
}

.feature-card {
    background-color: #fff;
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
    overflow: hidden;
    transition: transform 0.3s ease;
}

.feature-card:hover {
    transform: translateY(-5px);
}

.feature-image {
    height: 200px;
    background: linear-gradient(135deg, #6366F1, #A855F7);
    position: relative;
    overflow: hidden;
}

.feature-icon {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    font-size: 4rem;
    color: rgba(255, 255, 255, 0.8);
    text-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
}

.feature-content {
    padding: 1.5rem;
}

.feature-title {
    font-size: 1.4rem;
    margin-bottom: 0.75rem;
    color: var(--dark-color);
}

.feature-description {
    color: #4B5563;
    margin-bottom: 1.25rem;
}

.feature-tag {
    display: inline-block;
    padding: 0.25rem 0.75rem;
    background-color: #EEF2FF;
    color: var(--primary-color);
    border-radius: 20px;
    font-size: 0.85rem;
    margin-right: 0.5rem;
    margin-bottom: 0.5rem;
}

.benefits-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
    margin-top: 2rem;
}

.benefit-card {
    background-color: #fff;
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
    padding: 2rem;
    text-align: center;
    transition: transform 0.3s ease;
}

.benefit-card:hover {
    transform: translateY(-5px);
}

.benefit-icon {
    font-size: 2.5rem;
    margin-bottom: 1rem;
    background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    text-fill-color: transparent;
}

.benefit-title {
    font-size: 1.2rem;
    margin-bottom: 1rem;
    color: var(--dark-color);
}

.benefit-text {
    color: #4B5563;
}

.comparison-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 2rem;
    box-shadow: var(--box-shadow);
    border-radius: var(--border-radius);
    overflow: hidden;
}

.comparison-table th, .comparison-table td {
    padding: 1rem;
    text-align: center;
    border-bottom: 1px solid #E2E8F0;
}

.comparison-table th {
    background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
    color: white;
    font-weight: 600;
}

.comparison-table tr:nth-child(even) {
    background-color: #F8FAFC;
}

.comparison-table tr:hover {
    background-color: #EEF2FF;
}

.plan-name {
    font-weight: 700;
    color: var(--dark-color);
}

.check-icon {
    color: var(--success-color);
    font-size: 1.2rem;
}

.x-icon {
    color: #94A3B8;
    font-size: 1.2rem;
}

.use-case-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 2rem;
    margin-top: 2rem;
}

.use-case {
    background-color: #fff;
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
    padding: 2rem;
    transition: transform 0.3s ease;
}

.use-case:hover {
    transform: translateY(-5px);
}

.use-case-icon {
    font-size: 2.5rem;
    margin-bottom: 1rem;
    background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    text-fill-color: transparent;
}

.use-case-title {
    font-size: 1.2rem;
    margin-bottom: 1rem;
    color: var(--dark-color);
}

.use-case-text {
    color: #4B5563;
}

.integration-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    gap: 1.5rem;
    margin-top: 2rem;
}

.integration-card {
    background-color: #fff;
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
    padding: 1.5rem;
    text-align: center;
    transition: all 0.3s ease;
}

.integration-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 20px -10px rgba(0, 0, 0, 0.15);
}

.integration-icon {
    font-size: 2rem;
    margin-bottom: 1rem;
    color: var(--primary-color);
}

.integration-name {
    font-size: 1rem;
    color: var(--dark-color);
    font-weight: 500;
}

.testimonial-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
    gap: 2rem;
    margin-top: 2rem;
}

.testimonial-card {
    background-color: #fff;
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
    padding: 2rem;
    position: relative;
    overflow: hidden;
}

.testimonial-card::before {
    content: '\201C';
    position: absolute;
    top: -30px;
    left: 20px;
    font-size: 8rem;
    color: #F1F5F9;
    font-family: serif;
    z-index: 0;
}

.testimonial-content {
    position: relative;
    z-index: 1;
}

.testimonial-text {
    color: #4B5563;
    font-style: italic;
    margin-bottom: 1.5rem;
}

.testimonial-author {
    display: flex;
    align-items: center;
}

.author-avatar {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background: linear-gradient(135deg, #6366F1, #A855F7);
    margin-right: 1rem;
}

.author-name {
    font-weight: 600;
    color: var(--dark-color);
    margin-bottom: 0.25rem;
}

.author-company {
    color: #64748B;
    font-size: 0.9rem;
}

.cta-section {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    padding: 3rem 2rem;
    border-radius: var(--border-radius);
    text-align: center;
    margin-top: 2rem;
    color: white;
}

.cta-title {
    font-size: 2rem;
    margin-bottom: 1rem;
}

.cta-text {
    margin-bottom: 1.5rem;
    max-width: 700px;
    margin-left: auto;
    margin-right: auto;
}

.cta-button {
    display: inline-block;
    background-color: white;
    color: var(--primary-color);
    padding: 0.75rem 2rem;
    border-radius: 30px;
    font-weight: 600;
    text-decoration: none;
    transition: all 0.3s ease;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.cta-button:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
}

.faq-container {
    margin-top: 2rem;
}

.faq-item {
    margin-bottom: 1rem;
    border-radius: var(--border-radius);
    background-color: #fff;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
    overflow: hidden;
}

.faq-question {
    padding: 1.5rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
    font-weight: 600;
    color: var(--dark-color);
    background-color: #fff;
    transition: background-color 0.3s ease;
}

.faq-question:hover {
    background-color: #F8FAFC;
}

.faq-question i {
    transform: rotate(0deg);
    transition: transform 0.3s ease;
}

.faq-answer {
    padding: 0 1.5rem;
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.3s ease, padding 0.3s ease;
}

.faq-answer-inner {
    padding-bottom: 1.5rem;
    color: #4B5563;
}

.faq-item.active .faq-question {
    background-color: #F8FAFC;
}

.faq-item.active .faq-question i {
    transform: rotate(180deg);
}

.faq-item.active .faq-answer {
    max-height: 500px;
    padding: 0 1.5rem 1.5rem;
}

.tab-container {
    margin-top: 2rem;
}

.tabs {
    display: flex;
    overflow-x: auto;
    scrollbar-width: none;
    -ms-overflow-style: none;
    margin-bottom: 2rem;
    background-color: #F1F5F9;
    border-radius: 10px;
    padding: 0.5rem;
}

.tabs::-webkit-scrollbar {
    display: none;
}

.tab {
    padding: 1rem 1.5rem;
    font-weight: 500;
    color: #64748B;
    cursor: pointer;
    transition: all 0.3s ease;
    border-radius: 8px;
    white-space: nowrap;
}

.tab.active {
    background-color: white;
    color: var(--primary-color);
    font-weight: 600;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.tab-content {
    display: none;
}

.tab-content.active {
    display: block;
    animation: fadeIn 0.5s ease;
}

@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

/* Additional Fixes for Better Alignment */
.feature-tag {
    display: inline-block;
    padding: 0.25rem 0.75rem;
    background-color: #EEF2FF;
    color: var(--primary-color);
    border-radius: 20px;
    font-size: 0.85rem;
    margin-right: 0.5rem;
    margin-bottom: 0.5rem;
}

.benefits-container,
.use-case-grid,
.integration-grid {
    display: grid;
    gap: 2rem;
}

.benefit-card,
.use-case,
.integration-card {
    height: 100%;
    display: flex;
    flex-direction: column;
}

.benefit-text,
.use-case-text {
    flex-grow: 1;
}

/* Fix for the FAQs accordion */
.faq-item {
    margin-bottom: 1rem;
    border-radius: var(--border-radius);
    background-color: #fff;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
    overflow: hidden;
}

.faq-answer {
    height: 0;
    overflow: hidden;
    transition: height 0.3s ease;
}

.faq-item.active .faq-answer {
    height: auto;
    padding: 0 1.5rem 1.5rem;
}

/* Improved Responsive Design */
@media (max-width: 992px) {
    .container {
        padding: 1.5rem;
    }
}

@media (max-width: 768px) {
    .feature-grid, 
    .testimonial-grid, 
    .use-case-grid {
        grid-template-columns: 1fr;
    }
    
    .container {
        padding: 1rem;
    }
    
    h1 {
        font-size: 2.2rem;
    }
    
    .hero-title {
        font-size: 2rem;
    }
    
    .section-title {
        font-size: 1.8rem;
    }
    
    .hero-image {
        height: 300px;
    }
    
    .comparison-table {
        display: block;
        overflow-x: auto;
        white-space: nowrap;
    }
    
    .tabs {
        flex-wrap: wrap;
        justify-content: center;
    }
    
    .tab {
        margin-bottom: 0.5rem;
    }
    
    .feature-image, 
    .benefit-icon, 
    .use-case-icon, 
    .integration-icon {
        transform: scale(0.9);
    }
    
    .benefit-card, 
    .use-case, 
    .integration-card {
        padding: 1.5rem;
    }
}

@media (max-width: 480px) {
    .hero-title {
        font-size: 1.8rem;
    }
    
    .hero-subtitle {
        font-size: 1rem;
    }
    
    .hero-image {
        height: 250px;
    }
    
    .cta-title {
        font-size: 1.6rem;
    }
    
    .cta-text {
        font-size: 0.95rem;
    }
    
    .section-title {
        font-size: 1.6rem;
    }
    
    .section-content {
        padding: 1.5rem;
    }
}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Our AI Platform Features</h1>
            <p class="subtitle">Explore the powerful capabilities of our AI tools designed to transform how businesses operate, innovate, and grow.</p>
        </header>
        
        <div class="features-hero">
            <div class="hero-image"></div>
            <div class="hero-overlay">
                <h2 class="hero-title">Powerful AI Tools for Every Business Need</h2>
                <p class="hero-subtitle">Our comprehensive suite of AI solutions delivers the capabilities you need to automate workflows, gain insights, and create exceptional experiences.</p>
            </div>
        </div>
        
        <section class="section">
            <h2 class="section-title">Core Features</h2>
            <div class="section-content">
                <p style="margin-bottom: 2rem; text-align: center; color: #4B5563; max-width: 800px; margin-left: auto; margin-right: auto;">
                    Our AI platform offers a wide range of capabilities designed to help businesses of all sizes harness the power of artificial intelligence without specialized expertise.
                </p>
                
                <div class="feature-grid">
                    <div class="feature-card">
                        <div class="feature-image">
                            <div class="feature-icon">
                                <i class="fas fa-brain"></i>
                            </div>
                        </div>
                        <div class="feature-content">
                            <h3 class="feature-title">Advanced Natural Language Processing</h3>
                            <p class="feature-description">Process, analyze, and generate human language with remarkable accuracy. Our NLP tools can summarize documents, extract key information, translate languages, and generate high-quality content.</p>
                            <div>
                                <span class="feature-tag">Content Generation</span>
                                <span class="feature-tag">Translation</span>
                                <span class="feature-tag">Sentiment Analysis</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="feature-card">
                        <div class="feature-image">
                            <div class="feature-icon">
                                <i class="fas fa-chart-line"></i>
                            </div>
                        </div>
                        <div class="feature-content">
                            <h3 class="feature-title">Predictive Analytics</h3>
                            <p class="feature-description">Forecast trends, identify patterns, and make data-driven decisions with our predictive analytics tools. Leverage machine learning to predict customer behavior, market trends, and operational outcomes.</p>
                            <div>
                                <span class="feature-tag">Forecasting</span>
                                <span class="feature-tag">Anomaly Detection</span>
                                <span class="feature-tag">Risk Assessment</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="feature-card">
                        <div class="feature-image">
                            <div class="feature-icon">
                                <i class="fas fa-robot"></i>
                            </div>
                        </div>
                        <div class="feature-content">
                            <h3 class="feature-title">Intelligent Automation</h3>
                            <p class="feature-description">Automate repetitive tasks and complex workflows with AI-powered tools. Build custom automation pipelines that learn and improve over time to increase efficiency and reduce human error.</p>
                            <div>
                                <span class="feature-tag">Process Automation</span>
                                <span class="feature-tag">Workflow Optimization</span>
                                <span class="feature-tag">Smart Assistants</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="feature-card">
                        <div class="feature-image">
                            <div class="feature-icon">
                                <i class="fas fa-eye"></i>
                            </div>
                        </div>
                        <div class="feature-content">
                            <h3 class="feature-title">Computer Vision</h3>
                            <p class="feature-description">Extract insights from images and videos with our computer vision tools. Identify objects, recognize faces, detect emotions, and analyze visual content with state-of-the-art accuracy.</p>
                            <div>
                                <span class="feature-tag">Image Recognition</span>
                                <span class="feature-tag">Object Detection</span>
                                <span class="feature-tag">Visual Search</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="feature-card">
                        <div class="feature-image">
                            <div class="feature-icon">
                                <i class="fas fa-comments"></i>
                            </div>
                        </div>
                        <div class="feature-content">
                            <h3 class="feature-title">Conversational AI</h3>
                            <p class="feature-description">Create intelligent chatbots and virtual assistants that understand natural language, learn from interactions, and provide helpful responses to customer inquiries.</p>
                            <div>
                                <span class="feature-tag">Chatbots</span>
                                <span class="feature-tag">Virtual Assistants</span>
                                <span class="feature-tag">Voice Interfaces</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="feature-card">
                        <div class="feature-image">
                            <div class="feature-icon">
                                <i class="fas fa-lightbulb"></i>
                            </div>
                        </div>
                        <div class="feature-content">
                            <h3 class="feature-title">Recommendation Systems</h3>
                            <p class="feature-description">Deliver personalized recommendations to your users based on their preferences, behavior, and similar user patterns. Increase engagement, conversions, and satisfaction.</p>
                            <div>
                                <span class="feature-tag">Product Recommendations</span>
                                <span class="feature-tag">Content Curation</span>
                                <span class="feature-tag">Personalization</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <section class="section">
            <h2 class="section-title">Key Benefits</h2>
            <div class="section-content">
                <p style="margin-bottom: 2rem; text-align: center; color: #4B5563; max-width: 800px; margin-left: auto; margin-right: auto;">
                    Our AI platform doesn't just offer cutting-edge technology—it delivers tangible benefits that transform how your business operates and competes.
                </p>
                
                <div class="benefits-container">
                    <div class="benefit-card">
                        <div class="benefit-icon">
                            <i class="fas fa-tachometer-alt"></i>
                        </div>
                        <h3 class="benefit-title">Increased Efficiency</h3>
                        <p class="benefit-text">Automate time-consuming tasks and streamline workflows to free up your team's time for more strategic work.</p>
                    </div>
                    
                    <div class="benefit-card">
                        <div class="benefit-icon">
                            <i class="fas fa-chart-pie"></i>
                        </div>
                        <h3 class="benefit-title">Enhanced Decision Making</h3>
                        <p class="benefit-text">Leverage data-driven insights to make better decisions faster and with greater confidence.</p>
                    </div>
                    
                    <div class="benefit-card">
                        <div class="benefit-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <h3 class="benefit-title">Improved Customer Experience</h3>
                        <p class="benefit-text">Deliver personalized interactions and intelligent support that creates satisfied, loyal customers.</p>
                    </div>
                    
                    <div class="benefit-card">
                        <div class="benefit-icon">
                            <i class="fas fa-coins"></i>
                        </div>
                        <h3 class="benefit-title">Cost Reduction</h3>
                        <p class="benefit-text">Lower operational costs through automation, optimization, and predictive maintenance.</p>
                    </div>
                    
                    <div class="benefit-card">
                        <div class="benefit-icon">
                            <i class="fas fa-rocket"></i>
                        </div>
                        <h3 class="benefit-title">Accelerated Innovation</h3>
                        <p class="benefit-text">Discover new opportunities and quickly prototype solutions with AI-powered creativity tools.</p>
                    </div>
                    
                    <div class="benefit-card">
                        <div class="benefit-icon">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <h3 class="benefit-title">Risk Mitigation</h3>
                        <p class="benefit-text">Identify potential issues before they occur and implement preventative measures with intelligent risk assessment.</p>
                    </div>
                </div>
            </div>
        </section>
        
        <section class="section">
            <h2 class="section-title">Plan Comparison</h2>
            <div class="section-content">
                <p style="margin-bottom: 2rem; text-align: center; color: #4B5563; max-width: 800px; margin-left: auto; margin-right: auto;">
                    Choose the plan that best fits your business needs and scale as you grow with our flexible pricing options.
                </p>
                
                <table class="comparison-table">
                    <thead>
                        <tr>
                            <th>Features</th>
                            <th>Starter</th>
                            <th>Professional</th>
                            <th>Enterprise</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="plan-name">Natural Language Processing</td>
                            <td><i class="fas fa-check check-icon"></i></td>
                            <td><i class="fas fa-check check-icon"></i></td>
                            <td><i class="fas fa-check check-icon"></i></td>
                        </tr>
                        <tr>
                            <td class="plan-name">Basic Automation</td>
                            <td><i class="fas fa-check check-icon"></i></td>
                            <td><i class="fas fa-check check-icon"></i></td>
                            <td><i class="fas fa-check check-icon"></i></td>
                        </tr>
                        <tr>
                            <td class="plan-name">Predictive Analytics</td>
                            <td><i class="fas fa-times x-icon"></i></td>
                            <td><i class="fas fa-check check-icon"></i></td>
                            <td><i class="fas fa-check check-icon"></i></td>
                        </tr>
                        <tr>
                            <td class="plan-name">Computer Vision</td>
                            <td><i class="fas fa-times x-icon"></i></td>
                            <td><i class="fas fa-check check-icon"></i></td>
                            <td><i class="fas fa-check check-icon"></i></td>
                        </tr>
                        <tr>
                            <td class="plan-name">Conversational AI</td>
                            <td><i class="fas fa-times x-icon"></i></td>
                            <td><i class="fas fa-check check-icon"></i></td>
                            <td><i class="fas fa-check check-icon"></i></td>
                        </tr>
                        <tr>
                            <td class="plan-name">Advanced Recommendation Systems</td>
                            <td><i class="fas fa-times x-icon"></i></td>
                            <td><i class="fas fa-times x-icon"></i></td>
                            <td><i class="fas fa-check check-icon"></i></td>
                        </tr>
                        <tr>
                            <td class="plan-name">Custom Model Training</td>
                            <td><i class="fas fa-times x-icon"></i></td>
                            <td><i class="fas fa-times x-icon"></i></td>
                            <td><i class="fas fa-check check-icon"></i></td>
                        </tr>
                        <tr>
                            <td class="plan-name">Priority Support</td>
                            <td><i class="fas fa-times x-icon"></i></td>
                            <td><i class="fas fa-times x-icon"></i></td>
                            <td><i class="fas fa-check check-icon"></i></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>
        
        <section class="section">
            <h2 class="section-title">Use Cases</h2>
            <div class="section-content">
                <p style="margin-bottom: 2rem; text-align: center; color: #4B5563; max-width: 800px; margin-left: auto; margin-right: auto;">
                    Our AI platform helps businesses across various industries solve complex challenges and unlock new opportunities.
                </p>
                
                <div class="use-case-grid">
                    <div class="use-case">
                        <div class="use-case-icon">
                            <i class="fas fa-shopping-cart"></i>
                        </div>
                        <h3 class="use-case-title">E-commerce Personalization</h3>
                        <p class="use-case-text">Increase conversion rates by delivering personalized product recommendations, improving search relevance, and optimizing the shopping experience based on individual preferences.</p>
                    </div>
                    
                    <div class="use-case">
                        <div class="use-case-icon">
                            <i class="fas fa-headset"></i>
                        </div>
                        <h3 class="use-case-title">Customer Support Automation</h3>
                        <p class="use-case-text">Improve customer satisfaction and reduce support costs by automating routine inquiries, providing instant responses, and routing complex issues to the right human agents.</p>
                    </div>
                    
                    <div class="use-case">
                        <div class="use-case-icon">
                            <i class="fas fa-chart-bar"></i>
                        </div>
                        <h3 class="use-case-title">Market Intelligence</h3>
                        <p class="use-case-text">Stay ahead of market trends by analyzing customer sentiment, monitoring competitor activities, and forecasting demand patterns to inform strategic decisions.</p>
                    </div>
                    
                    <div class="use-case">
                        <div class="use-case-icon">
                            <i class="fas fa-industry"></i>
                        </div>
                        <h3 class="use-case-title">Predictive Maintenance</h3>
                        <p class="use-case-text">Minimize equipment downtime and maintenance costs by predicting failures before they occur, optimizing maintenance schedules, and extending asset lifespans.</p>
                    </div>
                    
                    <div class="use-case">
                        <div class="use-case-icon">
                            <i class="fas fa-bullhorn"></i>
                        </div>
                        <h3 class="use-case-title">Content Marketing</h3>
                        <p class="use-case-text">Create engaging, SEO-optimized content at scale, personalize messaging for different audience segments, and automate content distribution across channels.</p>
                    </div>
                    
                    <div class="use-case">
                        <div class="use-case-icon">
                            <i class="fas fa-user-shield"></i>
                        </div>
                        <h3 class="use-case-title">Fraud Detection</h3>
                        <p class="use-case-text">Protect your business and customers by identifying suspicious activities, detecting anomalies in real-time, and preventing fraudulent transactions before they occur.</p>
                    </div>
                </div>
            </div>
        </section>
        
        <section class="section">
            <h2 class="section-title">Integrations</h2>
            <div class="section-content">
                <p style="margin-bottom: 2rem; text-align: center; color: #4B5563; max-width: 800px; margin-left: auto; margin-right: auto;">
                    Our AI platform seamlessly integrates with your existing tech stack to enhance capabilities and streamline workflows.
                </p>
                
                <div class="integration-grid">
                    <div class="integration-card">
                        <div class="integration-icon">
                            <i class="fab fa-salesforce"></i>
                        </div>
                        <p class="integration-name">Salesforce</p>
                    </div>
                    
                    <div class="integration-card">
                        <div class="integration-icon">
                            <i class="fab fa-slack"></i>
                        </div>
                        <p class="integration-name">Slack</p>
                    </div>
                    
                    <div class="integration-card">
                        <div class="integration-icon">
                            <i class="fab fa-microsoft"></i>
                        </div>
                        <p class="integration-name">Microsoft 365</p>
                    </div>
                    
                    <div class="integration-card">
                        <div class="integration-icon">
                            <i class="fab fa-google"></i>
                        </div>
                        <p class="integration-name">Google Workspace</p>
                    </div>
                    
                    <div class="integration-card">
                        <div class="integration-icon">
                            <i class="fab fa-shopify"></i>
                        </div>
                        <p class="integration-name">Shopify</p>
                    </div>
                    
                    <div class="integration-card">
                        <div class="integration-icon">
                            <i class="fab fa-hubspot"></i>
                        </div>
                        <p class="integration-name">HubSpot</p>
                    </div>
                    
                    <div class="integration-card">
                        <div class="integration-icon">
                            <i class="fab fa-aws"></i>
                        </div>
                        <p class="integration-name">AWS</p>
                    </div>
                    
                    <div class="integration-card">
                        <div class="integration-icon">
                            <i class="fab fa-github"></i>
                        </div>
                        <p class="integration-name">GitHub</p>
                    </div>
                    
                    <div class="integration-card">
                        <div class="integration-icon">
                            <i class="fab fa-jira"></i>
                        </div>
                        <p class="integration-name">Jira</p>
                    </div>
                    
                    <div class="integration-card">
                        <div class="integration-icon">
                            <i class="fab fa-mailchimp"></i>
                        </div>
                        <p class="integration-name">Mailchimp</p>
                    </div>
                    
                    <div class="integration-card">
                        <div class="integration-icon">
                            <i class="fab fa-stripe"></i>
                        </div>
                        <p class="integration-name">Stripe</p>
                    </div>
                    
                    <div class="integration-card">
                        <div class="integration-icon">
                            <i class="fab fa-trello"></i>
                        </div>
                        <p class="integration-name">Trello</p>
                    </div>
                </div>
            </div>
        </section>
        
        <section class="section">
            <h2 class="section-title">Testimonials</h2>
            <div class="section-content">
                <p style="margin-bottom: 2rem; text-align: center; color: #4B5563; max-width: 800px; margin-left: auto; margin-right: auto;">
                    See what our customers are saying about how our AI platform has transformed their businesses.
                </p>
                
                <div class="testimonial-grid">
                    <div class="testimonial-card">
                        <div class="testimonial-content">
                            <p class="testimonial-text">"Implementing this AI platform has completely transformed our customer service operations. We've reduced response times by 65% and increased customer satisfaction scores to an all-time high."</p>
                            <div class="testimonial-author">
                                <div class="author-avatar"></div>
                                <div>
                                    <p class="author-name">Sarah Johnson</p>
                                    <p class="author-company">CTO, TechSolutions Inc.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="testimonial-card">
                        <div class="testimonial-content">
                            <p class="testimonial-text">"The predictive analytics features have given us insights we never thought possible. We've been able to forecast demand with 92% accuracy, optimizing our inventory and saving millions."</p>
                            <div class="testimonial-author">
                                <div class="author-avatar"></div>
                                <div>
                                    <p class="author-name">Michael Chen</p>
                                    <p class="author-company">Supply Chain Director, Global Retail</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="testimonial-card">
                        <div class="testimonial-content">
                            <p class="testimonial-text">"Our marketing team has leveraged the NLP tools to create highly engaging content that resonates with our audience. We've seen a 40% increase in engagement and a significant boost in conversion rates."</p>
                            <div class="testimonial-author">
                                <div class="author-avatar"></div>
                                <div>
                                    <p class="author-name">Emily Rodriguez</p>
                                    <p class="author-company">Marketing VP, Digital Media Group</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <section class="section">
            <h2 class="section-title">Frequently Asked Questions</h2>
            <div class="section-content">
                <div class="faq-container">
                    <div class="faq-item active">
                        <div class="faq-question">
                            <span>How does the AI platform ensure data security and privacy?</span>
                            <i class="fas fa-chevron-down"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                Our AI platform is built with security and privacy at its core. All data is encrypted both in transit and at rest using industry-standard protocols. We comply with GDPR, CCPA, and other regional privacy regulations. Your data is never used to train our models without explicit consent, and you maintain full ownership of your data at all times.
                            </div>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>Do I need technical expertise to use the platform?</span>
                            <i class="fas fa-chevron-down"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                No technical expertise is required to use our AI platform. We've designed it with intuitive interfaces and user-friendly tools that enable anyone in your organization to leverage the power of AI. For more advanced customization, we offer no-code builders and integration options that don't require programming knowledge.
                            </div>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>How quickly can I see results after implementing the platform?</span>
                            <i class="fas fa-chevron-down"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                Many of our customers start seeing tangible results within the first few weeks of implementation. The exact timeline depends on your specific use cases and the complexity of your integration, but our customer success team works closely with you to ensure quick time-to-value. Some tools, like chatbots and content generation, can be deployed and delivering value in as little as a few days.
                            </div>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>Can the AI platform integrate with my existing systems?</span>
                            <i class="fas fa-chevron-down"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                Yes, our AI platform is designed to integrate seamlessly with your existing tech stack. We offer pre-built connectors for popular business applications, as well as robust APIs for custom integrations. Our team can also work with you to develop specific integrations for your unique needs.
                            </div>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>How is the platform priced?</span>
                            <i class="fas fa-chevron-down"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                We offer flexible pricing plans designed to scale with your business needs. Our pricing is based on a combination of features accessed and usage volume. We provide transparent pricing with no hidden fees, and our team works with you to ensure you're getting the most value from your investment. Contact our sales team for a customized quote based on your specific requirements.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
<?php include 'homepage/pricing.php'; ?>
        
        <div class="cta-section">
            <h2 class="cta-title">Ready to Transform Your Business with AI?</h2>
            <p class="cta-text">Join thousands of organizations that are leveraging our AI platform to drive innovation, efficiency, and growth.</p>
            <a href="#" class="cta-button">Start Your Free Trial</a>
        </div>
        
        <footer style="margin-top: 4rem; text-align: center; color: #64748B; padding-bottom: 2rem;">
            <p>&copy; <?php echo $currentYear; ?> AI Tools Platform. All rights reserved.</p>
        </footer>
    </div>
    
    <script>
        // FAQ Accordion
        const faqItems = document.querySelectorAll('.faq-item');
        
        faqItems.forEach(item => {
            const question = item.querySelector('.faq-question');
            
            question.addEventListener('click', () => {
                const isActive = item.classList.contains('active');
                
                // Close all items
                faqItems.forEach(faqItem => {
                    faqItem.classList.remove('active');
                });
                
                // If clicked item wasn't active, open it
                if (!isActive) {
                    item.classList.add('active');
                }
            });
        });
        
        // Tabs functionality
        const tabs = document.querySelectorAll('.tab');
        const tabContents = document.querySelectorAll('.tab-content');
        
        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                const target = tab.getAttribute('data-target');
                
                // Remove active class from all tabs and contents
                tabs.forEach(t => t.classList.remove('active'));
                tabContents.forEach(c => c.classList.remove('active'));
                
                // Add active class to clicked tab and corresponding content
                tab.classList.add('active');
                document.getElementById(target).classList.add('active');
            });
        });
    </script>
</body>
</html>