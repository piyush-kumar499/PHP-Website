<?php
include 'header.php';

?>

<?php
$popupTimeLimit = 0.5;
$showOnEveryReload = true; 
$isMandatoryPage = false;

include 'popup-auth.php';
?>

<!-- Index starts from Here -->

<link rel="stylesheet" href="/assets/css/style.css">

<main class="site-main">

    <section class="hero">
        <div class="hero-content">
            <h1 class="hero-title">Create Better Content in Less Time</h1>
            <p class="hero-subtitle">Your AI-Powered Content Creation Companion for Seamless Writing, SEO, and Creativity</p>
            
            <div class="cta-section">
                <?php if(!isset($_SESSION['user_id'])): ?>
                    <div class="cta-buttons">
                        <a href="/register" class="btn btn-primary">
                            Get Started For Free
                        </a>
                        <a href="/features" class="btn btn-secondary">
                            Explore Features
                        </a>
                    </div>
                    <p class="cta-disclaimer">No credit card required • Instant setup • 7-day free trial</p>
                <?php else: ?>
                    <div class="cta-buttons">
                        <a href="#" class="btn btn-primary">Premium AI Tools
                        </a>
                        <a href="/ai-tools" class="btn btn-secondary"> Browse AI Tools
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="stats">
        <div class="stat">
            <div class="stat-number">50K+</div>
            <div class="stat-label">Active Users</div>
        </div>
        <div class="stat">
            <div class="stat-number">2M+</div>
            <div class="stat-label">Content Pieces Created</div>
        </div>
        <div class="stat">
            <div class="stat-number">97%</div>
            <div class="stat-label">Customer Satisfaction</div>
        </div>
        <div class="stat">
            <div class="stat-number">10x</div>
            <div class="stat-label">Faster Content Creation</div>
        </div>
    </section>

    <!-- Features Section -->

<section class="features">
    <a href="/" class="feature-link">
        <div class="feature">
            <div class="feature-icon">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                </svg>
            </div>
            <h3 class="feature-title">AI Blog Writer</h3>
            <p class="feature-description">Generate SEO-optimized blog posts with AI in seconds. Customize tone, style, and length effortlessly.</p>
        </div>
    </a>
    <a href="/" class="feature-link">
        <div class="feature">
            <div class="feature-icon">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
            </div>
            <h3 class="feature-title">AI Image Generator</h3>
            <p class="feature-description">Create unique, high-quality images for your content with advanced AI image generation technology.</p>
        </div>
    </a>
    <a href="/" class="feature-link">
        <div class="feature">
            <div class="feature-icon">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                </svg>
            </div>
            <h3 class="feature-title">Social Media Tools</h3>
            <p class="feature-description">Generate engaging social media posts with AI-powered creativity and optimize for maximum engagement.</p>
        </div>
    </a>
    <a href="/" class="feature-link">
        <div class="feature">
            <div class="feature-icon">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
            </div>
            <h3 class="feature-title">SEO Optimization</h3>
            <p class="feature-description">Boost your content's ranking with built-in SEO tools that analyze and enhance your content for search engines.</p>
        </div>
    </a>
    <a href="/" class="feature-link">
        <div class="feature">
            <div class="feature-icon">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M3 14h18m-9-4v8m-7 0h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                </svg>
            </div>
            <h3 class="feature-title">Content Templates</h3>
            <p class="feature-description">Start with professionally designed templates for blogs, emails, ads, and more to accelerate your workflow.</p>
        </div>
    </a>
    <a href="/" class="feature-link">
        <div class="feature">
            <div class="feature-icon">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
            </div>
            <h3 class="feature-title">Real-time Collaboration</h3>
            <p class="feature-description">Work together with your team in real-time with seamless sharing and collaborative editing features.</p>
        </div>
    </a>
    <a href="/" class="feature-link">
        <div class="feature">
            <div class="feature-icon">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
            </div>
            <h3 class="feature-title">Plagiarism Checker</h3>
            <p class="feature-description">Ensure your content is 100% original with our advanced plagiarism detection technology.</p>
        </div>
    </a>
    <a href="/" class="feature-link">
        <div class="feature">
            <div class="feature-icon">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
            </div>
            <h3 class="feature-title">Cost Estimator</h3>
            <p class="feature-description">Calculate the potential ROI of your content marketing efforts with our intelligent cost estimation tool.</p>
        </div>
    </a>
    <a href="/" class="feature-link">
        <div class="feature">
            <div class="feature-icon">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z" />
                </svg>
            </div>
            <h3 class="feature-title">Multilingual Support</h3>
            <p class="feature-description">Create content in over 50 languages with AI translation that preserves your brand voice and tone.</p>
        </div>
    </a>
    <a href="/ai-tools" class="feature-link">
        <div class="feature">
            <div class="feature-icon">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 12h.01M12 12h.01M19 12h.01M6 12a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0z" />
                </svg>
            </div>
            <h3 class="feature-title">See More Tools</h3>
            <p class="feature-description">Explore our complete collection of AI-powered content creation and optimization tools.</p>
        </div>
    </a>
</section>

      <!-- Testimonials Section -->
    <section class="testimonials">
        <div class="testimonials-header">
            <h2 class="testimonials-title">What Our Users Say</h2>
            <p class="testimonials-subtitle">See how our platform is transforming content creation workflows for businesses worldwide</p>
        </div>
        <div class="testimonials-grid">
            <div class="testimonial">
                <p class="testimonial-content">"This platform has completely transformed how our marketing team creates content. We've seen a 300% increase in productivity while maintaining high-quality standards."</p>
                <div class="testimonial-author">
                    <img src="/api/placeholder/64/64" alt="Sarah Johnson" class="author-avatar">
                    <div class="author-details">
                        <div class="author-name">Sarah Johnson</div>
                        <div class="author-title">Marketing Director, TechCorp</div>
                    </div>
                </div>
            </div>
            <div class="testimonial">
                <p class="testimonial-content">"As a solo entrepreneur, this tool has been a game-changer. I can now produce professional-quality content in minutes instead of hours, allowing me to focus on growing my business."</p>
                <div class="testimonial-author">
                    <img src="/api/placeholder/64/64" alt="Michael Chen" class="author-avatar">
                    <div class="author-details">
                        <div class="author-name">Michael Chen</div>
                        <div class="author-title">Founder, GrowthHackers</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="brands">
        <h4 class="brands-title">Trusted by Innovative Brands</h4>
        <div class="brand-logos">
            <img src="/api/placeholder/150/50" alt="Brand 1" class="brand-logo">
            <img src="/api/placeholder/150/50" alt="Brand 2" class="brand-logo">
            <img src="/api/placeholder/150/50" alt="Brand 3" class="brand-logo">
            <img src="/api/placeholder/150/50" alt="Brand 4" class="brand-logo">
            <img src="/api/placeholder/150/50" alt="Brand 5" class="brand-logo">
        </div>
    </section>

<?php include 'homepage/pricing.php'; ?>

    <!-- Call to Action Bottom -->
    <section class="cta-bottom">
        <h2 class="cta-bottom-title">Ready to Transform Your Content Strategy?</h2>
        <p class="cta-bottom-subtitle">Join thousands of content creators, marketers, and businesses who are revolutionizing their content creation process.</p>
        <a href="/register" class="btn btn-white">Start Your Free Trial Today</a>
    </section>

    <?php include 'homepage/faqs.php'; ?>

</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Intersection Observer for animations
    const statElements = document.querySelectorAll('.stat');
    
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -100px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);
    
    statElements.forEach(stat => {
        observer.observe(stat);
    });
});
</script>

<?php include 'footer.php'; ?>