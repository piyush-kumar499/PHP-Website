<?php
session_start();
require_once('../private/config.php');
require_once('../private/db.php');
require_once('../private/auth.php');
require_once('../private/login_tracker.php');
checkAndRecordLogin(); // Check and record the login if needed

// Check if user is logged in
requireLogin();

// Get current user data
$currentUser = getCurrentUser();
$userId = $currentUser['id'];

// Fetch user details from database to get the most up-to-date information
$user = dbSelectOne("SELECT * FROM users WHERE id = ?", [$userId]);

// Generate CSRF token for forms
$csrfToken = generateCSRFToken();

// Success and error message variables
$successMessage = '';
$errorMessage = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token for all form submissions
    if (!verifyCSRFToken($_POST['csrf_token'])) {
        $errorMessage = "Security verification failed. Please try again.";
    } else {
        // Handle password change
        if (isset($_POST['change_password'])) {
            $currentPassword = $_POST['current_password'] ?? '';
            $newPassword = $_POST['new_password'] ?? '';
            $confirmPassword = $_POST['confirm_password'] ?? '';
            
            // Verify current password
            if (!password_verify($currentPassword, $user['password'])) {
                $errorMessage = "Current password is incorrect.";
            } elseif (strlen($newPassword) < 8) {
                $errorMessage = "New password must be at least 8 characters long.";
            } elseif ($newPassword !== $confirmPassword) {
                $errorMessage = "New passwords do not match.";
            } else {
                // Hash new password and update in database
                $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                $result = dbExecute(
                    "UPDATE users SET password = ? WHERE id = ?",
                    [$hashedPassword, $userId]
                );
                
                if ($result !== false) {
                    $successMessage = "Password changed successfully.";
                } else {
                    $errorMessage = "Failed to update password. Please try again.";
                }
            }
        }
        
        // Handle account deletion schedule
        elseif (isset($_POST['schedule_deletion'])) {
            // Get password for verification
            $password = $_POST['deletion_password'] ?? '';
            
            // Check if password is empty
            if (empty($password)) {
                $errorMessage = "Please enter your password to confirm account deletion.";
            } else {
                // Verify the user's password
                if (!password_verify($password, $user['password'])) {
                    $errorMessage = "Incorrect password. Account deletion cancelled.";
                } else {
                    // Set scheduled deletion date (30 days from now)
                    $deletionDate = new DateTime();
                    $deletionDate->add(new DateInterval('P30D'));
                    
                    $result = dbExecute(
                        "UPDATE users SET scheduled_deletion = ? WHERE id = ?",
                        [$deletionDate->format('Y-m-d H:i:s'), $userId]
                    );
                    
                    if ($result !== false) {
                        $successMessage = "Account deletion scheduled. Your account will be permanently deleted in 30 days.";
                        // Refresh user data
                        $user = dbSelectOne("SELECT * FROM users WHERE id = ?", [$userId]);
                    } else {
                        $errorMessage = "Failed to schedule account deletion. Please try again.";
                    }
                }
            }
        }
        
        // Handle cancellation of scheduled deletion
        elseif (isset($_POST['cancel_deletion'])) {
            $result = dbExecute(
                "UPDATE users SET scheduled_deletion = NULL WHERE id = ?",
                [$userId]
            );
            
            if ($result !== false) {
                $successMessage = "Account deletion cancelled. Your account will remain active.";
                // Refresh user data
                $user = dbSelectOne("SELECT * FROM users WHERE id = ?", [$userId]);
            } else {
                $errorMessage = "Failed to cancel account deletion. Please try again.";
            }
        }
        
        // Handle privacy settings update
        elseif (isset($_POST['update_privacy'])) {
            $profileVisibility = $_POST['profile_visibility'] ?? 'public';
            $activityTracking = isset($_POST['activity_tracking']) ? 1 : 0;
            $emailNotifications = isset($_POST['email_notifications']) ? 1 : 0;
            
            // Update privacy settings in database
            $result = dbExecute(
                "UPDATE user_settings SET 
                 profile_visibility = ?, 
                 activity_tracking = ?, 
                 email_notifications = ? 
                 WHERE user_id = ?",
                [$profileVisibility, $activityTracking, $emailNotifications, $userId]
            );
            
            // If no settings exist yet, insert new settings
            if ($result === false || dbAffectedRows() === 0) {
                $result = dbExecute(
                    "INSERT INTO user_settings (user_id, profile_visibility, activity_tracking, email_notifications) 
                     VALUES (?, ?, ?, ?)",
                    [$userId, $profileVisibility, $activityTracking, $emailNotifications]
                );
            }
            
            if ($result !== false) {
                $successMessage = "Privacy settings updated successfully.";
            } else {
                $errorMessage = "Failed to update privacy settings. Please try again.";
            }
        }
        
        // Handle account upgrade request
        elseif (isset($_POST['upgrade_account'])) {
            // In a real application, this would handle payment processing
            // For now, we'll just redirect to a payment page
            header("Location: /payment?plan=premium");
            exit;
        }
        
        // Handle support request
        elseif (isset($_POST['send_support_request'])) {
            $supportSubject = $_POST['support_subject'] ?? '';
            $supportMessage = $_POST['support_message'] ?? '';
            
            if (empty($supportSubject) || empty($supportMessage)) {
                $errorMessage = "Please fill in all fields for your support request.";
            } else {
                // In a real application, this would send the support request to a system or email
                // For now, we'll just save it to the database
                $result = dbExecute(
                    "INSERT INTO support_tickets (user_id, subject, message, status, created_at) 
                     VALUES (?, ?, ?, 'open', NOW())",
                    [$userId, $supportSubject, $supportMessage]
                );
                
                if ($result !== false) {
                    $successMessage = "Your support request has been submitted. We'll get back to you soon.";
                } else {
                    $errorMessage = "Failed to submit support request. Please try again.";
                }
            }
        }
    }
}

// Get user membership level
$userLevel = $user['user_level'] ?? USER_LEVEL_BASIC;
$userLevelName = '';

switch ($userLevel) {
    case USER_LEVEL_PREMIUM:
        $userLevelName = 'Premium Member';
        break;
    case USER_LEVEL_ADMIN:
        $userLevelName = 'Administrator';
        break;
    default:
        $userLevelName = 'Basic Member';
}

// Check if account is scheduled for deletion
$deletionScheduled = !empty($user['scheduled_deletion']);
$daysRemaining = 0;
$deletionDate = null;

if ($deletionScheduled) {
    $deletionDate = new DateTime($user['scheduled_deletion']);
    $now = new DateTime();
    $daysRemaining = $now->diff($deletionDate)->days;
}

// Get user's privacy settings
$privacySettings = dbSelectOne(
    "SELECT * FROM user_settings WHERE user_id = ?",
    [$userId]
);

// Set default privacy values if no settings exist
if (!$privacySettings) {
    $privacySettings = [
        'profile_visibility' => 'public',
        'activity_tracking' => 1,
        'email_notifications' => 1
    ];
}

// Determine if user has 2FA enabled
$has2FA = false;
if (isset($user['two_factor_enabled']) && $user['two_factor_enabled']) {
    $has2FA = true;
}

// Premium benefits list for upgrade section
$premiumBenefits = [
    ['icon' => 'fas fa-bolt', 'title' => 'Faster Processing', 'description' => 'Get priority access to all tools and faster processing times.'],
    ['icon' => 'fas fa-ban', 'title' => 'Ad-Free Experience', 'description' => 'Enjoy an ad-free experience across the entire platform.'],
    ['icon' => 'fas fa-tools', 'title' => 'Premium Tools', 'description' => 'Access exclusive premium-only tools and features.'],
    ['icon' => 'fas fa-headset', 'title' => 'Priority Support', 'description' => 'Get priority customer support with faster response times.']
];

include 'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include_once ('../private/favicon.php'); ?>
    <title>Settings - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="/assets/css/settings-protected.css">
    <!-- Add Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

<style>
@keyframes fadeOut {
    from { opacity: 1; }
    to { opacity: 0; }
}

.fade-out {
    animation: fadeOut 0.5s ease forwards;
}

.alert {
    transition: opacity 0.5s ease;
}
</style>
</head>
<body>
    <div class="settings-app-container">
    <div class="dashboard-container">
        <div class="dashboard-header">
            <div class="user-welcome">
                <h1>Account Settings</h1>
                <p>Manage your account security, privacy, and preferences</p>
            </div>
            <div class="dashboard-actions">
                <a href="/profile" class="btn"><i class="fas fa-user" style="margin-right: 5px;"></i> View Profile</a>
                <a href="/" class="btn btn-outline"><i class="fa fa-home" style="margin-right: 5px;"></i> Home</a>
            </div>
        </div>
        
        <?php if (!empty($successMessage)): ?>
        <div class="alert alert-success">
            <?php echo $successMessage; ?>
        </div>
        <?php endif; ?>
        
        <?php if (!empty($errorMessage)): ?>
        <div class="alert alert-danger">
            <?php echo $errorMessage; ?>
        </div>
        <?php endif; ?>
        
        <?php if ($deletionScheduled): ?>
        <div class="alert alert-warning">
            <p><strong>Your account is scheduled for deletion on <?php echo $deletionDate->format('F j, Y'); ?></strong></p>
            <p>Your account will be permanently deleted in <?php echo $daysRemaining; ?> day<?php echo $daysRemaining != 1 ? 's' : ''; ?>.</p>
            <form method="post" action="settings">
                <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                <button type="submit" name="cancel_deletion" class="btn btn-sm">Cancel Account Deletion</button>
            </form>
        </div>
        <?php endif; ?>
        
        <!-- Navigation tabs for settings sections -->
        <div class="settings-navigation">
            <a href="#security" class="settings-tab active" data-tab="security">
                <i class="fas fa-lock"></i> Security & Privacy
            </a>
            <a href="#account-management" class="settings-tab" data-tab="account-management">
                <i class="fas fa-user-cog"></i> Account Management
            </a>
            <a href="#help-support" class="settings-tab" data-tab="help-support">
                <i class="fas fa-question-circle"></i> Help & Support
            </a>
        </div>
        
        <div class="settings-content">
            <!-- Security & Privacy Section -->
            <div id="security" class="settings-section active">
                <!-- Change Password Card -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3><i class="fas fa-key"></i> Change Password</h3>
                    </div>
                    <div class="card-content">
                        <form method="post" action="settings" class="settings-form">
                            <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                            
                            <div class="form-group">
                                <label for="current_password">Current Password</label>
                                <input type="password" id="current_password" name="current_password" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="new_password">New Password</label>
                                <input type="password" id="new_password" name="new_password" required>
                                <small>Password must be at least 8 characters long</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="confirm_password">Confirm New Password</label>
                                <input type="password" id="confirm_password" name="confirm_password" required>
                            </div>
                            
                            <button type="submit" name="change_password" class="btn btn-primary">Update Password</button>
                        </form>
                    </div>
                </div>
                
                <!-- Two-Factor Authentication Card -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3><i class="fas fa-shield-alt"></i> Two-Factor Authentication</h3>
                    </div>
                    <div class="card-content">
                        <div class="feature-status">
                            <div class="status-label">Status:</div>
                            <div class="status-value">
                                <?php if ($has2FA): ?>
                                    <span class="status-enabled"><i class="fas fa-check-circle"></i> Enabled</span>
                                <?php else: ?>
                                    <span class="status-disabled"><i class="fas fa-times-circle"></i> Disabled</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <p>Two-factor authentication adds an extra layer of security to your account by requiring a verification code in addition to your password.</p>
                        
                        <?php if ($has2FA): ?>
                            <a href="/manage-2fa" class="btn btn-outline">Manage 2FA</a>
                            <a href="/disable-2fa" class="btn btn-danger">Disable 2FA</a>
                        <?php else: ?>
                            <a href="/setup-2fa" class="btn btn-primary">Set Up 2FA</a>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Privacy Settings Card -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3><i class="fas fa-user-shield"></i> Privacy Preferences</h3>
                    </div>
                    <div class="card-content">
                        <form method="post" action="settings" class="settings-form">
                            <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                            
                            <div class="form-group">
                                <label for="profile_visibility">Profile Visibility</label>
                                <select id="profile_visibility" name="profile_visibility">
                                    <option value="public" <?php echo ($privacySettings['profile_visibility'] == 'public') ? 'selected' : ''; ?>>Public - Everyone can see your profile</option>
                                    <option value="members" <?php echo ($privacySettings['profile_visibility'] == 'members') ? 'selected' : ''; ?>>Members Only - Only registered users can see your profile</option>
                                    <option value="private" <?php echo ($privacySettings['profile_visibility'] == 'private') ? 'selected' : ''; ?>>Private - Only you can see your profile</option>
                                </select>
                            </div>
                            
                            <div class="form-group checkbox-group">
                                <input type="checkbox" id="activity_tracking" name="activity_tracking" <?php echo ($privacySettings['activity_tracking'] == 1) ? 'checked' : ''; ?>>
                                <label for="activity_tracking">Allow Activity Tracking</label>
                                <small>We use this data to improve your experience and provide personalized recommendations</small>
                            </div>
                            
                            <div class="form-group checkbox-group">
                                <input type="checkbox" id="email_notifications" name="email_notifications" <?php echo ($privacySettings['email_notifications'] == 1) ? 'checked' : ''; ?>>
                                <label for="email_notifications">Email Notifications</label>
                                <small>Receive updates about account activity, new features, and promotions</small>
                            </div>
                            
                            <button type="submit" name="update_privacy" class="btn btn-primary">Save Privacy Settings</button>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- Account Management Section -->
            <div id="account-management" class="settings-section">
                <!-- Membership Level Card -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3><i class="fas fa-award"></i> Membership Level</h3>
                    </div>
                    <div class="card-content">
                        <div class="membership-info">
                            <div class="current-plan">
                                <h4>Current Plan</h4>
                                <div class="plan-badge <?php echo $userLevel == USER_LEVEL_PREMIUM ? 'premium' : 'basic'; ?>">
                                    <?php echo $userLevelName; ?>
                                </div>
                            </div>
                            
                            <?php if ($userLevel != USER_LEVEL_PREMIUM && $userLevel != USER_LEVEL_ADMIN): ?>
                            <div class="upgrade-section">
                                <h4>Upgrade to Premium</h4>
                                <div class="premium-benefits">
                                    <?php foreach ($premiumBenefits as $benefit): ?>
                                    <div class="benefit-item">
                                        <div class="benefit-icon">
                                            <i class="<?php echo $benefit['icon']; ?>"></i>
                                        </div>
                                        <div class="benefit-info">
                                            <h5><?php echo $benefit['title']; ?></h5>
                                            <p><?php echo $benefit['description']; ?></p>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                                
                                <form method="post" action="settings">
                                    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                                    <button type="submit" name="upgrade_account" class="btn btn-premium">
                                        <i class="fas fa-crown"></i> Upgrade Now
                                    </button>
                                </form>
                            </div>
                            <?php else: ?>
                            <div class="premium-active">
                                <p>You are currently enjoying all premium benefits. Thank you for your support!</p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Account Deletion Card -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3><i class="fas fa-user-slash"></i> Account Deletion</h3>
                    </div>
                    <div class="card-content">
                        <div class="deletion-info">
                            <div class="deletion-warning-info">
                                <h4>What You Should Know Before Deleting Your Account</h4>
                                <ul>
                                    <li>Account deletion is scheduled to occur 30 days after your request.</li>
                                    <li>During this 30-day period, you can log in and cancel the deletion at any time.</li>
                                    <li>Once your account is deleted, all your personal data will be permanently deleted.</li>
                                    <li>Your profile information, favorites, activity history, and uploaded content will be erased.</li>
                                    <li>This action cannot be undone after the 30-day period.</li>
                                </ul>
                            </div>
                            
                            <?php if ($deletionScheduled): ?>
                            <div class="deletion-scheduled">
                                <p><strong>Your account is scheduled for deletion on <?php echo $deletionDate->format('F j, Y'); ?></strong></p>
                                <p>Your account will be permanently deleted in <?php echo $daysRemaining; ?> day<?php echo $daysRemaining != 1 ? 's' : ''; ?>.</p>
                                
                                <form method="post" action="settings">
                                    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                                    <button type="submit" name="cancel_deletion" class="btn btn-primary">Cancel Account Deletion</button>
                                </form>
                            </div>
                            <?php else: ?>
                            <div class="deletion-warning">
                                <p><strong>Warning:</strong> This action cannot be undone after the 30-day period.</p>
                                
                                <button type="button" id="delete-account-btn" class="btn btn-danger">Schedule Account Deletion</button>
                                
                                <div id="delete-confirmation" class="confirmation-dialog hidden">
                                    <form method="post" action="settings" id="delete-account-form">
                                        <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                                        <p>Are you sure you want to schedule your account for deletion?</p>
                                        <div class="form-group">
                                            <label for="deletion_password">Please enter your password to confirm:</label>
                                            <input type="password" name="deletion_password" id="deletion_password" required>
                                        </div>
                                        <div class="confirmation-actions">
                                            <button type="submit" name="schedule_deletion" class="btn btn-danger">Yes, Delete My Account</button>
                                            <button type="button" id="cancel-delete-btn" class="btn btn-outline">Cancel</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
                    
            <!-- Help & Support Section -->
            <div id="help-support" class="settings-section">
                
         <!-- FAQ Card -->
 <?php include 'settings1/settings-faqs.php'; ?>
                <!-- Contact Support Card -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3><i class="fas fa-headset"></i> Contact Support</h3>
                    </div>
                    <div class="card-content">
                        <p>Need help with something not covered in the FAQ? Our support team is here to help.</p>
                        
                        <form method="post" action="settings" class="support-form">
                            <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                            
                            <div class="form-group">
                                <label for="support_subject">Subject</label>
                                <input type="text" id="support_subject" name="support_subject" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="support_message">Message</label>
                                <textarea id="support_message" name="support_message" rows="5" required></textarea>
                            </div>
                            
                            <button type="submit" name="send_support_request" class="btn btn-primary">Send Message</button>
                        </form>
                    </div>
                </div>
                
                <!-- Support Resources Card -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3><i class="fas fa-book"></i> Resources</h3>
                    </div>
                    <div class="card-content">
                        <div class="resources-list">
                            <a href="/docs/user-guide" class="resource-item">
                                <i class="fas fa-file-alt"></i>
                                <span>User Guide</span>
                            </a>
                            <a href="/docs/tutorials" class="resource-item">
                                <i class="fas fa-video"></i>
                                <span>Video Tutorials</span>
                            </a>
                            <a href="/docs/api" class="resource-item">
                                <i class="fas fa-code"></i>
                                <span>API Documentation</span>
                            </a>
                            <a href="/blog/tips" class="resource-item">
                                <i class="fas fa-lightbulb"></i>
                                <span>Tips & Tricks</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 </div>
    
   
    
    <!-- JavaScript for settings page functionality -->
    <script>
        // Tab navigation functionality
        document.addEventListener('DOMContentLoaded', function() {
            const tabs = document.querySelectorAll('.settings-tab');
            const sections = document.querySelectorAll('.settings-section');
            
            tabs.forEach(tab => {
                tab.addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    // Remove active class from all tabs and sections
                    tabs.forEach(t => t.classList.remove('active'));
                    sections.forEach(s => s.classList.remove('active'));
                    
                    // Add active class to clicked tab
                    this.classList.add('active');
                    
                    // Show corresponding section
                    const targetId = this.getAttribute('data-tab');
                    document.getElementById(targetId).classList.add('active');
                    
                    // Update URL hash
                    window.location.hash = targetId;
                });
            });
            
            // Check for hash in URL on page load
            const hash = window.location.hash.substring(1);
            if (hash && document.getElementById(hash)) {
                tabs.forEach(t => t.classList.remove('active'));
                sections.forEach(s => s.classList.remove('active'));
                
                document.querySelector(`.settings-tab[data-tab="${hash}"]`).classList.add('active');
                document.getElementById(hash).classList.add('active');
            }
        });
        
        // Account deletion confirmation dialog
        document.addEventListener('DOMContentLoaded', function() {
            const deleteBtn = document.getElementById('delete-account-btn');
            const cancelBtn = document.getElementById('cancel-delete-btn');
            const confirmationDialog = document.getElementById('delete-confirmation');
            
            if (deleteBtn && cancelBtn && confirmationDialog) {
                deleteBtn.addEventListener('click', function() {
                    confirmationDialog.classList.remove('hidden');
                    this.style.display = 'none';
                });
                
                cancelBtn.addEventListener('click', function() {
                    confirmationDialog.classList.add('hidden');
                    deleteBtn.style.display = 'block';
                });
            }
        });

// Function to auto-hide alert messages
document.addEventListener('DOMContentLoaded', function() {
    // Target all alert messages
    const alerts = document.querySelectorAll('.alert:not(.alert-warning');
    
    if (alerts.length > 0) {
        setTimeout(function() {
            alerts.forEach(function(alert) {
                alert.classList.add('fade-out');
         
                setTimeout(function() {
                    if (alert.parentNode) {
                        alert.style.display = 'none';
                    }
                }, 500);
            });
        }, 3000);
    }
});
    </script>
</body>
</html>