<?php
session_start();
require_once('../private/config.php');
require_once('../private/db.php');
require_once('../private/auth.php');

// Check if user is logged in
requireLogin();

// Initialize response array
$response = array(
    'success' => false,
    'message' => 'An error occurred'
);

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    // Get current user data
    $currentUser = getCurrentUser();
    $userId = $currentUser['id'];
    
    // Verify CSRF token
    if (!verifyCSRFToken($_POST['csrf_token'])) {
        $response['message'] = "Security verification failed. Please try again.";
    } else {
        $name = trim($_POST['name'] ?? '');
        $bio = trim($_POST['bio'] ?? '');
        
        // Validate inputs
        if (empty($name)) {
            $response['message'] = "Name cannot be empty.";
        } else {
            // Update user profile
            $result = dbExecute(
                "UPDATE users SET name = ?, bio = ? WHERE id = ?",
                [$name, $bio, $userId]
            );
            
            if ($result !== false) {
                // Update successful
                $response['success'] = true;
                $response['message'] = "Profile updated successfully.";
                $response['name'] = $name;
                $response['bio'] = $bio;
                
                // Update session data
                $_SESSION['user_name'] = $name;
            } else {
                $response['message'] = "Failed to update profile. Please try again.";
            }
        }
    }
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
exit;
?>