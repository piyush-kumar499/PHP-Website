<?php
session_start();
require_once('../private/config.php');
require_once('../private/db.php');
require_once('../private/auth.php');
require_once('../private/login_tracker.php'); // Add this line

/**
 * Extract readable browser and OS information from user agent
 * @param string $userAgent User agent string
 * @return string Formatted browser and OS info
 */
function getBrowserInfo($userAgent) {
    // Default values
    $browser = "Unknown Browser";
    $platform = "Unknown OS";
    
    // Detect platform
    if (preg_match('/linux/i', $userAgent)) {
        $platform = 'Linux';
    } elseif (preg_match('/macintosh|mac os x/i', $userAgent)) {
        $platform = 'macOS';
    } elseif (preg_match('/windows|win32/i', $userAgent)) {
        $platform = 'Windows';
    } elseif (preg_match('/android/i', $userAgent)) {
        $platform = 'Android';
    } elseif (preg_match('/iphone|ipad/i', $userAgent)) {
        $platform = 'iOS';
    }
    
    // Detect browser
    if (preg_match('/MSIE|Trident/i', $userAgent)) {
        $browser = 'Internet Explorer';
    } elseif (preg_match('/Firefox/i', $userAgent)) {
        $browser = 'Firefox';
    } elseif (preg_match('/Chrome/i', $userAgent) && !preg_match('/Edg|Edge/i', $userAgent)) {
        $browser = 'Chrome';
    } elseif (preg_match('/Safari/i', $userAgent) && !preg_match('/Chrome|Edg|Edge/i', $userAgent)) {
        $browser = 'Safari';
    } elseif (preg_match('/Edg|Edge/i', $userAgent)) {
        $browser = 'Edge';
    } elseif (preg_match('/Opera|OPR/i', $userAgent)) {
        $browser = 'Opera';
    }
    
    return "$browser on $platform";
}

// Check for login and record if needed
checkAndRecordLogin();

// Check if user is logged in
requireLogin();

// Clean up old tool usage records (older than 7 days)
cleanupOldToolUsage(7);

// Clean up old login history records (older than 30 days)
cleanupOldLoginHistory(30);

// Get current user data
$currentUser = getCurrentUser();
$userId = $currentUser['id'];

// Fetch user details from database to get the most up-to-date information
$user = dbSelectOne("SELECT * FROM users WHERE id = ?", [$userId]);

// Generate CSRF token for profile icon selection
$csrfToken = generateCSRFToken();

// Initialize message variables
$imageMessage = '';
$imageError = '';

// Handle profile icon selection
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['select_icon'])) {
    // Verify CSRF token
    if (!verifyCSRFToken($_POST['csrf_token'])) {
        $imageError = "Security verification failed. Please try again.";
    } else {
        // Check if icon was selected
        if (isset($_POST['selected_icon']) && !empty($_POST['selected_icon'])) {
            $selectedIcon = $_POST['selected_icon'];
            
            // Validate the selected icon (ensure it's from our predefined list)
            // The value stored will be the CSS class or path depending on your implementation
            
            // Update user profile with selected icon
            $result = dbExecute(
                "UPDATE users SET profile_image = ? WHERE id = ?",
                [$selectedIcon, $userId]
            );
            
            if ($result !== false) {
                $imageMessage = "Profile icon updated successfully.";
                // Refresh user data
                $user = dbSelectOne("SELECT * FROM users WHERE id = ?", [$userId]);
            } else {
                $imageError = "Failed to update profile icon in database.";
            }
        } else {
            $imageError = "Please select an icon.";
        }
    }
}

// Check if table exists first to avoid errors
function tableExists($tableName) {
    $result = dbSelectOne(
        "SELECT COUNT(*) as count FROM information_schema.tables 
         WHERE table_schema = ? AND table_name = ?",
        [DB_NAME, $tableName]
    );
    return $result && $result['count'] > 0;
}

// Fetch user's favorite tools
$favoriteTools = dbSelect(
    "SELECT t.id, t.name, t.description, t.icon 
     FROM tools t 
     JOIN user_favorites uf ON t.id = uf.tool_id 
     WHERE uf.user_id = ? 
     ORDER BY uf.date_added DESC 
     LIMIT 6",
    [$userId]
);

// Fetch user's recent tool usage (last 7 days only)
$recentToolUsage = dbSelect(
    "SELECT t.id, t.name, tu.used_at 
     FROM tools t 
     JOIN tool_usage tu ON t.id = tu.tool_id 
     WHERE tu.user_id = ? AND tu.used_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
     ORDER BY tu.used_at DESC",
    [$userId]
);

// Initialize variables to prevent undefined variable errors
if (!tableExists('user_favorites') || !tableExists('tools')) {
    $favoriteTools = [];
}

if (!tableExists('tool_usage') || !tableExists('tools')) {
    $recentToolUsage = [];
}

// Get user membership level
$userLevel = $user['user_level'] ?? USER_LEVEL_BASIC;
$userLevelName = '';

switch ($userLevel) {
    case USER_LEVEL_PREMIUM:
        $userLevelName = 'Premium Member';
        break;
    case USER_LEVEL_ADMIN:
        $userLevelName = 'Administrator';
        break;
    default:
        $userLevelName = 'Basic Member';
}

// Format registration date
$registrationDate = new DateTime($user['registration_date']);
$memberSince = $registrationDate->format('F j, Y');

// Count user stats
$totalToolsUsed = dbSelectOne(
    "SELECT COUNT(DISTINCT tool_id) as count FROM tool_usage WHERE user_id = ?",
    [$userId]
);

$totalFavorites = dbSelectOne(
    "SELECT COUNT(*) as count FROM user_favorites WHERE user_id = ?",
    [$userId]
);

// Get total tools used and favorites count
$toolsUsedCount = $totalToolsUsed ? $totalToolsUsed['count'] : 0;
$favoritesCount = $totalFavorites ? $totalFavorites['count'] : 0;

// Calculate account status
$accountStatus = "Active";
if (isset($user['is_active']) && !$user['is_active']) {
    $accountStatus = "Inactive";
}

// Check if account is scheduled for deletion for notification purposes
$deletionScheduled = !empty($user['scheduled_deletion']);
$daysRemaining = 0;
$deletionDate = null;

if ($deletionScheduled) {
    $deletionDate = new DateTime($user['scheduled_deletion']);
    $now = new DateTime();
    $daysRemaining = $now->diff($deletionDate)->days;
    $accountStatus = "Scheduled for Deletion";
}

// Check if user has achievements (assuming you have an achievements system)
$hasAchievements = tableExists('user_achievements');
$achievements = [];

if ($hasAchievements) {
    $achievements = dbSelect(
        "SELECT a.name, a.description, a.icon, ua.earned_at 
         FROM achievements a 
         JOIN user_achievements ua ON a.id = ua.achievement_id 
         WHERE ua.user_id = ? 
         ORDER BY ua.earned_at DESC 
         LIMIT 5",
        [$userId]
    );
}

// Fetch total login count
$loginCount = dbSelectOne(
    "SELECT COUNT(*) as count FROM user_logins WHERE user_id = ?",
    [$userId]
);
$totalLogins = $loginCount ? $loginCount['count'] : 0;

// Get last login date (previous login, not current)
$lastLogin = dbSelectOne(
    "SELECT login_time FROM user_logins WHERE user_id = ? 
     ORDER BY login_time DESC LIMIT 1 OFFSET 1", // This gets the previous login, not the current one
    [$userId]
);

// Instead of showing "First Login", show blank when no previous login exists
if (!$lastLogin) {
    $lastLoginDate = 'Inactive for 30 days'; 
} else {
    $lastLoginDate = (new DateTime($lastLogin['login_time']))->format('F j, Y - g:i:s a');
}

// Fetch user's login history (last 30 days only)
$loginHistory = dbSelect(
    "SELECT login_time, ip_address, user_agent 
     FROM user_logins 
     WHERE user_id = ? AND login_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)
     ORDER BY login_time DESC",
    [$userId]
);

// Define available profile icons
$profileIcons = [
    'user-1' => 'fas fa-user',
    'user-tie' => 'fas fa-user-tie',
    'user-graduate' => 'fas fa-user-graduate',
    'user-astronaut' => 'fas fa-user-astronaut',
    'user-ninja' => 'fas fa-user-ninja',
    'user-secret' => 'fas fa-user-secret',
    'cat' => 'fas fa-cat',
    'dog' => 'fas fa-dog',
    'dragon' => 'fas fa-dragon',
    'robot' => 'fas fa-robot',
    'code' => 'fas fa-code',
    'brain' => 'fas fa-brain',
    'rocket' => 'fas fa-rocket',
    'atom' => 'fas fa-atom',
    'coffee' => 'fas fa-coffee',
    'laptop' => 'fas fa-laptop-code'
];

include 'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include_once ('../private/favicon.php'); ?>
    <title>Profile - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="/assets/css/profile-protected.css">
    <!-- Add Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
/* Edit profile form styles */
.profile-edit-form {
    padding: 1.5rem;
    background-color: #f9f9f9;
    border-radius: 0.5rem;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
    margin-top: 1rem;
}

.profile-edit-form h3 {
    margin-top: 0;
    margin-bottom: 1.5rem;
    color: #333;
    font-size: 1.25rem;
}

.form-group {
    margin-bottom: 1.5rem;
}

.form-group label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 500;
    color: #333;
}

.form-group input,
.form-group textarea {
    width: 100%;
    padding: 0.75rem;
    border: 1px solid #ddd;
    border-radius: 0.25rem;
    font-size: 1rem;
    transition: border-color 0.2s;
}

.form-group input:focus,
.form-group textarea:focus {
    outline: none;
    border-color: #4a90e2;
    box-shadow: 0 0 0 2px rgba(74, 144, 226, 0.2);
}

.form-help {
    font-size: 0.875rem;
    color: #666;
    margin-top: 0.25rem;
}

.form-actions {
    display: flex;
    gap: 1rem;
    margin-top: 1.5rem;
}

/* Animation for form transitions */
#profile-info-view, #profile-edit-form {
    transition: opacity 0.3s ease-in-out, display 0.3s ease-in-out;
}

.alert {
    padding: 0.75rem 1rem;
    margin-bottom: 1rem;
    border-radius: 0.25rem;
    font-size: 0.875rem;
}

.alert-success {
    background-color: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}

.alert-danger {
    background-color: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}

/* Modal styles */
.modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  z-index: 1000;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 20px;
  box-sizing: border-box;
}

.modal-content {
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
  width: 100%;
  max-width: 600px;
  max-height: 80vh;
  overflow-y: auto;
  animation: modalFadeIn 0.3s ease-out;
  margin: auto;
}

@keyframes modalFadeIn {
  from { opacity: 0; transform: scale(0.95); }
  to { opacity: 1; transform: scale(1); }
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 20px;
  border-bottom: 1px solid #e5e5e5;
  position: sticky;
  top: 0;
  background-color: #fff;
  z-index: 5;
}

.modal-header h3 {
  margin: 0;
  color: #333;
  font-size: 1.2rem;
}

.close-modal {
  font-size: 24px;
  cursor: pointer;
  color: #777;
  transition: color 0.2s;
  padding: 5px;
  line-height: 0.8;
}

.close-modal:hover {
  color: #333;
}

.modal-body {
  padding: 20px;
}

/* Icon selection grid */
.icon-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(70px, 1fr));
  gap: 15px;
  margin-bottom: 20px;
}

.icon-option {
  width: 100%;
  aspect-ratio: 1/1;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  background-color: #f5f5f5;
  transition: all 0.2s ease;
  border: 2px solid transparent;
  box-sizing: border-box;
}

.icon-option:hover {
  background-color: #e9e9e9;
  transform: scale(1.05);
}

.icon-option i {
  font-size: 24px;
  color: #555;
}

.icon-option.selected {
  border-color: #4a90e2;
  background-color: #e6f0fc;
}

.icon-option.selected i {
  color: #4a90e2;
}

/* Form actions in modal */
.form-actions {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 15px;
  padding: 15px 20px;
  border-top: 1px solid #e5e5e5;
  background-color: #f9f9f9;
  position: sticky;
  bottom: 0;
}

/* Responsive adjustments */
@media (max-width: 768px) {
  .modal-content {
    max-height: 90vh;
  }
  
  .icon-grid {
    grid-template-columns: repeat(auto-fill, minmax(60px, 1fr));
    gap: 10px;
  }
  
  .modal-header h3 {
    font-size: 1.1rem;
  }
  
  .form-actions {
    flex-direction: column;
  }
  
  .form-actions button {
    width: 100%;
  }
}

@media (max-width: 480px) {
  .modal {
    padding: 10px;
  }
  
  .icon-grid {
    grid-template-columns: repeat(auto-fill, minmax(50px, 1fr));
    gap: 8px;
  }
  
  .icon-option i {
    font-size: 20px;
  }
  
  .modal-header, .modal-body {
    padding: 12px 15px;
  }
}

/* Override sidebar layout at all screen sizes */
.profile-app-container .dashboard-grid {
    display: flex !important;
    flex-direction: column !important;
    gap: 2rem !important;
    width: 100% !important;
}

.profile-app-container .dashboard-main,
.profile-app-container .dashboard-sidebar {
    width: 100% !important;
    max-width: none !important;
    flex: 1 1 auto !important;
}

/* These will override any existing media queries */
@media (min-width: 768px) {
    .profile-app-container .dashboard-grid {
        display: flex !important;
        flex-direction: column !important;
    }
    
    .profile-app-container .dashboard-main,
    .profile-app-container .dashboard-sidebar {
        width: 100% !important;
        max-width: none !important;
    }
}

@media (min-width: 992px) {
    .profile-app-container .dashboard-grid {
        display: flex !important;
        flex-direction: column !important;
    }
    
    .profile-app-container .dashboard-main,
    .profile-app-container .dashboard-sidebar {
        width: 100% !important;
        max-width: none !important;
    }
}

@media (min-width: 1200px) {
    .profile-app-container .dashboard-grid {
        display: flex !important;
        flex-direction: column !important;
    }
    
    .profile-app-container .dashboard-main,
    .profile-app-container .dashboard-sidebar {
        width: 100% !important;
        max-width: none !important;
    }
}
    </style>
</head>
<body>
   <div class="profile-app-container">  
    <div class="dashboard-container">
        <div class="dashboard-header">
            <div class="user-welcome">
                <h1>My Profile</h1>
                <p>View and manage your profile information</p>
            </div>
            <div class="dashboard-actions">
                <a href="/settings" class="btn"><i class="fas fa-cog" style="margin-right: 5px;"></i> Settings</a>
                <a href="/tools" class="btn btn-outline"><i class="fas fa-tools" style="margin-right: 5px;"></i> Explore Tools</a>
            </div>
        </div>
        
        <?php if ($deletionScheduled): ?>
        <div class="alert alert-warning">
            <p><strong>Your account is scheduled for deletion on <?php echo $deletionDate->format('F j, Y'); ?></strong></p>
            <p>Your account will be permanently deleted in <?php echo $daysRemaining; ?> day<?php echo $daysRemaining != 1 ? 's' : ''; ?>. 
            <a href="/settings#account-management" class="btn btn-sm">Manage Account Deletion</a></p>
        </div>
        <?php endif; ?>
        
        <div class="dashboard-grid">
            <div class="dashboard-main">
                <!-- Profile Overview Card -->
                <div class="dashboard-card profile-card">
                    <div class="profile-header-bg"></div>
                    <div class="profile-image-container">
                        <div class="profile-image">
                            <?php if (!empty($user['profile_image']) && strpos($user['profile_image'], 'fa-') !== false): ?>
                                <i class="<?php echo htmlspecialchars($user['profile_image']); ?>"></i>
                            <?php else: ?>
                                <?php echo strtoupper(substr($user['name'], 0, 1)); ?>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Icon selection button -->
                        <button type="button" class="btn btn-outline btn-sm" id="choose-icon-btn">
                            <i class="fas fa-icons"></i> Choose Profile Image
                        </button>
                        
                        <?php if (!empty($imageMessage)): ?>
                            <div class="alert alert-success"><?php echo $imageMessage; ?></div>
                        <?php endif; ?>
                        
                        <?php if (!empty($imageError)): ?>
                            <div class="alert alert-danger"><?php echo $imageError; ?></div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Profile Info (visible when not editing) -->
                    <div class="profile-info" id="profile-info-view">
                        <h3><?php echo htmlspecialchars($user['name']); ?></h3>
                        <div class="user-level-badge">
                            <span><?php echo $userLevelName; ?></span>
                        </div>
                        <p class="user-email"><?php echo htmlspecialchars($user['email']); ?></p>
                        <p class="user-bio">
                            <?php if (!empty($user['bio'])): ?>
                                <?php echo htmlspecialchars($user['bio']); ?>
                            <?php else: ?>
                                <em>No bio added yet. Tell us about yourself!</em>
                            <?php endif; ?>
                        </p>
                        
                        <button type="button" class="btn btn-outline btn-sm" id="edit-profile-btn">
                            <i class="fas fa-user-edit"></i> Edit Profile
                        </button>
                    </div>
                    
                    <!-- Edit Profile Form (hidden by default) -->
                    <div class="profile-edit-form" id="profile-edit-form" style="display: none;">
                        <h3>Edit Profile</h3>
                        
                        <div id="update-message-container"></div>
                        
                        <form id="edit-profile-form">
                            <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                            
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                                <div class="form-help">Your display name on the platform</div>
                            </div>
                            
                            <div class="form-group">
                                <label for="email">Email Address</label>
                                <input type="email" id="email" value="<?php echo htmlspecialchars($user['email']); ?>" disabled>
                                <div class="form-help">You cannot change your email address</div>
                            </div>
                            
                            <div class="form-group">
                                <label for="bio">Bio</label>
                                <textarea id="bio" name="bio" rows="4"><?php echo htmlspecialchars($user['bio'] ?? ''); ?></textarea>
                                <div class="form-help">Tell us about yourself in a few sentences</div>
                            </div>
                            
                            <div class="form-actions">
                                <button type="submit" name="update_profile" class="btn btn-primary">Save Changes</button>
                                <button type="button" class="btn btn-secondary" id="cancel-edit-btn">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Achievements Section (New) -->
                <?php if ($hasAchievements && !empty($achievements)): ?>
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3><i class="fas fa-trophy"></i> Achievements</h3>
                    </div>
                    <div class="card-content">
                        <ul class="achievements-list">
                            <?php foreach ($achievements as $achievement): ?>
                                <li class="achievement-item">
                                    <div class="achievement-icon">
                                        <i class="<?php echo htmlspecialchars($achievement['icon']); ?>"></i>
                                    </div>
                                    <div class="achievement-details">
                                        <span class="achievement-name"><?php echo htmlspecialchars($achievement['name']); ?></span>
                                        <p class="achievement-desc"><?php echo htmlspecialchars($achievement['description']); ?></p>
                                        <span class="achievement-date">
                                            Earned on <?php echo (new DateTime($achievement['earned_at']))->format('M j, Y'); ?>
                                        </span>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="dashboard-sidebar">
                <!-- Account Status Section -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3><i class="fas fa-user-check"></i> Account Status</h3>
                    </div>
                    <div class="card-content">
                        <div class="stat-item">
                            <div class="stat-label">Membership Level</div>
                            <div class="stat-value"><?php echo $userLevelName; ?></div>
                        </div>
               <div class="stat-item">
    <div class="stat-label">Account Status</div>
    <div class="stat-value">
        <?php if ($accountStatus == "Active"): ?>
            <span class="status-badge status-active">Active</span>
        <?php elseif ($accountStatus == "Inactive"): ?>
            <span class="status-badge status-inactive">Inactive</span>
        <?php elseif ($accountStatus == "Scheduled for Deletion"): ?>
            <span class="status-badge status-scheduled">Scheduled for Deletion</span>
        <?php else: ?>
            <?php echo $accountStatus; ?>
        <?php endif; ?>
    </div>
</div>
                        <div class="stat-item">
                            <div class="stat-label">Member Since</div>
                            <div class="stat-value"><?php echo $memberSince; ?></div>
                        </div>
                   <div class="stat-item">
    <div class="stat-label">Last Login</div>
    <div class="stat-value"><?php echo $lastLoginDate; ?></div>
</div>
                        
                        <?php if ($userLevel == USER_LEVEL_BASIC): ?>
                        <div class="upgrade-section">
                            <a href="/settings#account-management" class="btn btn-primary">
                                <i class="fas fa-crown"></i> Upgrade to Premium
                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- User Stats Section -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3><i class="fas fa-chart-line"></i> Activity Stats</h3>
                    </div>
                    <div class="card-content">
                        <div class="stat-item">
                            <div class="stat-label">Tools Used</div>
                            <div class="stat-value"><?php echo $toolsUsedCount; ?></div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-label">Favorites</div>
                            <div class="stat-value"><?php echo $favoritesCount; ?></div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-label">Total Logins</div>
                            <div class="stat-value"><?php echo $totalLogins; ?></div>
                        </div>
                    </div>
                </div>
                
                <!-- Favorite Tools Section -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3><i class="fas fa-star"></i> Favorite Tools</h3>
                    </div>
                    <div class="card-content">
                        <?php if (!empty($favoriteTools)): ?>
                            <div class="favorite-tools-grid">
                                <?php foreach ($favoriteTools as $tool): ?>
                                    <a href="/tool?id=<?php echo $tool['id']; ?>" class="tool-card">
                                        <div class="tool-icon">
                                            <i class="<?php echo htmlspecialchars($tool['icon']); ?>"></i>
                                        </div>
                                        <div class="tool-name"><?php echo htmlspecialchars($tool['name']); ?></div>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <p>You haven't favorited any tools yet. Explore our tools and add some to your favorites!</p>
                            <a href="/tools" class="btn btn-outline btn-sm">Browse Tools</a>
                        <?php endif; ?>
                    </div>
                </div>
 
      <!-- Recent Tool Usage Section -->
<div class="dashboard-card">
    <div class="card-header">
        <h3><i class="fas fa-history"></i> Recent Activity (Last 7 Days)</h3>
    </div>
    <div class="card-content">
        <?php if (!empty($recentToolUsage)): ?>
            <div class="activity-list-container">
                <ul class="activity-list">
                    <?php foreach ($recentToolUsage as $usage): ?>
                        <li>
                            <div class="activity-icon">
                                <i class="fas fa-tools"></i>
                            </div>
                            <div class="activity-details">
                                <span class="activity-name">Used <?php echo htmlspecialchars($usage['name']); ?></span>
                                <span class="activity-date">
                                    <?php 
    $usageTime = new DateTime($usage['used_at']);
    echo $usageTime->format('M j, Y - g:i:s a'); 
?>
                                </span>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <div class="activity-notice">
                <p class="activity-info-text"><small><i class="fas fa-info-circle"></i> Only showing activity from the past 7 days. Older activity is automatically removed.</small></p>
            </div>
        <?php else: ?>
            <p>No tools used in the past 7 days. Start exploring our tools!</p>
            <a href="/tools" class="btn btn-outline btn-sm">Browse Tools</a>
        <?php endif; ?>
    </div>
</div>
                
          <!-- Login History Section -->
<div class="dashboard-card">
    <div class="card-header">
        <h3><i class="fas fa-sign-in-alt"></i> Login History (Last 30 Days)</h3>
    </div>
    <div class="card-content">
        <?php if (!empty($loginHistory)): ?>
            <div class="activity-list-container">
                <ul class="activity-list">
                    <?php 
                    // First record is the current session
                    $currentSessionIndex = 0;
                    foreach ($loginHistory as $index => $login): 
                    ?>
                        <li>
                            <div class="activity-icon">
                                <i class="fas fa-user-clock"></i>
                            </div>
                            <div class="activity-details">
                                <span class="activity-name">
                                    Login Session
                                    <?php if ($index === $currentSessionIndex): ?>
                                        <span class="active-badge">Active</span>
                                    <?php endif; ?>
                                </span>
                                <span class="activity-date">
                                    <?php 
                                        $loginTime = new DateTime($login['login_time']);
                                        echo $loginTime->format('M j, Y - g:i:s a'); 
                                    ?>
                                </span>
                                <div class="login-details">
                                    <small>
                                        <i class="fas fa-map-marker-alt"></i> IP: <?php echo htmlspecialchars($login['ip_address']); ?>
                                        <?php if (!empty($login['user_agent'])): ?>
                                            <br><i class="fas fa-laptop"></i> <?php echo htmlspecialchars(getBrowserInfo($login['user_agent'])); ?>
                                        <?php endif; ?>
                                    </small>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
           <div class="activity-notice">
                <p class="activity-info-text"><small><i class="fas fa-info-circle"></i> Showing your login sessions from the past 30 days. Older records are automatically removed.</small></p>
            </div>
        <?php else: ?>
            <p>No login history available.</p>
        <?php endif; ?>
    </div>
</div>
            </div> 
        </div>
    </div>
    

    <!-- Profile Icon Selection Modal -->
    <div id="icon-selection-modal" class="modal" style="display: none;">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Choose Profile Image</h3>
                <span class="close-modal">&times;</span>
            </div>
            <div class="modal-body">
                <form method="post" action="profile" id="icon-selection-form">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                    <input type="hidden" name="selected_icon" id="selected_icon_input">
                    
                    <div class="icon-grid">
                        <?php foreach ($profileIcons as $id => $iconClass): ?>
                            <div class="icon-option" data-icon="<?php echo htmlspecialchars($iconClass); ?>">
                                <i class="<?php echo htmlspecialchars($iconClass); ?>"></i>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" name="select_icon" class="btn btn-primary">Save Selection</button>
                        <button type="button" class="btn btn-secondary" id="cancel-icon-selection">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
 </div>   
    
    <!-- JavaScript for profile page functionality -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Elements
            const editProfileBtn = document.getElementById('edit-profile-btn');
            const cancelEditBtn = document.getElementById('cancel-edit-btn');
            const profileInfoView = document.getElementById('profile-info-view');
            const profileEditForm = document.getElementById('profile-edit-form');
            const editProfileForm = document.getElementById('edit-profile-form');
            const updateMessageContainer = document.getElementById('update-message-container');
            
            // Show edit form
            if (editProfileBtn) {
                editProfileBtn.addEventListener('click', function() {
                    profileInfoView.style.display = 'none';
                    profileEditForm.style.display = 'block';
                    
                    // Scroll to the edit form
                    profileEditForm.scrollIntoView({behavior: 'smooth'});
                });
            }
            
            // Hide edit form
            if (cancelEditBtn) {
                cancelEditBtn.addEventListener('click', function() {
                    profileInfoView.style.display = 'block';
                    profileEditForm.style.display = 'none';
                    updateMessageContainer.innerHTML = '';
                });
            }
            
            // Handle form submission
            if (editProfileForm) {
                editProfileForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    
                    // Prepare form data
                    const formData = new FormData();
                    formData.append('csrf_token', editProfileForm.querySelector('[name="csrf_token"]').value);
                    formData.append('name', editProfileForm.querySelector('[name="name"]').value);
                    formData.append('bio', editProfileForm.querySelector('[name="bio"]').value);
                    formData.append('update_profile', '1');
                    
                    // Create and send AJAX request
                    fetch('/profile_update_handler', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    
                    
                    
                    
                    
                .then(data => {
    if (data.success) {
        // Show success message
        updateMessageContainer.innerHTML = '<div class="alert alert-success">' + data.message + '</div>';
        
        // Call the auto-hide function for the new message
        setupAutoHideMessages();
        
        // Update visible profile information
        document.querySelector('.profile-info h3').textContent = data.name;
        
        // Update bio
        const userBio = document.querySelector('.user-bio');
        if (data.bio) {
            userBio.textContent = data.bio;
        } else {
            userBio.innerHTML = '<em>No bio added yet. Tell us about yourself!</em>';
        }
        
        // Hide edit form after 2 seconds
        setTimeout(function() {
            profileInfoView.style.display = 'block';
            profileEditForm.style.display = 'none';
        }, 2000);
    } else {
        // Show error message
        updateMessageContainer.innerHTML = '<div class="alert alert-danger">' + data.message + '</div>';
        
        // Call the auto-hide function for the new message
        setupAutoHideMessages();
    }
})
.catch(error => {
    console.error('Error:', error);
    updateMessageContainer.innerHTML = '<div class="alert alert-danger">An error occurred. Please try again.</div>';
    
    // Call the auto-hide function for the new message
    setupAutoHideMessages();
});
                });
            }
            
            // Icon selection functionality
            const iconSelectionModal = document.getElementById('icon-selection-modal');
            const chooseIconBtn = document.getElementById('choose-icon-btn');
            const cancelIconSelection = document.getElementById('cancel-icon-selection');
            const closeModalBtn = document.querySelector('.close-modal');
            const iconOptions = document.querySelectorAll('.icon-option');
            const selectedIconInput = document.getElementById('selected_icon_input');
            const iconSelectionForm = document.getElementById('icon-selection-form');
            
            // Show icon selection modal
            if (chooseIconBtn) {
                chooseIconBtn.addEventListener('click', function() {
                    iconSelectionModal.style.display = 'block';
                });
            }
            
            // Hide icon selection modal
            if (cancelIconSelection) {
                cancelIconSelection.addEventListener('click', function() {
                    iconSelectionModal.style.display = 'none';
                });
            }
            
            if (closeModalBtn) {
                closeModalBtn.addEventListener('click', function() {
                    iconSelectionModal.style.display = 'none';
                });
            }
            
            // Close modal when clicking outside
            window.addEventListener('click', function(e) {
                if (e.target === iconSelectionModal) {
                    iconSelectionModal.style.display = 'none';
                }
            });
            
            // Icon selection
            iconOptions.forEach(option => {
                option.addEventListener('click', function() {
                    // Remove selection from all icons
                    iconOptions.forEach(opt => opt.classList.remove('selected'));
                    
                    // Add selection to clicked icon
                    this.classList.add('selected');
                    
                    // Store selected icon value
                    selectedIconInput.value = this.dataset.icon;
                });
            });
            
            // Add animation class to elements after page load
            const activityItems = document.querySelectorAll('.activity-list li');
            activityItems.forEach((item, index) => {
                item.style.animationDelay = `${0.1 * index}s`;
                item.style.animation = 'fadeIn 0.5s ease-out forwards';
                item.style.opacity = '0';
            });
            
            const achievementItems = document.querySelectorAll('.achievement-item');
            achievementItems.forEach((item, index) => {
                item.style.animationDelay = `${0.1 * index}s`;
                item.style.animation = 'fadeIn 0.5s ease-out forwards';
                item.style.opacity = '0';
            });
            
            const statItems = document.querySelectorAll('.stat-item');
            statItems.forEach((item, index) => {
                item.style.animationDelay = `${0.05 * index}s`;
                item.style.animation = 'fadeIn 0.5s ease-out forwards';
                item.style.opacity = '0';
            });
        });

        // Add this inside your existing document.addEventListener('DOMContentLoaded', function() { ... });
const loginHistoryItems = document.querySelectorAll('.activity-list li');
loginHistoryItems.forEach((item, index) => {
    item.style.animationDelay = `${0.1 * index}s`;
    item.style.animation = 'fadeIn 0.5s ease-out forwards';
    item.style.opacity = '0';
});

// Function to auto-hide alert messages
function setupAutoHideMessages() {
    // Target all alert messages
    const alertMessages = document.querySelectorAll('.alert:not(.alert-warning');
    
    if (alertMessages.length > 0) {
        alertMessages.forEach(function(message) {
        
            setTimeout(function() {
        message.classList.add('fade-out');
         
                setTimeout(function() {
                    if (message.parentNode) {
                        message.remove();
                    }
                }, 500);
            }, 5000);
        });
    }
}

// Call the function when the page loads to handle existing messages
setupAutoHideMessages();
    </script>
</body>
</html>