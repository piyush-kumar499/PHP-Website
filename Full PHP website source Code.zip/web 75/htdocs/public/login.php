<?php
session_start();
require_once('../private/config.php');
require_once('../private/db.php');
require_once('../private/auth.php'); 

// Check if user is already logged in
if (isLoggedIn()) {
    header("Location: /");
    exit();
}

$error = '';
$blockInfo = null;
$verificationRequired = false;
$userEmail = '';

// Get the user's IP address
$userIP = $_SERVER['REMOTE_ADDR'];

// Check if the user is blocked before processing the form
$email = isset($_POST['email']) ? $_POST['email'] : '';
if (!empty($email)) {
    $blockStatus = checkLoginBlock($email, $userIP);
    if ($blockStatus['blocked']) {
        $blockInfo = $blockStatus;
    }
}

// Process login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$blockInfo) {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    
    // Validate inputs
    if (empty($email) || empty($password)) {
        $error = "Please fill in all required fields.";
    } else {
        // Attempt to login the user
        $result = loginUser($email, $password, $userIP);
        
        if ($result === true) {
            require_once('../private/messages.php');
    
    // Set success message
    set_success_message('Welcome back! You have successfully logged in.');

            // Redirect to homepage on successful login
            header("Location: /");
            exit();
        } elseif (is_array($result)) {
            if (isset($result['blocked'])) {
                // User is blocked
                $blockInfo = $result;
            } elseif (isset($result['requires_verification'])) {
                // User needs email verification
                $verificationRequired = true;
                $userEmail = $email;
                $_SESSION['pending_verification_email'] = $email;
            }
        } else {
            $error = $result; // Error message returned from login function
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include_once ('../private/favicon.php'); ?>
    <title>Login Page - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="/asssets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <style>
/* General Styles */
body {
    font-family: Arial, sans-serif;
    background: #f4f7f6;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}

/* Authentication Container */
.auth-container {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    width: 100%;
    padding: 10px;
}

.auth-form {
    background: #ffffff;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 400px;
    text-align: center;
}

/* Title */
.auth-form h1 {
    font-size: 24px;
    color: #4a00e0;
    font-weight: 700;
    background: linear-gradient(to right, #8e2de2, #4a00e0);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin-bottom: 20px;
}

/* Error Message */
.error-message {
    background: rgba(255, 0, 0, 0.1);
    color: #d9534f;
    padding: 10px;
    border-radius: 5px;
    margin-bottom: 15px;
    font-size: 14px;
}

/* Block Message */
.block-message {
    background: rgba(255, 152, 0, 0.1);
    color: #ff9800;
    padding: 15px;
    border-radius: 5px;
    margin-bottom: 15px;
    font-size: 14px;
    text-align: left;
    border-left: 4px solid #ff9800;
}

.countdown {
    font-weight: bold;
    color: #ff5722;
}

/* Form Group */
.form-group {
    margin-bottom: 15px;
    text-align: left;
}

label {
    display: block;
    font-weight: bold;
    margin-bottom: 5px;
    color: #333;
}

input[type="email"],
input[type="password"],
input[type="text"] {
    width: 100%;
    max-width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
    box-sizing: border-box;
}

input[type="email"]:focus,
input[type="password"]:focus,
input[type="text"]:focus {
    border-color: #8e2de2;
    outline: none;
}

/* Remember Me */
.remember-me {
    display: flex;
    align-items: center;
    font-size: 14px;
}

.remember-me input {
    margin-right: 5px;
}

/* Login Button */
.btn-primary {
    display: inline-block;
    width: 100%;
    padding: 12px;
    font-size: 16px;
    font-weight: 600;
    text-align: center;
    color: #ffffff;
    background: linear-gradient(to right, #8e2de2, #4a00e0);
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease-in-out;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    position: relative;
    overflow: hidden;
    z-index: 1;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 15px rgba(142, 45, 226, 0.4);
    background: linear-gradient(to right, #7d28c7, #3900c9);
}

.btn-primary::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(to right, rgba(255, 255, 255, 0), rgba(255, 255, 255, 0.3), rgba(255, 255, 255, 0));
    transition: all 0.5s ease;
    z-index: -1;
}

.btn-primary:hover::before {
    left: 100%;
}

.btn-primary:active {
    transform: translateY(0);
    box-shadow: 0 3px 4px rgba(0, 0, 0, 0.15);
}

/* Authentication Links */
.auth-links {
    margin-top: 15px;
}

.auth-links p {
    font-size: 14px;
    color: #333;
}

.auth-links a {
    color: #8e2de2;
    font-weight: 600;
    text-decoration: none;
    transition: color 0.3s ease-in-out;
}

.auth-links a:hover {
    color: #4a00e0;
    text-decoration: underline;
}

/* Responsive Design */
@media (max-width: 480px) {
    .auth-form {
        padding: 20px;
        width: 90%;
    }

    .btn-primary {
        font-size: 14px;
        padding: 10px;
    }
}

/* Disabled Form Elements */
input:disabled {
    background-color: #f5f5f5;
    color: #999;
    cursor: not-allowed;
}

button:disabled {
    background: linear-gradient(to right, #cccccc, #aaaaaa) !important;
    cursor: not-allowed;
    transform: none !important;
    box-shadow: none !important;
}

button:disabled::before {
    display: none;
}

/* Modal Overlay */
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 1000;
    visibility: hidden;
    opacity: 0;
    transition: visibility 0s linear 0.25s, opacity 0.25s;
}

.modal-overlay.active {
    visibility: visible;
    opacity: 1;
    transition-delay: 0s;
}

/* Verification Modal */
.verification-modal {
    background: white;
    padding: 30px;
    border-radius: 8px;
    box-shadow: 0px 5px 20px rgba(0, 0, 0, 0.2);
    max-width: 400px;
    width: 90%;
    text-align: center;
    position: relative;
    transform: scale(0.7);
    transition: transform 0.3s;
}

.modal-overlay.active .verification-modal {
    transform: scale(1);
}

.verification-modal h2 {
    margin-top: 0;
    color: #4a00e0;
    font-size: 20px;
}

.verification-modal p {
    margin-bottom: 20px;
    color: #555;
    font-size: 14px;
    line-height: 1.5;
}

.btn-verify {
    background: linear-gradient(to right, #8e2de2, #4a00e0);
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s;
}

.btn-verify:hover {
    box-shadow: 0 4px 10px rgba(142, 45, 226, 0.4);
    transform: translateY(-2px);
}

.close-modal {
    position: absolute;
    top: 10px;
    right: 10px;
    background: none;
    border: none;
    font-size: 18px;
    color: #888;
    cursor: pointer;
}

.close-modal:hover {
    color: #333;
}
    </style>
</head>
<body>
    
    <div class="auth-container">
        <div class="auth-form">
            <h1>Login to Your Account</h1>
            
            <?php if ($blockInfo): ?>
                <div class="block-message">
                    <p><strong>Account temporarily locked</strong></p>
                    <p>Too many failed login attempts. Please try again after <span class="countdown" data-seconds="<?php echo $blockInfo['time_remaining']; ?>"><?php echo $blockInfo['readable_time']; ?></span>.</p>
                </div>
            <?php elseif (!empty($error)): ?>
                <div class="error-message"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <form method="post" action="login" id="login-form">
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" required <?php echo $blockInfo ? 'disabled' : ''; ?>>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required <?php echo $blockInfo ? 'disabled' : ''; ?>>
                </div>
                
                <div class="form-group remember-me">
                    <input type="checkbox" id="remember" name="remember" <?php echo $blockInfo ? 'disabled' : ''; ?>>
                    <label for="remember">Remember me</label>
                </div>
                
                <button type="submit" class="btn btn-primary" <?php echo $blockInfo ? 'disabled' : ''; ?>>Login</button>
            </form>
            
            <div class="auth-links">
                <p>Don't have an account? <a href="/register">Register</a></p>
                <p><a href="/forgot-password">Forgot Password?</a></p>
            </div>
        </div>
    </div>
    
    <!-- Verification Modal -->
    <div class="modal-overlay" id="verification-modal-overlay">
        <div class="verification-modal">
            <button class="close-modal">&times;</button>
            <h2>Email Verification Required</h2>
            <p>Your account has not been verified yet. Please verify your email address to continue.</p>
            <form action="/verify_otp" method="get">
             <input type="hidden" name="user_id" value="<?php echo $userIdToVerify; ?>">
                <button type="submit" class="btn-verify">Verify Email</button>
            </form>
        </div>
    </div>
    
    <script src="/assets/js/main.js"></script>
    <script src="/assets/js/auth.js"></script>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Countdown timer for blocked accounts
        const countdownElements = document.querySelectorAll('.countdown');
        countdownElements.forEach(function(element) {
            let secondsRemaining = parseInt(element.getAttribute('data-seconds'));
            
            const countdownTimer = setInterval(function() {
                secondsRemaining--;
                
                if (secondsRemaining <= 0) {
                    clearInterval(countdownTimer);
                    location.reload(); // Reload the page when countdown finishes
                } else {
                    // Format time
                    const hours = Math.floor(secondsRemaining / 3600);
                    const minutes = Math.floor((secondsRemaining % 3600) / 60);
                    const seconds = secondsRemaining % 60;
                    
                    let timeString = '';
                    if (hours > 0) {
                        timeString = `${hours} hour${hours !== 1 ? 's' : ''} ${minutes} minute${minutes !== 1 ? 's' : ''}`;
                    } else if (minutes > 0) {
                        timeString = `${minutes} minute${minutes !== 1 ? 's' : ''} ${seconds} second${seconds !== 1 ? 's' : ''}`;
                    } else {
                        timeString = `${seconds} second${seconds !== 1 ? 's' : ''}`;
                    }
                    
                    element.textContent = timeString;
                }
            }, 1000);
        });
        
        // Verification modal
        const showVerificationModal = <?php echo $verificationRequired ? 'true' : 'false'; ?>;
        const modalOverlay = document.getElementById('verification-modal-overlay');
        const closeModalBtn = document.querySelector('.close-modal');
        
        if (showVerificationModal) {
            modalOverlay.classList.add('active');
        }
        
        if (closeModalBtn) {
            closeModalBtn.addEventListener('click', function() {
                modalOverlay.classList.remove('active');
            });
        }
    });
    </script>
</body>
</html>