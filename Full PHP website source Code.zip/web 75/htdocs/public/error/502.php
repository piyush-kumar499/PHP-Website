<?php
// Set page variables
$pageTitle = "Bad Gateway | AI Tools Platform";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include_once ('../../private/favicon.php'); ?>
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <style>
        :root {
            --primary-color: #4F46E5;
            --secondary-color: #7C3AED;
            --dark-color: #1E293B;
            --light-color: #F8FAFC;
            --accent-color: #06B6D4;
            --success-color: #10B981;
            --warning-color: #F59E0B;
            --error-color: #EF4444;
            --border-radius: 8px;
            --box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        }
        
        body {
            background-color: var(--light-color);
            color: var(--dark-color);
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        
        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 1rem;
            text-align: center;
        }
        
        .error-container {
            background-color: #fff;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: clamp(1.5rem, 5vw, 3rem) clamp(1rem, 3vw, 2rem);
            margin: 1rem auto;
            max-width: 800px;
            width: 95%;
        }
        
        .error-icon {
            font-size: clamp(3rem, 8vw, 6rem);
            margin-bottom: clamp(0.75rem, 2vw, 1.5rem);
            background: linear-gradient(to right, var(--primary-color), var(--error-color));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-fill-color: transparent;
        }
        
        .error-code {
            font-size: clamp(2.5rem, 6vw, 3.5rem);
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(to right, var(--primary-color), var(--error-color));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-fill-color: transparent;
        }
        
        .error-title {
            font-size: clamp(1.5rem, 4vw, 2rem);
            margin-bottom: clamp(0.5rem, 1.5vw, 1rem);
            color: var(--dark-color);
        }
        
        .error-message {
            font-size: clamp(0.9rem, 2vw, 1.1rem);
            color: #64748B;
            margin-bottom: clamp(1rem, 3vw, 2rem);
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
            padding: 0 0.5rem;
        }
        
        .error-actions {
            display: flex;
            flex-direction: column;
            gap: 1rem;
            align-items: center;
            margin-top: clamp(1rem, 3vw, 2rem);
        }
        
        .primary-button {
            display: inline-block;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 0.75rem 2rem;
            border-radius: 30px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 220px;
            text-align: center;
        }
        
        .primary-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
        }
        
        .secondary-button {
            display: inline-block;
            background-color: transparent;
            color: var(--primary-color);
            padding: 0.75rem 2rem;
            border-radius: 30px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            border: 2px solid var(--primary-color);
            width: 100%;
            max-width: 220px;
            text-align: center;
        }
        
        .secondary-button:hover {
            background-color: rgba(79, 70, 229, 0.1);
            transform: translateY(-3px);
        }
        
        .error-illustration {
            max-width: 400px;
            margin: 0 auto 2rem;
            position: relative;
            height: 250px;
            background: linear-gradient(135deg, #EEF2FF, #E0E7FF);
            border-radius: var(--border-radius);
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }
        
        .error-path {
            display: flex;
            align-items: center;
            justify-content: center;
            margin: clamp(1rem, 3vw, 2rem) 0;
            flex-wrap: wrap;
            gap: 0.25rem;
        }
        
        .path-item {
            color: #64748B;
            font-size: clamp(0.85rem, 1.5vw, 0.95rem);
        }
        
        .path-separator {
            margin: 0 0.25rem;
            color: #CBD5E1;
        }
        
        .suggestions {
            margin-top: clamp(1rem, 3vw, 2rem);
            text-align: left;
            max-width: 500px;
            margin-left: auto;
            margin-right: auto;
            padding: 0 0.5rem;
        }
        
        .suggestion-title {
            font-size: clamp(1rem, 2.5vw, 1.2rem);
            margin-bottom: 1rem;
            color: var(--dark-color);
        }
        
        .suggestion-list {
            list-style-type: none;
        }
        
        .suggestion-list li {
            margin-bottom: 0.75rem;
            color: #64748B;
            display: flex;
            align-items: flex-start;
            font-size: clamp(0.85rem, 1.8vw, 1rem);
        }
        
        .suggestion-list li i {
            color: var(--primary-color);
            margin-right: 0.75rem;
            margin-top: 0.25rem;
            min-width: 1rem;
        }
        
        .redirect-message {
            margin-top: clamp(1rem, 3vw, 2rem);
            color: #64748B;
            font-size: clamp(0.85rem, 1.8vw, 1rem);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            flex-wrap: wrap;
        }
        
        .redirect-timer {
            font-weight: 700;
            color: var(--primary-color);
            min-width: 2rem;
            display: inline-block;
        }
        
        /* Animation for the dots */
        .loading-dots span {
            display: inline-block;
            animation: dots 1.5s infinite;
            font-size: 1.5rem;
            line-height: 0;
            position: relative;
            top: -3px;
        }
        
        .loading-dots span:nth-child(2) {
            animation-delay: 0.3s;
        }
        
        .loading-dots span:nth-child(3) {
            animation-delay: 0.6s;
        }
        
        @keyframes dots {
            0%, 20% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-5px);
            }
            80%, 100% {
                transform: translateY(0);
            }
        }
        
        /* Animation for the pulse */
        .pulse {
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% {
                transform: scale(1);
            }
            50% {
                transform: scale(1.05);
            }
            100% {
                transform: scale(1);
            }
        }
        
        /* Improve touch targets for mobile */
        @media (max-width: 767px) {
            .primary-button, .secondary-button {
                padding: 0.9rem 2rem;
                font-size: 1.05rem;
            }
            
            .error-actions {
                margin-bottom: 1.5rem;
            }
            
            .suggestion-list li {
                margin-bottom: 1rem;
            }
        }
        
        @media (min-width: 768px) {
            .error-actions {
                flex-direction: row;
                justify-content: center;
            }
            
            .container {
                padding: 2rem;
            }
            
            .error-container {
                margin: 2rem auto;
            }
        }
        
        @media (prefers-reduced-motion: reduce) {
            * {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
                scroll-behavior: auto !important;
            }
        }
        
        /* Dark mode support */
        @media (prefers-color-scheme: dark) {
            :root {
                --light-color: #0F172A;
                --dark-color: #E2E8F0;
            }
            
            body {
                background-color: var(--light-color);
                color: var(--dark-color);
            }
            
            .error-container {
                background-color: #1E293B;
                box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.3), 0 4px 6px -2px rgba(0, 0, 0, 0.2);
            }
            
            .error-title {
                color: #F1F5F9;
            }
            
            .error-message, .path-item, .suggestion-list li {
                color: #94A3B8;
            }
            
            .suggestion-title {
                color: #F1F5F9;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="error-container">
            <div class="error-icon">
                <i class="fas fa-exchange-alt"></i>
            </div>
            
            <h1 class="error-code">502</h1>
            <h2 class="error-title">Bad Gateway</h2>
            <p class="error-message">
                We're having trouble connecting to our servers. This is usually a temporary issue due to high traffic or maintenance. 
                Please wait a moment and try again.
            </p>
            
            <div class="error-path">
                <span class="path-item">Home</span>
                <span class="path-separator"><i class="fas fa-chevron-right"></i></span>
                <span class="path-item">Connection Issue</span>
                <span class="path-separator"><i class="fas fa-chevron-right"></i></span>
                <span class="path-item">502 Error</span>
            </div>
            
            <div class="suggestions">
                <h3 class="suggestion-title">What you can do:</h3>
                <ul class="suggestion-list">
                    <li>
                        <i class="fas fa-clock"></i>
                        <span>Wait a few minutes and try again</span>
                    </li>
                    <li>
                        <i class="fas fa-redo-alt"></i>
                        <span>Refresh the page</span>
                    </li>
                    <li>
                        <i class="fas fa-wifi"></i>
                        <span>Check your internet connection</span>
                    </li>
                    <li>
                        <i class="fas fa-exclamation-triangle"></i>
                        <span>If the problem persists, our system might be undergoing maintenance</span>
                    </li>
                </ul>
            </div>
            
            <div class="error-actions">
                <a href="/" class="primary-button">
                    <i class="fas fa-home"></i> Back to Home
                </a>
                <a href="#" class="secondary-button">
                    <i class="fas fa-chart-line"></i> System Status
                </a>
            </div>
            
            <div class="redirect-message">
                <i class="fas fa-sync-alt fa-spin"></i>
                <span>Retrying connection in <span id="countdown-timer" class="redirect-timer">10</span> seconds</span>
            </div>
        </div>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Fade in animation for the error container
            const errorContainer = document.querySelector('.error-container');
            errorContainer.style.opacity = 0;
            errorContainer.style.transform = 'translateY(20px)';
            errorContainer.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            
            setTimeout(() => {
                errorContainer.style.opacity = 1;
                errorContainer.style.transform = 'translateY(0)';
            }, 100);
            
            // Check for reduced motion preference
            const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
            
            if (!prefersReducedMotion) {
                // Staggered animation for the suggestion list
                const suggestionItems = document.querySelectorAll('.suggestion-list li');
                suggestionItems.forEach((item, index) => {
                    item.style.opacity = 0;
                    item.style.transform = 'translateX(20px)';
                    item.style.transition = `opacity 0.5s ease ${index * 0.1}s, transform 0.5s ease ${index * 0.1}s`;
                    
                    setTimeout(() => {
                        item.style.opacity = 1;
                        item.style.transform = 'translateX(0)';
                    }, 500 + (index * 100));
                });
            } else {
                // If reduced motion is preferred, make everything visible immediately
                document.querySelectorAll('.suggestion-list li').forEach(item => {
                    item.style.opacity = 1;
                    item.style.transform = 'translateX(0)';
                });
            }
            
            // Automatic retry with countdown timer
            let timeLeft = 10; // 10 seconds countdown
            const timerElement = document.getElementById('countdown-timer');
            
            const countdownInterval = setInterval(() => {
                timeLeft--;
                timerElement.textContent = timeLeft;
                
                if (timeLeft <= 0) {
                    clearInterval(countdownInterval);
                    window.location.href = '/';
                }
                
                // Add pulse animation when timer gets to 3 seconds or less
                if (timeLeft <= 3 && !prefersReducedMotion) {
                    timerElement.classList.add('pulse');
                }
            }, 1000);
            
            // Pause countdown when user interacts with the page
            const interactiveElements = document.querySelectorAll('a, button');
            interactiveElements.forEach(element => {
                element.addEventListener('click', function() {
                    clearInterval(countdownInterval);
                    const redirectMessage = document.querySelector('.redirect-message');
                    redirectMessage.innerHTML = '<i class="fas fa-pause"></i> Auto-retry paused due to user interaction';
                });
            });
        });
    </script>
</body>
</html>