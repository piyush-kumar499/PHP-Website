<div class="pricing-module-container">
    <style>
    .pricing-module-container {
        margin: 0;
        padding: 0;
        width: 100%;
        box-sizing: border-box;
    }
    
    .pricing-module-container * {
        box-sizing: border-box;
    }
    
    .pricing-module-container .pricing-container {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        line-height: 1.6; 
        color: #1a202c;
        background: linear-gradient(to right, #864ae8, #4c8df6);
        margin: 0; 
        padding: 1rem 0.2rem;
        border-radius: 0.5rem;
    }
    
    /* Pricing Header */
    .pricing-module-container .pricing-header {
        text-align: center;
        margin-bottom: 1rem;
        background-color: #ffffff;
        border-radius: 1rem;
        padding: 1.5rem;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
    }
    
    .pricing-module-container .pricing-title {
        font-size: 2.5rem;
        font-weight: 700;
        color: #1a202c;
        margin-bottom: 0.5rem;
        margin-top: 0;
        background: linear-gradient(to right, #6a11cb, #2575fc);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }
    
    .pricing-module-container .pricing-subtitle {
        color: #4a5568;
        max-width: 600px;
        margin: 0 auto;
        font-size: 1.25rem;
    }
    
    /* Pricing Toggle */
    .pricing-module-container .pricing-toggle {
        display: flex;
        justify-content: center;
        align-items: center;
        margin-bottom: 1rem;
        background-color: rgba(255, 255, 255, 0.2);
        padding: 0.5rem;
        border-radius: 2rem;
        width: fit-content;
        margin-left: auto;
        margin-right: auto;
    }
    
    .pricing-module-container .pricing-toggle-option {
        padding: 0.5rem 1.5rem;
        background: transparent;
        color: white;
        cursor: pointer;
        border: none;
        font-size: 1rem;
        border-radius: 2rem;
        transition: all 0.3s ease;
    }
    
    .pricing-module-container .pricing-toggle-option.active {
        background-color: rgba(255, 255, 255, 0.9);
        color: #6b46c1;
        font-weight: 600;
    }
    
    /* Pricing Plans */
    .pricing-module-container .pricing-plans {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 1.5rem;
        margin-bottom: 1rem;
        width: 100%;
        padding: 0 1rem;
        box-sizing: border-box;
    }
    
    .pricing-module-container .pricing-plan {
        background-color: #ffffff;
        border-radius: 1rem;
        padding: 1.5rem;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
        display: flex;
        flex-direction: column;
        border: 2px solid transparent;
    }
    
    .pricing-module-container .pricing-plan:hover {
        transform: translateY(-10px);
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.15);
    }
    
    .pricing-module-container .pricing-plan.popular {
        transform: scale(1.05);
        border: 2px solid #6b46c1;
        z-index: 1;
    }
    
    .pricing-module-container .pricing-plan.popular:hover {
        transform: scale(1.05) translateY(-10px);
    }
    
    /* Popular Ribbon Style */
    .pricing-module-container .popular-ribbon {
        position: absolute;
        top: 0;
        right: 0;
        width: 100px;
        height: 100px;
        overflow: hidden;
        z-index: 2;
        pointer-events: none;
    }
    
    .pricing-module-container .popular-ribbon::before {
        content: 'Popular';
        position: absolute;
        display: block;
        width: 150px;
        padding: 8px 0;
        background-color: #00c1d4;
        color: white;
        font-size: 14px;
        font-weight: bold;
        text-transform: uppercase;
        text-align: center;
        right: -35px;
        top: 20px;
        transform: rotate(45deg);
        box-shadow: 0 3px 7px rgba(0,0,0,0.15);
    }
    
    .pricing-module-container .plan-name {
        font-size: 1.5rem;
        font-weight: 700;
        margin-bottom: 0.25rem;
        margin-top: 0;
        padding-right: 40px;
    }
    
    .pricing-module-container .plan-price {
        font-size: 2.5rem;
        font-weight: 700;
        margin-bottom: 0.5rem;
        color: #6b46c1;
        margin-top: 0;
    }
    
    .pricing-module-container .plan-price span {
        font-size: 1rem;
        color: #4a5568;
    }
    
    .pricing-module-container .plan-description {
        color: #4a5568;
        margin-bottom: 1rem;
        font-size: 0.9rem;
        margin-top: 0;
    }
    
    .pricing-module-container .plan-features {
        list-style: none;
        margin-bottom: 1rem;
        padding-left: 0;
        flex-grow: 1;
        margin-top: 0;
    }
    
    .pricing-module-container .plan-feature {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        margin-bottom: 0.5rem;
    }
    
    .pricing-module-container .feature-check {
        color: #6b46c1;
    }
    
    .pricing-module-container .plan-cta {
        width: 100%;
        text-align: center;
        margin-top: auto;
    }
    
    /* Buttons */
    .pricing-module-container .btn {
        display: inline-block;
        padding: 0.75rem 2rem;
        border-radius: 0.5rem;
        text-decoration: none;
        font-weight: 600;
        transition: all 0.3s ease;
    }
    
    .pricing-module-container .btn-primary {
        position: relative;
        background: linear-gradient(to right, #6a11cb, #2575fc); 
        color: white;
        font-weight: 600;
        padding: 12px 24px;
        border-radius: 6px;
        text-decoration: none;
        transition: all 0.4s ease;
        border: 1px solid transparent;
        letter-spacing: 0.5px;
        overflow: hidden;
        z-index: 1;
    }
    
    .pricing-module-container .btn-secondary {
        position: relative;
        background: white;
        color: #6b46c1;
        font-weight: 600;
        padding: 12px 24px;
        border-radius: 6px;
        text-decoration: none;
        transition: all 0.4s ease;
        border: 1px solid #6b46c1;
        letter-spacing: 0.5px;
        overflow: hidden;
        z-index: 1;
    }
    
    .pricing-module-container .btn-primary::before, 
    .pricing-module-container .btn-secondary::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 0%;
        height: 100%;
        background: linear-gradient(to right, #8a2be2, #4500e0); 
        transition: width 0.3s cubic-bezier(0.58, 0.3, 0.005, 1);
        z-index: -1;
    }
    
    .pricing-module-container .btn-primary:hover, 
    .pricing-module-container .btn-secondary:hover {
        color: white;
        transform: translateY(-2px);
        border-color: transparent;
        box-shadow: 0 5px 15px rgba(106, 17, 203, 0.4);
    }
    
    .pricing-module-container .btn-primary:hover::before, 
    .pricing-module-container .btn-secondary:hover::before {
        width: 100%;
    }
    
    .pricing-module-container .btn-primary:active, 
    .pricing-module-container .btn-secondary:active {
        transform: translateY(0);
    }
    
    /* Responsive Design */
    @media screen and (min-width: 1025px) {
        .pricing-module-container .pricing-plans {
            grid-template-columns: repeat(3, 1fr);
        }
        
        .pricing-module-container .pricing-plan.popular {
            transform: scale(1.05);
        }
    }
    
    @media screen and (max-width: 1024px) and (min-width: 769px) {
        .pricing-module-container .pricing-plans {
            grid-template-columns: repeat(3, 1fr);
        }
        
        .pricing-module-container .pricing-plan {
            padding: 1.5rem;
        }
        
        .pricing-module-container .pricing-plan.popular {
            transform: scale(1.03);
        }
        
        .pricing-module-container .plan-price {
            font-size: 2.2rem;
        }
        
        .pricing-module-container .popular-ribbon::before {
            width: 140px;
            padding: 7px 0;
            font-size: 13px;
            right: -35px;
            top: 18px;
        }
    }
    
    @media screen and (max-width: 768px) and (min-width: 641px) {
        .pricing-module-container .pricing-plans {
            grid-template-columns: repeat(2, 1fr);
            gap: 0.75rem;
        }
        
        .pricing-module-container .pricing-plan.popular {
            grid-column: span 2;
            transform: scale(1);
            margin-top: 0.75rem;
            margin-bottom: 0.75rem;
        }
        
        .pricing-module-container .pricing-title {
            font-size: 2rem;
        }
        
        .pricing-module-container .popular-ribbon {
            width: 90px;
            height: 90px;
        }
        
        .pricing-module-container .popular-ribbon::before {
            width: 130px;
            padding: 6px 0;
            font-size: 12px;
            right: -32px;
            top: 16px;
        }
    }
    
    @media screen and (max-width: 640px) {
        .pricing-module-container .pricing-plans {
            grid-template-columns: 1fr;
            gap: 0.75rem;
        }
        
        .pricing-module-container .pricing-plan {
            margin-bottom: 0.75rem;
        }
        
        .pricing-module-container .pricing-plan.popular {
            transform: scale(1);
            order: -1;
            margin-bottom: 0.75rem;
        }
        
        .pricing-module-container .pricing-title {
            font-size: 1.75rem;
        }
        
        .pricing-module-container .pricing-subtitle {
            font-size: 1rem;
        }
        
        .pricing-module-container .plan-price {
            font-size: 2rem;
        }
        
        .pricing-module-container .pricing-header {
            padding: 1.5rem 1rem;
        }
        
        .pricing-module-container .popular-ribbon {
            width: 80px;
            height: 80px;
        }
        
        .pricing-module-container .popular-ribbon::before {
            width: 120px;
            padding: 5px 0;
            font-size: 11px;
            right: -30px;
            top: 15px;
        }
    }
    
    @media screen and (max-width: 480px) {
        .pricing-module-container .pricing-toggle-option {
            padding: 0.5rem 1rem;
            font-size: 0.9rem;
        }
        
        .pricing-module-container .pricing-plan {
            padding: 1.25rem;
        }
        
        .pricing-module-container .pricing-header {
            padding: 1.25rem 0.75rem;
        }
        
        .pricing-module-container .pricing-plans {
            gap: 0.5rem;
        }
        
        .pricing-module-container .pricing-plan {
            margin-bottom: 0.5rem;
        }
        
        .pricing-module-container .popular-ribbon {
            width: 70px;
            height: 70px;
        }
        
        .pricing-module-container .popular-ribbon::before {
            width: 110px;
            padding: 4px 0;
            font-size: 10px;
            right: -28px;
            top: 14px;
        }
    }
    </style>

    <div class="pricing-container">
        <!-- Pricing Header -->
        <div class="pricing-header">
            <h1 class="pricing-title">Simple, Transparent Pricing</h1>
            <p class="pricing-subtitle">Choose the plan that works best for you and your team</p>
        </div>
        
        <!-- Pricing Toggle -->
        <div class="pricing-toggle">
            <button class="pricing-toggle-option active">Monthly</button>
            <button class="pricing-toggle-option">Annual</button>
        </div>
        
        <!-- Pricing Plans -->
        <div class="pricing-plans">
            <div class="pricing-plan">
                <h3 class="plan-name">Starter</h3>
                <div class="plan-price">$19<span>/month</span></div>
                <p class="plan-description">Perfect for individuals and small projects</p>
                <ul class="plan-features">
                    <li class="plan-feature">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="feature-check" viewBox="0 0 16 16">
                            <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                        </svg>
                        50,000 AI words per month
                    </li>
                    <li class="plan-feature">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="feature-check" viewBox="0 0 16 16">
                            <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                        </svg>
                        20 AI images per month
                    </li>
                    <li class="plan-feature">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="feature-check" viewBox="0 0 16 16">
                            <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                        </svg>
                        Basic content templates
                    </li>
                    <li class="plan-feature">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="feature-check" viewBox="0 0 16 16">
                            <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                        </svg>
                        Email support
                    </li>
                </ul>
                <div class="plan-cta">
                    <a href="/register" class="btn btn-secondary">Get Started</a>
                </div>
            </div>
            <div class="pricing-plan popular">
                <!-- Optimized ribbon-style popular tag -->
                <div class="popular-ribbon"></div>
                <h3 class="plan-name">Professional</h3>
                <div class="plan-price">$49<span>/month</span></div>
                <p class="plan-description">Ideal for professionals and growing teams</p>
                <ul class="plan-features">
                    <li class="plan-feature">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="feature-check" viewBox="0 0 16 16">
                            <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                        </svg>
                        200,000 AI words per month
                    </li>
                    <li class="plan-feature">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="feature-check" viewBox="0 0 16 16">
                            <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                        </svg>
                        100 AI images per month
                    </li>
                    <li class="plan-feature">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="feature-check" viewBox="0 0 16 16">
                            <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                        </svg>
                        Premium content templates
                    </li>
                    <li class="plan-feature">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="feature-check" viewBox="0 0 16 16">
                            <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                        </svg>
                        Priority support
                    </li>
                    <li class="plan-feature">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="feature-check" viewBox="0 0 16 16">
                            <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                        </svg>
                        Team collaboration
                    </li>
                </ul>
                <div class="plan-cta">
                    <a href="/register" class="btn btn-primary">Get Started</a>
                </div>
            </div>
            <div class="pricing-plan">
                <h3 class="plan-name">Enterprise</h3>
                <div class="plan-price">$99<span>/month</span></div>
                <p class="plan-description">Advanced features for larger organizations</p>
                <ul class="plan-features">
                    <li class="plan-feature">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="feature-check" viewBox="0 0 16 16">
                            <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                        </svg>
                        Unlimited AI words
                    </li>
                    <li class="plan-feature">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="feature-check" viewBox="0 0 16 16">
                            <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                        </svg>
                        Unlimited AI images
                    </li>
                    <li class="plan-feature">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="feature-check" viewBox="0 0 16 16">
                            <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                        </svg>
                        Custom content templates
                    </li>
                    <li class="plan-feature">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="feature-check" viewBox="0 0 16 16">
                            <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                        </svg>
                        Dedicated account manager
                    </li>
                    <li class="plan-feature">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="feature-check" viewBox="0 0 16 16">
                            <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                        </svg>
                        API access
                    </li>
                </ul>
                <div class="plan-cta">
                    <a href="/page/contact" class="btn btn-secondary">Contact Sales</a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Use a self-executing function to avoid global scope pollution
(function() {
    document.addEventListener('DOMContentLoaded', function() {
        // Find elements specifically within our container to avoid affecting other page elements
        const container = document.querySelector('.pricing-module-container');
        const monthlyToggle = container.querySelector('.pricing-toggle-option:first-child');
        const annualToggle = container.querySelector('.pricing-toggle-option:last-child');
        const pricingPlans = container.querySelectorAll('.plan-price');
        
        const monthlyPrices = ['$19', '$49', '$99'];
        const annualPrices = ['$15', '$39', '$79'];
        
        monthlyToggle.addEventListener('click', function() {
            monthlyToggle.classList.add('active');
            annualToggle.classList.remove('active');
            
            pricingPlans.forEach((plan, index) => {
                plan.innerHTML = monthlyPrices[index] + '<span>/month</span>';
            });
        });
        
        annualToggle.addEventListener('click', function() {
            annualToggle.classList.add('active');
            monthlyToggle.classList.remove('active');
            
            pricingPlans.forEach((plan, index) => {
                plan.innerHTML = annualPrices[index] + '<span>/month</span>';
            });
        });
    });
})();
</script>
<!-- END PRICING SECTION -->