<div id="coming-soon" class="coming-soon">
    <h2 class="coming-soon-text">🚀 Coming Soon</h2>
    <div class="countdown-timer">
        <div class="time-box">
            <span class="time-digit" id="days">00</span>
            <span class="time-label">Days</span>
        </div>
        <div class="time-box">
            <span class="time-digit" id="hours">00</span>
            <span class="time-label">Hours</span>
        </div>
        <div class="time-box">
            <span class="time-digit" id="minutes">00</span>
            <span class="time-label">Minutes</span>
        </div>
        <div class="time-box">
            <span class="time-digit" id="seconds">00</span>
            <span class="time-label">Seconds</span>
        </div>
    </div>
    <div class="ceo-info">
    <p class="ceo-name">Piyush Chaurasiya</p>
    <p class="ceo-title">CEO & Founder</p>
</div>
</div>