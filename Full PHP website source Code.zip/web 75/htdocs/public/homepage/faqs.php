<?php
// Set page variables
$currentYear = date('Y');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Tools</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
    .faq-page-container {
        all: initial;
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
    }
    
    .faq-page-container * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
    }
    
    .faq-page-container :root {
        --primary-color: #0039CB;
        --secondary-color: #7C3AED;
        --dark-color: #1E293B;
        --light-color: #F8FAFC;
        --accent-color: #06B6D4;
        --success-color: #10B981;
        --warning-color: #F59E0B;
        --border-radius: 8px;
        --box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    }
    
    .faq-page-container body {
        background-color: #f0f7ff;
        color: #1E293B;
        line-height: 1.6;
    }
    
    .faq-page-container .container {
        width: 100%;
        max-width: 1200px;
        margin: 0 auto;
        padding: 2rem;
    }
    
    .faq-page-container .page-wrapper {
        background-color: #f0f7ff;
        border-radius: 15px;
        min-height: auto; /* Changed from 100vh to auto */
        width: 100%;
        padding: 2rem 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        position: relative; /* For the decorative elements */
    }
    
    .faq-page-container header {
        margin-bottom: 3rem;
        text-align: center;
        width: 100%;
    }
    
    .faq-page-container h1 {
        font-size: 3.5rem;
        margin-bottom: 0.5rem;
        color: #222;
        line-height: 1.1;
        font-weight: 800;
    }
    
    .faq-page-container h1 span {
        color: #0039CB;
        display: block;
        font-size: 3.5rem;
        font-weight: 800;
    }
    
    .faq-page-container .tab-container {
        background-color: white;
        border-radius: 50px;
        padding: 0.5rem;
        display: flex;
        justify-content: center;
        gap: 0.5rem;
        margin: 2rem auto 3rem;
        max-width: 900px;
        width: 90%;
        overflow-x: auto;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }
    
    .faq-page-container .tab {
        padding: 0.8rem 1.5rem;
        cursor: pointer;
        border-radius: 50px;
        white-space: nowrap;
        font-weight: 500;
        transition: all 0.3s ease;
    }
    
    .faq-page-container .tab.active {
        background-color: #0039CB;
        color: white;
    }
    
    .faq-page-container .faq-section {
        max-width: 900px;
        margin: 0 auto;
        width: 100%;
    }
    
    .faq-page-container .faq-item {
        background-color: white;
        border-radius: 10px;
        margin-bottom: 1.5rem;
        overflow: hidden;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        border: none;
    }
    
    .faq-page-container .faq-question {
        padding: 1.5rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
        cursor: pointer;
        font-weight: 500;
        color: #1E293B;
        font-size: 1.1rem;
    }
    
    .faq-page-container .faq-question span {
        flex: 1;
    }
    
    .faq-page-container .faq-question i {
        font-size: 1.2rem;
        transition: transform 0.3s ease;
    }
    
    .faq-page-container .faq-answer {
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.3s ease;
    }
    
    .faq-page-container .faq-answer-inner {
        padding: 0 1.5rem 1.5rem 1.5rem;
        color: #4B5563;
    }
    
    .faq-page-container .faq-item.active .faq-question i {
        transform: rotate(45deg);
    }
    
    .faq-page-container .faq-item.active .faq-answer {
        max-height: 500px;
    }
    
    .faq-page-container .category-content {
        display: none;
        width: 100%;
    }
    
    .faq-page-container .category-content.active {
        display: block;
    }
    
    @media (max-width: 768px) {
        .faq-page-container .container {
            padding: 1rem;
        }
        
        .faq-page-container h1 {
            font-size: 2.5rem;
        }
        
        .faq-page-container h1 span {
            font-size: 2.5rem;
        }
        
        .faq-page-container .tab-container {
            padding: 0.3rem;
            justify-content: flex-start;
            
        }
        
        .faq-page-container .tab {
            padding: 0.6rem 1rem;
            font-size: 0.9rem;
        }
    }
    

    </style>
</head>
<body>
<div class="faq-page-container">
    <div class="page-wrapper">
        <div class="container">
            
            <header>
                <h1>Frequently Asked <span>Questions</span></h1>
            </header>
            
            <div class="tab-container">
                <div class="tab active" data-category="general">General</div>
                <div class="tab" data-category="features">Features</div>
                <div class="tab" data-category="pricing">Pricing</div>
                <div class="tab" data-category="security">Security</div>
                <div class="tab" data-category="technical">Technical</div>
            </div>
            
            <div class="faq-section">
                <!-- General Category -->
                <div class="category-content active" id="general">
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>What is the AI Tools Platform?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                The AI Tools Platform is a comprehensive suite of artificial intelligence solutions designed to help businesses of all sizes leverage the power of AI without requiring specialized technical expertise. Our platform offers tools for natural language processing, predictive analytics, computer vision, conversational AI, and more—all accessible through intuitive interfaces and seamless integrations with your existing systems.
                            </div>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>How does your AI platform differ from competitors?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                Our AI platform stands out through its combination of powerful capabilities and user-friendly design. Unlike many competitors that require deep technical knowledge, our tools are accessible to users of all skill levels. We also offer more comprehensive integration options, superior customization capabilities, and a more transparent pricing model with no hidden costs. Our dedicated customer success team ensures you get maximum value from the platform, providing personalized guidance and support throughout your AI journey.
                            </div>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>Do I need to have AI expertise to use your platform?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                No technical expertise is required to use our AI platform. We've designed it with intuitive interfaces and user-friendly tools that enable anyone in your organization to leverage the power of AI. For more advanced customization, we offer no-code builders and integration options that don't require programming knowledge. Our platform democratizes access to AI technology, making it accessible to users regardless of their technical background.
                            </div>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>How can I get started with the platform?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                Getting started with our AI platform is simple. You can sign up for a free trial on our website, which gives you access to core features for 14 days. Once registered, you'll have access to our quickstart guides, video tutorials, and knowledge base. Our onboarding team will reach out to help you set up your account, understand your specific needs, and guide you through the initial implementation. For enterprise customers, we offer dedicated onboarding services to ensure a smooth transition.
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Features Category -->
                <div class="category-content" id="features">
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>What specific AI capabilities does your platform offer?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                Our platform offers a comprehensive suite of AI capabilities including: Natural Language Processing (content generation, summarization, sentiment analysis, translation), Predictive Analytics (forecasting, anomaly detection, pattern recognition), Computer Vision (image recognition, object detection, visual search), Conversational AI (chatbots, virtual assistants, voice interfaces), Intelligent Automation (process automation, workflow optimization), and Recommendation Systems (personalized recommendations, content curation). These capabilities are available through various tools and APIs that can be combined to create powerful, custom solutions.
                            </div>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>Can I customize the AI models for my specific business needs?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                Yes, customization is a core strength of our platform. While our pre-trained models work effectively out of the box, we offer several customization options. Professional and Enterprise plans include the ability to fine-tune models with your own data, create custom workflows, and develop specialized AI solutions for your unique use cases. Enterprise customers also have access to custom model training services where our AI specialists work directly with your team to build bespoke models tailored to your specific requirements.
                            </div>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>What languages does your natural language processing support?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                Our NLP tools support over 100 languages, with comprehensive capabilities in major languages like English, Spanish, French, German, Chinese, Japanese, and Arabic. Advanced features like sentiment analysis, entity recognition, and content generation are fully supported in 25+ languages. Translation services cover 100+ language pairs with high accuracy. We regularly expand our language support based on customer needs and the latest advancements in multilingual AI.
                            </div>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>How accurate are your predictive analytics tools?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                The accuracy of our predictive analytics tools varies by use case and data quality, but our customers typically report 80-95% accuracy in forecasting scenarios. Factors affecting accuracy include historical data volume, data quality, and the complexity of the patterns being predicted. Our platform uses ensemble methods and continuous learning to improve accuracy over time. We provide transparency into model confidence and prediction intervals, allowing you to make informed decisions. For specialized use cases, our team can work with you to optimize models for maximum accuracy in your specific context.
                            </div>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>What customization options does your platform offer for content generation?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                Our AI platform offers comprehensive customization options including topic selection, tone adjustment, audience targeting, content length control, and format preferences. Professional and Enterprise plans allow for fine-tuning models with your own data, creating custom workflows, and developing specialized AI solutions for your unique use cases. Our tools adapt to your brand voice and style guidelines to ensure consistency across all generated content.
                            </div>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>Can your platform help improve my SEO efforts?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                Absolutely! Our platform can analyze top-ranking content for your target keywords, incorporate semantic SEO principles, generate SEO-optimized meta descriptions and titles, and create content structured for featured snippets. Our platform helps maintain optimal keyword density without sacrificing readability and creates internal linking suggestions for improved site structure. Each piece of content is created with search engine algorithms in mind while still prioritizing user experience and engagement metrics.
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Pricing Category -->
                <div class="category-content" id="pricing">
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>How is the platform priced?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                We offer flexible pricing plans designed to scale with your business needs. Our pricing is based on a combination of features accessed and usage volume. The Starter plan begins at $99/month, Professional at $299/month, and Enterprise plans are custom-priced based on specific requirements. We provide transparent pricing with no hidden fees, and our team works with you to ensure you're getting the most value from your investment. You can view detailed pricing information on our website or contact our sales team for a customized quote.
                            </div>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>Do you offer a free trial?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                Yes, we offer a 14-day free trial that provides access to most of our core features. The trial includes limited usage of our AI tools, allowing you to explore the platform and test capabilities with your own data before committing to a subscription. No credit card is required to start your trial. During the trial period, our onboarding team will help you maximize your experience and answer any questions you may have about the platform.
                            </div>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>What's included in the Enterprise plan?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                The Enterprise plan includes all features from the Professional plan plus advanced capabilities like custom model training, unlimited API calls, priority access to new features, enhanced security controls, custom SLAs, and a dedicated success manager. Enterprise customers receive 24/7 premium support, quarterly business reviews, and access to our AI specialists for consultation. We also offer custom integrations, dedicated infrastructure options, and compliance packages for regulated industries. Enterprise pricing is customized based on your organization's specific needs and scale.
                            </div>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>Can I upgrade or downgrade my plan at any time?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                Yes, you can upgrade your plan at any time, and the changes will take effect immediately. When upgrading, you'll only be charged the prorated difference for the remainder of your billing cycle. Downgrades take effect at the end of your current billing cycle. Both upgrades and downgrades can be managed from your account settings or with assistance from our customer success team. We don't lock you into long-term contracts, giving you the flexibility to adjust your plan as your needs change.
                            </div>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>What payment methods do you accept?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                We accept all major credit cards including Visa, Mastercard, American Express, and Discover. For Enterprise customers, we also support invoice-based payments, wire transfers, and purchase orders. All payments are processed securely through industry-standard payment gateways with PCI DSS compliance. Monthly and annual billing options are available, with annual plans offering a discount of up to 20% compared to monthly billing.
                            </div>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>What is your refund policy?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                For monthly plans, we offer a 14-day satisfaction guarantee from the initial purchase. If you're not satisfied with our service during this period, you can request a full refund. For annual plans, we offer a 30-day refund window. After these periods, we generally don't provide prorated refunds for subscription cancellations, but we will honor your service until the end of your billing cycle. Enterprise customers should refer to their specific service agreements for refund terms.
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Security Category -->
                <div class="category-content" id="security">
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>How does the AI platform ensure data security and privacy?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                Our AI platform is built with security and privacy at its core. All data is encrypted both in transit and at rest using industry-standard protocols. We comply with GDPR, CCPA, and other regional privacy regulations. Your data is never used to train our models without explicit consent, and you maintain full ownership of your data at all times. We implement strict access controls, regular security audits, and vulnerability testing. Enterprise customers receive additional security features including custom data retention policies, private cloud deployments, and dedicated security reviews.
                            </div>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>Is my data used to train your AI models?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                No, your data is not used to train our general AI models without your explicit permission. By default, all customer data is isolated and used only to provide the services you've requested. Your inputs may be used to fine-tune your own custom models if you enable this feature, but this customization only affects your instance of the platform. We maintain strict data boundaries between customers. Enterprise customers can opt for complete data isolation with guarantees that their data will never be used for any purpose other than delivering their requested services.
                            </div>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>Are you compliant with industry regulations?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                Yes, we maintain compliance with major regulations and standards including GDPR, CCPA, HIPAA (for healthcare customers), SOC 2 Type II, and ISO 27001. We regularly undergo independent audits to verify our security practices and compliance status. For industries with specific regulatory requirements, our Enterprise plan offers additional compliance packages with enhanced controls and documentation to support your compliance needs. We provide detailed documentation and assistance for customers undergoing their own compliance audits.
                            </div>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>Where is my data stored?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                We operate data centers in multiple regions including North America, Europe, and Asia-Pacific. Your data is stored in the region you select during account setup, allowing you to comply with data residency requirements. Enterprise customers can specify exact data storage locations to meet specific regulatory needs. All data centers are SOC 2 compliant and implement robust physical and logical security controls. We don't transfer your data between regions without your explicit consent, and you can monitor data locations through our admin dashboard.
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Technical Category -->
                <div class="category-content" id="technical">
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>What support options are available?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                We offer multiple support channels tailored to your plan level. All customers have access to our comprehensive knowledge base, community forums, and email support. Professional plan customers receive priority email support and phone support during business hours. Enterprise customers enjoy 24/7 premium support with guaranteed response times, a dedicated support team, and optional on-site support for critical issues. We also provide regular webinars, training sessions, and implementation guidance to help you maximize the value of our platform.
                            </div>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>How quickly can I integrate the platform with my existing systems?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                Integration timeframes vary depending on your systems and requirements, but most customers can achieve basic integration within 1-4 weeks. Simple API integrations can be completed in days, while more complex enterprise implementations may take 1-2 months. We provide comprehensive documentation, SDKs for popular programming languages, and pre-built connectors for common business systems to accelerate integration. Our professional services team is available to assist with custom integrations, and we offer implementation packages specifically designed to minimize time-to-value.
                            </div>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>What APIs do you offer?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                We offer a comprehensive suite of RESTful APIs that provide programmatic access to all our AI capabilities. These include Natural Language Processing API, Computer Vision API, Predictive Analytics API, Conversational AI API, and more. All APIs follow modern design principles with detailed documentation, consistent error handling, and robust authentication. We provide client libraries for popular programming languages including Python, JavaScript, Java, C#, and Ruby. Our API plans include generous usage limits with options to scale as your needs grow.
                            </div>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>What is your system uptime guarantee?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                We guarantee 99.9% uptime for our Standard and Professional plans, and up to 99.99% uptime for Enterprise customers with custom SLAs. Our infrastructure is built on redundant systems with automatic failover capabilities to minimize disruptions. We maintain a public status page with real-time information about system performance and scheduled maintenance. In the rare event of service disruptions, we provide transparent communication and appropriate compensation as outlined in our service level agreements. Enterprise customers receive advance notification of planned maintenance and can request maintenance windows that align with their business needs.
                            </div>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>How do I cancel my subscription?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                You can cancel your subscription at any time through your account dashboard by navigating to Billing > Subscription > Cancel Subscription. Alternatively, you can contact our support team via email or phone for assistance with cancellation. Upon cancellation, your service will remain active until the end of your current billing period. We'll send a confirmation email once your cancellation is processed, and you'll maintain access to your data for 30 days after your subscription ends.
                            </div>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>What if the generated content doesn't meet my expectations?</span>
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-inner">
                                We understand that content quality is paramount. If you're not satisfied with the generated content, you can use our revision system to refine the output by providing specific feedback. Our AI learns from your preferences over time, improving results with continued use. For Professional and Enterprise plans, you can contact your dedicated success manager for personalized assistance. We also offer content credits for cases where our platform genuinely fails to meet reasonable quality standards despite multiple revision attempts.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    
<script>
    // Toggle FAQ items
    document.querySelectorAll('.faq-page-container .faq-question').forEach(question => {
        question.addEventListener('click', () => {
            const item = question.parentElement;
            item.classList.toggle('active');
            
            // Get all active FAQ items' answers' heights
            let totalHeight = 0;
            document.querySelectorAll('.faq-page-container .faq-item.active .faq-answer').forEach(answer => {
                totalHeight += answer.scrollHeight;
            });
        });
    });
    
    // Tab switching
    document.querySelectorAll('.faq-page-container .tab').forEach(tab => {
        tab.addEventListener('click', () => {
            // Remove active class from all tabs
            document.querySelectorAll('.faq-page-container .tab').forEach(t => {
                t.classList.remove('active');
            });
            
            // Add active class to clicked tab
            tab.classList.add('active');
            
            // Hide all category content
            document.querySelectorAll('.faq-page-container .category-content').forEach(content => {
                content.classList.remove('active');
            });
            
           // Show selected category content
                const category = tab.getAttribute('data-category');
                document.getElementById(category).classList.add('active');
            });
        });
    </script>
</body>
</html>