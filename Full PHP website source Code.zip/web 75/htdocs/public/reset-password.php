<?php
session_start();
require_once('../private/config.php');
require_once('../private/db.php');
require_once('../private/auth.php');

// If user is already logged in, redirect to homepage
if (isLoggedIn()) {
    header("Location: /");
    exit();
}

$token = $_GET['token'] ?? '';
$userData = null;
$error = '';
$success = false;

// Verify token validity
if (!empty($token)) {
    $userData = verifyPasswordResetToken($token);
    if (!$userData) {
        $error = "Invalid or expired reset link. Please request a new one.";
    }
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $userData) {
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $csrfToken = $_POST['csrf_token'] ?? '';
    
    // Validate CSRF token
    if (!verifyCSRFToken($csrfToken)) {
        $error = "Invalid request, please try again.";
    } elseif (empty($password)) {
        $error = "Please enter a new password.";
    } elseif (strlen($password) < 8) {
        $error = "Password must be at least 8 characters long.";
    } elseif ($password !== $confirmPassword) {
        $error = "Passwords do not match.";
    } else {
        // Reset the password
        $result = resetPassword($token, $password);
        
        if ($result === true) {
            $success = true;
        } else {
            $error = $result;
        }
    }
}

// Generate CSRF token
$csrfToken = generateCSRFToken();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include_once ('../private/favicon.php'); ?>
    <title>Reset Password - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="/assets/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    
    <style>
    /* Reusing login page styles */
    body {
        font-family: Arial, sans-serif;
        background: #f4f7f6;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }

    .auth-container {
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        width: 100%;
        padding: 10px;
    }

    .auth-form {
        background: #ffffff;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        width: 100%;
        max-width: 400px;
        text-align: center;
    }

    .auth-form h1 {
        font-size: 24px;
        color: #4a00e0;
        font-weight: 700;
        background: linear-gradient(to right, #8e2de2, #4a00e0);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 20px;
    }

    .form-group {
        margin-bottom: 15px;
        text-align: left;
    }

    label {
        display: block;
        font-weight: bold;
        margin-bottom: 5px;
        color: #333;
    }

    input[type="password"] {
        width: 100%;
        max-width: 100%;
        padding: 12px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 16px;
        box-sizing: border-box;
    }

    input[type="password"]:focus {
        border-color: #8e2de2;
        outline: none;
    }

    .password-container {
        position: relative;
        width: 100%;
    }

    .password-container input[type="password"],
.password-container input[type="text"] {
    width: 100%;
    padding-right: 40px;
    height: 42px;
    box-sizing: border-box;
}

.toggle-password i {
    /* Ensure consistent icon size */
    width: 16px;
    height: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
}
    .toggle-password {
        position: absolute;
        right: 10px;
        top: 50%;
        transform: translateY(-50%);
        border: none;
        background: transparent;
        cursor: pointer;
        color: #8e2de2;
        font-size: 16px;
        z-index: 10;
        padding: 0;
        height: 20px;
        width: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .toggle-password:hover {
        color: #4a00e0;
    }

    .btn-primary {
        display: inline-block;
        width: 100%;
        padding: 12px;
        font-size: 16px;
        font-weight: 600;
        text-align: center;
        color: #ffffff;
        background: linear-gradient(to right, #8e2de2, #4a00e0);
        border: none;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.3s ease-in-out;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        position: relative;
        overflow: hidden;
        z-index: 1;
    }

    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 15px rgba(142, 45, 226, 0.4);
        background: linear-gradient(to right, #7d28c7, #3900c9);
    }

    .error-message {
        background: rgba(255, 0, 0, 0.1);
        color: #d9534f;
        padding: 10px;
        border-radius: 5px;
        margin-bottom: 15px;
        font-size: 14px;
    }

    .success-message {
        background: rgba(40, 167, 69, 0.1);
        color: #28a745;
        padding: 10px;
        border-radius: 5px;
        margin-bottom: 15px;
        font-size: 14px;
    }

    .auth-links {
        margin-top: 15px;
    }

    .auth-links a {
        color: #8e2de2;
        font-weight: 600;
        text-decoration: none;
        transition: color 0.3s ease-in-out;
    }

    .auth-links a:hover {
        color: #4a00e0;
        text-decoration: underline;
    }

    /* Password strength meter */
    .password-strength {
        height: 5px;
        margin-top: 5px;
        border-radius: 3px;
        transition: all 0.3s;
    }

    .password-strength.weak {
        background-color: #dc3545;
        width: 25%;
    }

    .password-strength.medium {
        background-color: #ffc107;
        width: 50%;
    }

    .password-strength.strong {
        background-color: #28a745;
        width: 100%;
    }

    .password-feedback {
        font-size: 12px;
        margin-top: 5px;
    }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-form">
            <h1>Reset Password</h1>
            
            <?php if ($success): ?>
                <div class="success-message">
                    <p><strong>Password Reset Complete!</strong></p>
                    <p>Your account has been secured with your new password. You can now <a href="/login">sign in</a> to your account.</p>
                </div>
            <?php elseif (!empty($error)): ?>
                <div class="error-message"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if (!$success && $userData): ?>
                <p>Create a strong, secure password for your account.</p>
                
                <form method="post" action="reset-password?token=<?php echo $token; ?>">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                    
                    <div class="form-group">
                        <label for="password">New Password</label>
                        <div class="password-container">
                            <input type="password" id="password" name="password" required minlength="8">
                            <button type="button" class="toggle-password" data-target="password">
                                <i class="fa fa-eye"></i>
                            </button>
                        </div>
                        <div class="password-strength"></div>
                        <div class="password-feedback"></div>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">Confirm New Password</label>
                        <div class="password-container">
                            <input type="password" id="confirm_password" name="confirm_password" required minlength="8">
                            <button type="button" class="toggle-password" data-target="confirm_password">
                                <i class="fa fa-eye"></i>
                            </button>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Secure My Account</button>
                </form>
            <?php elseif (!$success && empty($token)): ?>
                <div class="error-message">
                    <strong>Invalid Reset Link</strong>
                    <p>This password reset link has expired or is invalid. Please request a new one.</p>
                </div>
                <div class="auth-links">
                    <p><a href="/forgot-password">Request a New Reset Link</a></p>
                </div>
            <?php endif; ?>
            
            <div class="auth-links">
                <p><a href="/login">Return to Login</a></p>
            </div>
        </div>
    </div>
    
    <script src="/assets/js/main.js"></script>
    <script>
    // Immediately Invoked Function Expression (IIFE) to isolate the script
    (function(window, document) {
        // Create a namespace for reset password page
        window.resetPasswordPage = window.resetPasswordPage || {};
        
        // Initialize the reset password functionality
        resetPasswordPage.init = function() {
            // Password visibility toggle
            const toggleButtons = document.querySelectorAll('.toggle-password');
            
            toggleButtons.forEach(button => {
                button.addEventListener('click', resetPasswordPage.togglePasswordVisibility);
            });
            
            // Password strength meter
            const passwordInput = document.getElementById('password');
            const strengthIndicator = document.querySelector('.password-strength');
            const feedbackElement = document.querySelector('.password-feedback');
            
            if (passwordInput && strengthIndicator && feedbackElement) {
                passwordInput.addEventListener('input', resetPasswordPage.checkPasswordStrength);
            }
            
            // Confirm password validation
            const confirmInput = document.getElementById('confirm_password');
            if (passwordInput && confirmInput) {
                confirmInput.addEventListener('input', resetPasswordPage.validateConfirmPassword);
            }
        };
        
        // Toggle password visibility
        resetPasswordPage.togglePasswordVisibility = function() {
            const targetId = this.getAttribute('data-target');
            const inputField = document.getElementById(targetId);
            
            // Toggle the input type
            if (inputField.type === 'password') {
                inputField.type = 'text';
                this.innerHTML = '<i class="fa fa-eye-slash"></i>';
            } else {
                inputField.type = 'password';
                this.innerHTML = '<i class="fa fa-eye"></i>';
            }
        };
        
        // Check password strength
        resetPasswordPage.checkPasswordStrength = function() {
            const password = this.value;
            const strengthIndicator = document.querySelector('.password-strength');
            const feedbackElement = document.querySelector('.password-feedback');
            
            let strength = 0;
            let feedback = '';
            
            if (password.length >= 8) {
                strength += 1;
            } else {
                feedback = 'Use at least 8 characters for better security.';
            }
            
            if (password.match(/[A-Z]/)) {
                strength += 1;
            } else if (password.length > 0) {
                feedback = 'Add an uppercase letter to strengthen your password.';
            }
            
            if (password.match(/[0-9]/)) {
                strength += 1;
            } else if (password.length > 0) {
                feedback = 'Include a number to enhance security.';
            }
            
            if (password.match(/[^A-Za-z0-9]/)) {
                strength += 1;
            } else if (password.length > 0) {
                feedback = 'Add a special character (!@#$%) for maximum security.';
            }
            
            // Update the strength indicator
            strengthIndicator.className = 'password-strength';
            if (password.length === 0) {
                strengthIndicator.style.width = '0';
            } else if (strength === 1) {
                strengthIndicator.classList.add('weak');
                if (!feedback) feedback = 'Weak: Your password is too simple.';
            } else if (strength === 2) {
                strengthIndicator.classList.add('medium');
                if (!feedback) feedback = 'Medium: Getting better, but still could be stronger.';
            } else {
                strengthIndicator.classList.add('strong');
                if (!feedback) feedback = 'Strong: Excellent password choice!';
            }
            
            feedbackElement.textContent = feedback;
        };
        
        // Validate confirm password
        resetPasswordPage.validateConfirmPassword = function() {
            const passwordInput = document.getElementById('password');
            if (this.value !== passwordInput.value) {
                this.setCustomValidity('Passwords don\'t match. Please try again.');
            } else {
                this.setCustomValidity('');
            }
        };
        
        // Initialize when DOM content is loaded
        document.addEventListener('DOMContentLoaded', resetPasswordPage.init);
        
    })(window, document);
    </script>
</body>
</html>