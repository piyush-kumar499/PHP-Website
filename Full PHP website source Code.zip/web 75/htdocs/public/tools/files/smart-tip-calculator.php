<?php
/**
* Tool: Smart Tip Calculator
* Description: A comprehensive tool for calculating tips, splitting bills, and tracking itemized expenses with regional customizations.
* Category: Finance & Productivity
* Icon: <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
  <!-- Receipt background -->
  <rect x="4" y="2" width="16" height="20" rx="2" fill="#f8fafc" stroke="#64748b" stroke-width="1.5"/>
  
  <!-- Receipt lines -->
  <line x1="7" y1="7" x2="17" y2="7" stroke="#94a3b8" stroke-width="1"/>
  <line x1="7" y1="11" x2="17" y2="11" stroke="#94a3b8" stroke-width="1"/>
  <line x1="7" y1="15" x2="13" y2="15" stroke="#94a3b8" stroke-width="1"/>
  
  <!-- Coin/tip symbol -->
  <circle cx="16" cy="16" r="4" fill="#2563eb"/>
  <text x="16" y="18" font-family="sans-serif" font-size="5" font-weight="bold" fill="white" text-anchor="middle">$</text>
  
  <!-- Calculator button -->
  <rect x="7" y="17" width="6" height="2" rx="1" fill="#2563eb"/>
</svg>
*/
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Tip Calculator</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lucide/0.263.1/lucide.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        .neptunite-container {
            min-height: 100vh;
            padding: 1rem;
            background-color: rgb(249, 250, 251);
            font-family: system-ui, -apple-system, sans-serif;
        }

        .neptunite-card {
            max-width: 42rem;
            margin: 0 auto;
            background: white;
            border-radius: 0.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        .neptunite-card-header {
            padding: 1.5rem;
            border-bottom: 1px solid #e5e7eb;
            background-color: #f8fafc;
            border-radius: 0.5rem 0.5rem 0 0;
        }

        .neptunite-card-title {
            font-size: 1.25rem;
            font-weight: bold;
            color: #1e3a8a;
        }

        .neptunite-card-content {
            padding: 1.5rem;
        }

        .neptunite-space-y-6 > * + * {
            margin-top: 1.5rem;
        }

        .neptunite-space-y-4 > * + * {
            margin-top: 1rem;
        }

        .neptunite-space-y-2 > * + * {
            margin-top: 0.5rem;
        }

        .neptunite-grid {
            display: grid;
            gap: 1rem;
        }

        .neptunite-grid-cols-2 {
            grid-template-columns: repeat(2, 1fr);
        }

        .neptunite-grid-cols-3 {
            grid-template-columns: repeat(3, 1fr);
        }

        .neptunite-grid-cols-1 {
            grid-template-columns: 1fr;
        }

        .neptunite-label {
            display: block;
            font-size: 0.875rem;
            font-weight: 500;
            margin-bottom: 0.5rem;
            color: #4b5563;
        }

        .neptunite-input, .neptunite-select {
            width: 100%;
            padding: 0.5rem;
            border: 1px solid #e5e7eb;
            border-radius: 0.375rem;
        }

        .neptunite-input:focus, .neptunite-select:focus {
            outline: none;
            border-color: #2563eb;
            box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.2);
        }

        .neptunite-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.5rem 1rem;
            border-radius: 0.375rem;
            font-size: 0.875rem;
            font-weight: 500;
            cursor: pointer;
            border: 1px solid #e5e7eb;
            background: white;
            transition: all 0.2s;
        }

        .neptunite-btn-primary {
            background: #2563eb;
            color: white;
            border: none;
        }

        .neptunite-btn-primary:hover {
            background: #1d4ed8;
        }

        .neptunite-btn-selected {
            background: #2563eb;
            color: white;
        }

        .neptunite-btn-sm {
            padding: 0.25rem 0.5rem;
            font-size: 0.75rem;
        }

        .neptunite-flex {
            display: flex;
        }

        .neptunite-flex-wrap {
            flex-wrap: wrap;
        }

        .neptunite-items-center {
            align-items: center;
        }

        .neptunite-justify-between {
            justify-content: space-between;
        }

        .neptunite-space-x-2 > * + * {
            margin-left: 0.5rem;
        }

        .neptunite-space-x-4 > * + * {
            margin-left: 1rem;
        }

        .neptunite-slider {
            width: 100%;
            height: 5px;
            -webkit-appearance: none;
            appearance: none;
            background: #e5e7eb;
            outline: none;
            border-radius: 3px;
        }

        .neptunite-slider::-webkit-slider-thumb {
            -webkit-appearance: none;
            appearance: none;
            width: 15px;
            height: 15px;
            border-radius: 50%;
            background: #2563eb;
            cursor: pointer;
        }

        .neptunite-slider::-moz-range-thumb {
            width: 15px;
            height: 15px;
            border-radius: 50%;
            background: #2563eb;
            cursor: pointer;
            border: none;
        }

        .neptunite-switch {
            position: relative;
            display: inline-block;
            width: 40px;
            height: 20px;
        }

        .neptunite-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .neptunite-slider-round {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 20px;
        }

        .neptunite-slider-round:before {
            position: absolute;
            content: "";
            height: 16px;
            width: 16px;
            left: 2px;
            bottom: 2px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }

        input:checked + .neptunite-slider-round {
            background-color: #2563eb;
        }

        input:checked + .neptunite-slider-round:before {
            transform: translateX(20px);
        }

        .neptunite-quality-labels {
            display: flex;
            justify-content: space-between;
            font-size: 0.75rem;
            width: 99%;
            color: #6b7280;
        }

        .neptunite-rounded {
            border-radius: 0.375rem;
        }

        .neptunite-p-4 {
            padding: 1rem;
        }

        .neptunite-p-2 {
            padding: 0.5rem;
        }

        .neptunite-font-medium {
            font-weight: 500;
        }

        .neptunite-font-bold {
            font-weight: 700;
        }

        .neptunite-text-sm {
            font-size: 0.875rem;
        }

        .neptunite-w-20 {
            width: 5rem;
        }

        .neptunite-w-full {
            width: 100%;
        }

        .neptunite-mr-2 {
            margin-right: 0.5rem;
        }

        .neptunite-mt-2 {
            margin-top: 0.5rem;
        }
        
        .neptunite-mb-4 {
            margin-bottom: 1rem;
        }

        .neptunite-ml-0 {
            margin-left: 0 !important;
        }

        .neptunite-gap-2 {
            gap: 0.5rem;
        }

        /* Enhanced result styles */
        .neptunite-results-container {
            padding: 1.25rem;
            border-radius: 0.5rem;
            background: linear-gradient(to right, #f3f4f6, #e5e7eb);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
        }

        .neptunite-results-divider {
            height: 1px;
            background: rgba(107, 114, 128, 0.2);
            margin: 0.75rem 0;
        }

        .neptunite-result-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.5rem 0;
            color: #4b5563;
        }

        .neptunite-result-label {
            font-size: 0.875rem;
            font-weight: 500;
        }

        .neptunite-result-value {
            font-weight: 600;
            color: #1e3a8a;
        }

        .neptunite-total-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.75rem 0;
            margin-top: 0.5rem;
            background-color: rgba(255, 255, 255, 0.5);
            border-radius: 0.375rem;
            border-left: 4px solid #2563eb;
            padding-left: 0.75rem;
            padding-right: 0.75rem;
        }

        .neptunite-total-label {
            font-size: 1.125rem;
            font-weight: 700;
            color: #1e3a8a;
        }

        .neptunite-total-value {
            font-size: 1.5rem;
            font-weight: 800;
            color: #2563eb;
        }

        .neptunite-per-person-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.5rem 0.75rem;
            margin-top: 0.5rem;
            background-color: rgba(219, 234, 254, 0.4);
            border-radius: 0.375rem;
        }

        .neptunite-tip-guide {
            margin-top: 1rem;
            padding: 0.75rem;
            background-color: rgba(255, 255, 255, 0.7);
            border-radius: 0.375rem;
            font-size: 0.875rem;
            color: #4b5563;
            border-left: 3px solid #93c5fd;
        }

        .neptunite-tip-guide-title {
            font-weight: 600;
            color: #1e3a8a;
            margin-bottom: 0.25rem;
        }

        .neptunite-item-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.75rem;
            background-color: #f9fafb;
            border-radius: 0.375rem;
            margin-bottom: 0.5rem;
            border-left: 3px solid #93c5fd;
        }

        .neptunite-item-name {
            font-weight: 600;
            color: #1e3a8a;
        }

        .neptunite-item-price {
            font-weight: 500;
            color: #2563eb;
        }

        .neptunite-item-assigned {
            font-size: 0.75rem;
            color: #6b7280;
        }

        /* Responsive designs */
        @media (max-width: 768px) {
            .neptunite-grid-cols-2, 
            .neptunite-grid-cols-3 {
                grid-template-columns: 1fr;
            }

            .neptunite-tip-buttons {
                margin-top: 0.5rem;
            }

            .neptunite-toggle-group {
                flex-direction: column;
                align-items: flex-start;
            }

            .neptunite-toggle-group > * + * {
                margin-top: 0.5rem;
            }

            .neptunite-quality-labels {
                font-size: 0.6rem;
            }
            
            .neptunite-total-value {
                font-size: 1.25rem;
            }
        }

        @media (max-width: 640px) {
            .neptunite-card-content {
                padding: 1rem;
            }
            
            .neptunite-results-container {
                padding: 1rem;
            }
        }
    </style>
</head>
<body class="neptunite-container">
    <div class="neptunite-card">
        
        <div class="neptunite-card-content neptunite-space-y-6">
            <!-- Bill Amount and Tax Section -->
            <div class="neptunite-grid neptunite-grid-cols-2">
                <div class="neptunite-space-y-2">
                    <label class="neptunite-label">Bill Amount</label>
                    <input type="number" id="billAmount" class="neptunite-input" placeholder="Enter bill amount">
                </div>
                <div class="neptunite-space-y-2">
                    <label class="neptunite-label">Tax Rate (%)</label>
                    <input type="number" id="taxRate" class="neptunite-input" placeholder="Enter tax rate">
                </div>
            </div>

            <!-- Tip Options -->
            <div class="neptunite-space-y-4">
                <div class="neptunite-flex neptunite-items-center neptunite-justify-between neptunite-flex-wrap">
                    <span class="neptunite-text-sm neptunite-font-medium neptunite-mb-4">Tip Percentage</span>
                    <div class="neptunite-space-x-2 neptunite-tip-buttons neptunite-flex neptunite-flex-wrap">
                        <button id="tip10" class="neptunite-btn neptunite-btn-sm" onclick="setTip(10)">10%</button>
                        <button id="tip15" class="neptunite-btn neptunite-btn-sm neptunite-btn-selected" onclick="setTip(15)">15%</button>
                        <button id="tip20" class="neptunite-btn neptunite-btn-sm" onclick="setTip(20)">20%</button>
                        <input type="number" id="customTip" class="neptunite-input neptunite-w-20 neptunite-ml-0" placeholder="Custom">
                    </div>
                </div>

                <!-- Service Quality Slider -->
                <div class="neptunite-space-y-2">
                    <label class="neptunite-label">Service Quality</label>
                    <input type="range" id="serviceQuality" min="0" max="4" value="3" step="1" class="neptunite-slider">
                    <div class="neptunite-quality-labels">
                        <span>Poor</span>
                        <span>Fair</span>
                        <span>Good</span>
                        <span>Very Good</span>
                        <span>Excellent</span>
                    </div>
                </div>
            </div>

            <!-- Split and Options -->
            <div class="neptunite-grid neptunite-grid-cols-2">
                <div class="neptunite-space-y-2">
                    <label class="neptunite-label">Split Between</label>
                    <input type="number" id="numPeople" min="1" value="1" class="neptunite-input">
                </div>
                <div class="neptunite-space-y-2">
                    <label class="neptunite-label">Region</label>
                    <select id="country" class="neptunite-select">
                        <option value="USA">USA</option>
                        <option value="UK">UK</option>
                        <option value="Japan">Japan</option>
                        <option value="Australia">Australia</option>
                    </select>
                </div>
            </div>

            <!-- Toggles -->
            <div class="neptunite-flex neptunite-justify-between neptunite-items-center neptunite-toggle-group">
                <div class="neptunite-flex neptunite-items-center neptunite-space-x-2">
                    <label class="neptunite-switch">
                        <input type="checkbox" id="postTax">
                        <span class="neptunite-slider-round"></span>
                    </label>
                    <span class="neptunite-text-sm">Calculate tip after tax</span>
                </div>
                <div class="neptunite-flex neptunite-items-center neptunite-space-x-2">
                    <label class="neptunite-switch">
                        <input type="checkbox" id="roundUp">
                        <span class="neptunite-slider-round"></span>
                    </label>
                    <span class="neptunite-text-sm">Round up total</span>
                </div>
            </div>

            <!-- Itemized Split Section -->
            <div class="neptunite-space-y-4">
                <div class="neptunite-flex neptunite-justify-between neptunite-items-center">
                    <h3 class="neptunite-font-medium">Itemized Split</h3>
                </div>
                
                <div class="neptunite-grid neptunite-grid-cols-3">
                    <input type="text" id="itemName" placeholder="Item name" class="neptunite-input">
                    <input type="number" id="itemPrice" placeholder="Price" class="neptunite-input">
                    <input type="text" id="itemAssignedTo" placeholder="Assigned to (optional)" class="neptunite-input">
                </div>
                
                <button class="neptunite-btn neptunite-btn-primary neptunite-w-full" onclick="addItem()">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="neptunite-mr-2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="16"></line>
                        <line x1="8" y1="12" x2="16" y2="12"></line>
                    </svg>
                    Add Item
                </button>

                <div id="itemsList" class="neptunite-space-y-2"></div>
            </div>

            <!-- Enhanced Results Section -->
            <div class="neptunite-results-container">
                <!-- Calculation Results -->
                <div class="neptunite-result-row">
                    <span class="neptunite-result-label">Subtotal:</span>
                    <span class="neptunite-result-value">$<span id="subtotal">0.00</span></span>
                </div>
                <div class="neptunite-result-row">
                    <span class="neptunite-result-label">Tax:</span>
                    <span class="neptunite-result-value">$<span id="tax">0.00</span></span>
                </div>
                <div class="neptunite-result-row">
                    <span class="neptunite-result-label">Tip:</span>
                    <span class="neptunite-result-value">$<span id="tipAmount">0.00</span></span>
                </div>
                
                <div class="neptunite-results-divider"></div>
                
                <div class="neptunite-total-row">
                    <span class="neptunite-total-label">Total:</span>
                    <span class="neptunite-total-value">$<span id="total">0.00</span></span>
                </div>
                
                <div class="neptunite-per-person-row">
                    <span class="neptunite-result-label">Per Person:</span>
                    <span class="neptunite-result-value">$<span id="perPerson">0.00</span></span>
                </div>
                
                <div class="neptunite-tip-guide" id="tipGuide">
                    <!-- Tip guide content will be inserted here -->
                </div>
            </div>
        </div>
    </div>

    <script>
        // Initialize Lucide
        if (window.lucide) {
            lucide.createIcons();
        }

        // Namespace protection using IIFE to avoid global scope pollution
        (function() {
            // State management
            let neptuniteState = {
                billAmount: '',
                tipPercentage: 15,
                customTip: '',
                serviceQuality: 3,
                numPeople: 1,
                taxRate: '',
                postTax: false,
                roundUp: false,
                country: 'USA',
                items: []
            };

            const tipGuides = {
                USA: { range: '15-20%', description: 'Tipping is customary' },
                UK: { range: '10-15%', description: 'Optional but appreciated' },
                Japan: { range: '0%', description: 'Tipping is not customary' },
                Australia: { range: '10%', description: 'Optional for exceptional service' }
            };

            const qualityLabels = ['Poor', 'Fair', 'Good', 'Very Good', 'Excellent'];
            const qualityTipAdjustments = [-5, -2.5, 0, 2.5, 5];

            // Initialize tip guide
            updateTipGuide();

            // Event listeners
            document.getElementById('billAmount').addEventListener('input', handleInput);
            document.getElementById('taxRate').addEventListener('input', handleInput);
            document.getElementById('customTip').addEventListener('input', handleCustomTip);
            document.getElementById('serviceQuality').addEventListener('input', handleInput);
            document.getElementById('numPeople').addEventListener('input', handleInput);
            document.getElementById('country').addEventListener('change', handleCountryChange);
            document.getElementById('postTax').addEventListener('change', handleInput);
            document.getElementById('roundUp').addEventListener('change', handleInput);

            function handleInput(e) {
                const id = e.target.id;
                if (id === 'postTax' || id === 'roundUp') {
                    neptuniteState[id] = e.target.checked;
                } else if (id === 'billAmount' || id === 'numPeople') {
                    neptuniteState[id] = Math.max(0, parseFloat(e.target.value) || 0);
                    e.target.value = neptuniteState[id] || '';
                } else {
                    neptuniteState[id] = e.target.value;
                }
                updateCalculations();
            }

            // Expose necessary functions to global scope
            window.setTip = function(percentage) {
                neptuniteState.tipPercentage = percentage;
                neptuniteState.customTip = '';
                document.getElementById('customTip').value = '';
                
                // Update button styles
                ['tip10', 'tip15', 'tip20'].forEach(id => {
                    const btn = document.getElementById(id);
                    if (parseInt(id.replace('tip', '')) === percentage) {
                        btn.classList.add('neptunite-btn-selected');
                    } else {
                        btn.classList.remove('neptunite-btn-selected');
                    }
                });
                
                updateCalculations();
            };

            window.addItem = function() {
                const name = document.getElementById('itemName').value.trim();
                const priceInput = document.getElementById('itemPrice');
                const price = Math.max(0, parseFloat(priceInput.value) || 0);
                const assignedTo = document.getElementById('itemAssignedTo').value.trim();

                if (name && price) {
                    neptuniteState.items.push({ name, price, assignedTo });
                    updateItemsList();
                    
                    // Update bill amount
                    neptuniteState.billAmount = (parseFloat(neptuniteState.billAmount) || 0) + price;
                    document.getElementById('billAmount').value = neptuniteState.billAmount.toFixed(2);
                    
                    // Clear input fields
                    document.getElementById('itemName').value = '';
                    priceInput.value = '';
                    document.getElementById('itemAssignedTo').value = '';
                    
                    updateCalculations();
                }
            };

            window.removeItem = function(index) {
                const removedItem = neptuniteState.items.splice(index, 1)[0];
                neptuniteState.billAmount = Math.max(0, (parseFloat(neptuniteState.billAmount) || 0) - parseFloat(removedItem.price));
                document.getElementById('billAmount').value = neptuniteState.billAmount.toFixed(2);
                updateItemsList();
                updateCalculations();
            };

            function handleCustomTip(e) {
                const value = Math.max(0, parseFloat(e.target.value) || 0);
                e.target.value = value || '';
                neptuniteState.customTip = value;
                neptuniteState.tipPercentage = 0;
                
                ['tip10', 'tip15', 'tip20'].forEach(id => {
                    document.getElementById(id).classList.remove('neptunite-btn-selected');
                });
                
                updateCalculations();
            }

            function handleCountryChange(e) {
                neptuniteState.country = e.target.value;
                updateTipGuide();
                updateCalculations();
            }

            function updateTipGuide() {
                const guide = tipGuides[neptuniteState.country];
                document.getElementById('tipGuide').innerHTML = `
                    <div class="neptunite-tip-guide-title">Tip Guide for ${neptuniteState.country}</div>
                    <div>${guide.range} - ${guide.description}</div>
                `;
            }

            function updateItemsList() {
                const itemsList = document.getElementById('itemsList');
                itemsList.innerHTML = '';
                
                neptuniteState.items.forEach((item, index) => {
                    const itemRow = document.createElement('div');
                    itemRow.className = 'neptunite-item-row';

                    itemRow.innerHTML = `
                        <span class="neptunite-item-name">${item.name}</span>
                        <span class="neptunite-item-price">$${parseFloat(item.price).toFixed(2)}</span>
                        <span class="neptunite-item-assigned">${item.assignedTo || 'N/A'}</span>
                        <button class="neptunite-btn neptunite-btn-sm" onclick="removeItem(${index})">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <polyline points="3 6 5 6 21 6"></polyline>
                                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                            </svg>
                        </button>
                    `;
                    
                    itemsList.appendChild(itemRow);
                });
                
                // Refresh Lucide icons for newly added items
                if (window.lucide) {
                    lucide.createIcons();
                }
            }

            function updateCalculations() {
                // Ensure all numeric values are properly parsed
                const billAmount = Math.max(0, parseFloat(neptuniteState.billAmount) || 0);
                const taxRate = Math.max(0, parseFloat(neptuniteState.taxRate) || 0);
                const numPeople = Math.max(1, parseInt(neptuniteState.numPeople) || 1);
                
                // Calculate tax
                const tax = (billAmount * taxRate) / 100;

                // Calculate tip
                const tipPercentage = neptuniteState.customTip ? 
                    parseFloat(neptuniteState.customTip) : 
                    parseFloat(neptuniteState.tipPercentage);
                
                // Apply service quality adjustment
                const adjustedTipPercentage = tipPercentage + qualityTipAdjustments[parseInt(neptuniteState.serviceQuality)];
                
                // Calculate tip amount based on whether it should include tax
                const tipBase = neptuniteState.postTax ? (billAmount + tax) : billAmount;
                const tipAmount = (tipBase * adjustedTipPercentage) / 100;

                // Calculate total and handle rounding
                let total = billAmount + tax + tipAmount;
                if (neptuniteState.roundUp) {
                    total = Math.ceil(total);
                }

                // Calculate per person amount
                const perPerson = total / numPeople;

                // Update display
                document.getElementById('subtotal').innerText = billAmount.toFixed(2);
                document.getElementById('tax').innerText = tax.toFixed(2);
                document.getElementById('tipAmount').innerText = tipAmount.toFixed(2);
                document.getElementById('total').innerText = total.toFixed(2);
                document.getElementById('perPerson').innerText = perPerson.toFixed(2);
            }

            // Initialize calculations
            updateCalculations();
        })();
    </script>
</body>
</html>