<?php
/**
 * Tools List Page
 * 
 * Displays a list of all available tools from the database
 * Organized by category sections with grid layout
 * Features "View All" toggle for each category
 * Includes real-time search functionality
 */

require_once __DIR__ . '/../../private/config.php';
require_once __DIR__ . '/../../private/db.php';

// Function to format view counts in K and M format
function formatViewCount($views) {
    if ($views >= 1000000) {
        return number_format($views / 1000000, 2) . 'M';
    } elseif ($views >= 1000) {
        return number_format($views / 1000, 2) . 'K';
    } else {
        return number_format($views);
    }
}

// Get all categories for the filter menu and to organize tools
$categories = dbSelect("SELECT DISTINCT category FROM tools ORDER BY category");

// Build query to get all tools
$query = "SELECT t.*, si.keywords, ts.views FROM tools t 
          LEFT JOIN tools_search_index si ON t.id = si.tool_id
          LEFT JOIN tool_stats ts ON t.id = ts.tool_id
          ORDER BY t.category, t.created_at DESC";

// Get recent tools
$recentTools = dbSelect("SELECT t.*, si.keywords, ts.views FROM tools t 
                        LEFT JOIN tools_search_index si ON t.id = si.tool_id
                        LEFT JOIN tool_stats ts ON t.id = ts.tool_id
                        WHERE t.created_at >= DATE_SUB(NOW(), INTERVAL 10 DAY)
                        ORDER BY t.created_at DESC LIMIT 50");


// Get popular tools - modified to only show tools with 300000+ views
$popularTools = dbSelect("SELECT t.*, si.keywords, ts.views FROM tools t 
                         LEFT JOIN tools_search_index si ON t.id = si.tool_id
                         LEFT JOIN tool_stats ts ON t.id = ts.tool_id
                         WHERE ts.views >= 300000
                         ORDER BY ts.views DESC LIMIT 50");
                         
// Get tools from database
$tools = dbSelect($query);

// Organize tools by category
$toolsByCategory = [];
foreach ($tools as $tool) {
    $cat = $tool['category'];
    if (!isset($toolsByCategory[$cat])) {
        $toolsByCategory[$cat] = [];
    }
    $toolsByCategory[$cat][] = $tool;
}

// Function to render tool icon
function renderToolIcon($icon, $iconType, $toolName) {
    if (!$icon || !$iconType) {
        // Default icon if none is provided
        return '<div class="tools-portal-icon-default"><i class="fas fa-tools"></i></div>';
    }
    
    switch ($iconType) {
        case 'svg':
            return $icon;
        case 'class':
            return '<i class="' . htmlspecialchars($icon) . '" aria-hidden="true"></i>';
        case 'image':
            return '<img src="' . htmlspecialchars('/assets/images/tools/' . $icon) . '" alt="' . htmlspecialchars($toolName) . ' icon" class="tools-portal-icon-img">';
        default:
            return '<div class="tools-portal-icon-default"><i class="fas fa-tools"></i></div>';
    }
}

// Function to create safe category ID for anchors
function getCategoryId($categoryName) {
    return 'category-' . preg_replace('/[^a-z0-9]/i', '-', strtolower($categoryName));
}

// Include header
include_once __DIR__ . '/../header.php';
?>
<link rel="stylesheet" href="/assets/css/tools-portal.css">
<style>
html {
    scroll-behavior: smooth;
}

</style>

<div class="tools-portal-wrapper">
    <div class="tools-portal-container">
        <div class="tools-portal-main-view" id="tools-portal-main-view">
            <h1 class="tools-portal-heading"><?php echo $pageTitle; ?></h1>
            
            <!-- Add search bar -->
            <div class="tools-portal-search-container">
                <i class="fas fa-search tools-portal-search-icon"></i>
                <input type="text" class="tools-portal-search-input" placeholder="Search tools..." id="tools-portal-search">
                <button class="tools-portal-search-clear" id="tools-portal-search-clear">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <!-- Search results section (initially hidden) -->
            <div class="tools-portal-search-results" id="tools-portal-search-results">
                <h2 class="tools-portal-search-results-heading">Search Results</h2>
                <div class="tools-portal-row" id="tools-portal-search-results-container">
                    <!-- Search results will be populated here -->
                </div>
                <div class="tools-portal-no-results" id="tools-portal-no-results" style="display: none;">
                    No tools found matching your search. Try different keywords.
                </div>
            </div>
            
            <!-- Horizontal scrollable categories -->
            <?php if (!empty($toolsByCategory)): ?>
            <div class="tools-portal-categories-scroll-container">
                <div class="tools-portal-categories-row">
                    <a href="#" class="tools-portal-category-pill tools-portal-special-pill" data-special-category="recent">
                        <i class="fas fa-clock"></i> Recent
                    </a>
                    <a href="#" class="tools-portal-category-pill tools-portal-special-pill" data-special-category="popular">
                        <i class="fas fa-fire"></i> Popular
                    </a>
                    <?php foreach (array_keys($toolsByCategory) as $cat): ?>
                    <a href="#<?php echo getCategoryId($cat); ?>" class="tools-portal-category-pill">
                        <?php echo htmlspecialchars($cat); ?>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Not Found Tools -->
            <?php if (empty($tools)): ?>
                <div class="tools-portal-alert">
                    No tools found.
                </div>
            <?php else: ?>
                <?php foreach ($toolsByCategory as $categoryName => $categoryTools): ?>
                    <div id="<?php echo getCategoryId($categoryName); ?>" class="tools-portal-category-section">
                        <div class="tools-portal-category-header">
                            <h2 class="tools-portal-category-title"><?php echo htmlspecialchars($categoryName); ?></h2>
                            <button class="tools-portal-view-all-btn" 
                                    data-category="<?php echo htmlspecialchars($categoryName); ?>">
                                View All (<?php echo count($categoryTools); ?>)
                            </button>
                        </div>
                        <div class="tools-portal-row">
               <?php 
// Display first 14 tools for preview in main view
$previewTools = array_slice($categoryTools, 0, 14);

// Identify top 3 popular tools in this category
$popularToolIds = [];
$tempCatTools = $categoryTools;
// Sort by views (descending)
usort($tempCatTools, function($a, $b) {
    return ($b['views'] ?? 0) - ($a['views'] ?? 0);
});
// Get the IDs of top 3 most viewed tools
$topCount = 0;
foreach ($tempCatTools as $popularTool) {
    if ($topCount < 3 && ($popularTool['views'] ?? 0) > 0) {
        $popularToolIds[] = $popularTool['id'];
        $topCount++;
    }
}

foreach ($previewTools as $tool): 
    // Check if tool was created within last 10 days
    $createdDate = strtotime($tool['created_at']);
    $now = time();
    $daysDiff = floor(($now - $createdDate) / (60 * 60 * 24));
    $isNew = ($daysDiff <= 10);
    
    // Check if this is one of the top 3 most popular tools
    $isPopular = in_array($tool['id'], $popularToolIds);
?>
    <div class="tools-portal-col">
        <div class="tools-portal-card" 
             data-tool-slug="<?php echo urlencode($tool['slug']); ?>"
             data-tool-name="<?php echo htmlspecialchars($tool['name']); ?>"
             data-tool-category="<?php echo htmlspecialchars($tool['category']); ?>"
             data-tool-description="<?php echo htmlspecialchars($tool['description']); ?>"
             data-tool-keywords="<?php echo htmlspecialchars($tool['keywords'] ?? ''); ?>">
            <?php if ($isPopular): ?>
                <div class="tools-portal-badge tools-portal-badge-fire"><i class="fas fa-fire"></i> HOT</div>
            <?php elseif ($isNew): ?>
                <div class="tools-portal-badge tools-portal-badge-new">NEW</div>
            <?php endif; ?>
            <div class="tools-portal-card-body">
                <div class="tools-portal-card-header">
                    <div class="tools-portal-icon">
                        <?php echo renderToolIcon($tool['icon'], $tool['icon_type'], $tool['name']); ?>
                    </div>
                    <h5 class="tools-portal-card-title"><?php echo htmlspecialchars($tool['name']); ?></h5>
                </div>
                <h6 class="tools-portal-card-subtitle"><?php echo htmlspecialchars($tool['category']); ?></h6>
                <p class="tools-portal-card-text">
                    <?php 
                    $description = htmlspecialchars($tool['description']);
                    echo (strlen($description) > 100) ? substr($description, 0, 97) . '...' : $description;
                    ?>
                </p>
                <div class="tools-portal-card-footer">
                    <div class="tools-portal-card-actions">
                        <a href="/tools/<?php echo urlencode($tool['slug']); ?>" class="tools-portal-btn-primary tool-link">Use Tool</a>
                    </div>
                    <!-- Add view count display here -->
                    <div class="tools-portal-view-count">
                        <i class="fas fa-eye"></i>
                        <span class="formatted-count"><?php echo formatViewCount($tool['views'] ?? 0); ?></span>
                        <span class="exact-count"><?php echo number_format($tool['views'] ?? 0); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>
                        </div>
   
      <div class="tools-portal-view-all-bottom" style="text-align: center; width: 100%; display: flex; justify-content: center; margin: 20px auto; padding: 0 15px;">
    <style>
.custom-btn-hover {
    background-color: #4361ee !important; 
    color: white !important; 
    padding: 12px 28px !important; 
    border: none !important; 
    border-radius: 6px !important; 
    font-size: 16px !important; 
    font-weight: 600 !important; 
    cursor: pointer !important; 
    transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1) !important; 
    box-shadow: 0 2px 10px rgba(67, 97, 238, 0.3) !important;
    position: relative !important;
    max-width: 100% !important;
    width: auto !important;
    margin: 0 auto !important;
    white-space: normal !important;
    word-wrap: break-word !important;
    overflow-wrap: break-word !important;
    line-height: 1.4 !important;
    min-height: 44px !important;
}
        
.custom-btn-hover:hover {
    background-color: #3a56e5 !important;
    box-shadow: 0 4px 15px rgba(67, 97, 238, 0.5) !important;
    transform: translateY(-3px) !important;
}
        
@media (max-width: 768px) {
    .custom-btn-hover {
        padding: 10px 20px !important;
        font-size: 14px !important;
        width: 100% !important;
        max-width: 300px !important;
    }
}
        
@media (max-width: 480px) {
    .custom-btn-hover {
        padding: 8px 16px !important;
        font-size: 13px !important;
        width: 100% !important;
        max-width: 250px !important;
    }
}
    </style>
    
    <button class="tools-portal-view-all-btn custom-btn-hover" 
            data-category="<?php echo htmlspecialchars($categoryName); ?>">
        View All <?php echo htmlspecialchars($categoryName); ?> Tools (<?php echo count($categoryTools); ?>)
    </button>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // This ensures external CSS doesn't override our styles
            const btn = document.querySelector('.custom-btn-hover');
            if (btn) {
                btn.setAttribute('style', 'background-color: #4361ee !important; color: white !important; padding: 12px 28px !important; border: none !important; border-radius: 6px !important; font-size: 16px !important; font-weight: 600 !important; cursor: pointer !important; transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1) !important; box-shadow: 0 2px 10px rgba(67, 97, 238, 0.3) !important; position: relative !important; max-width: 100% !important; width: auto !important; margin: 0 auto !important; white-space: normal !important; word-wrap: break-word !important; overflow-wrap: break-word !important; line-height: 1.4 !important; min-height: 44px !important;');
            }
        });
    </script>
</div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <!-- Category-specific views (initially hidden) -->
       <?php foreach ($toolsByCategory as $categoryName => $categoryTools): ?>
    <div id="tools-portal-category-view-<?php echo htmlspecialchars(preg_replace('/[^a-z0-9]/i', '-', strtolower($categoryName))); ?>" 
         class="tools-portal-category-view" style="display: none;">
        <div class="tools-portal-category-view-header">
            <h1 class="tools-portal-category-view-title"><?php echo htmlspecialchars($categoryName); ?> Tools</h1>
            <button class="tools-portal-back-btn">
                <i class="fas fa-arrow-left"></i> Back to Tools
            </button>
        </div>
        
        <?php
        // Identify top 3 popular tools in this category
        $popularToolIds = [];
        $tempCatTools = $categoryTools;
        // Sort by views (descending)
        usort($tempCatTools, function($a, $b) {
            return ($b['views'] ?? 0) - ($a['views'] ?? 0);
        });
        // Get the IDs of top 3 most viewed tools
        $topCount = 0;
        foreach ($tempCatTools as $popularTool) {
            if ($topCount < 5 && ($popularTool['views'] ?? 0) > 0) {
                $popularToolIds[] = $popularTool['id'];
                $topCount++;
            }
        }
        ?>
        
        <div class="tools-portal-row tools-portal-tools-container">
            <?php foreach ($categoryTools as $index => $tool): ?>
                <div class="tools-portal-col tools-portal-tool-card" data-index="<?php echo $index; ?>">
                    <div class="tools-portal-card" 
                         data-tool-slug="<?php echo urlencode($tool['slug']); ?>"
                         data-tool-name="<?php echo htmlspecialchars($tool['name']); ?>"
                         data-tool-category="<?php echo htmlspecialchars($tool['category']); ?>"
                         data-tool-description="<?php echo htmlspecialchars($tool['description']); ?>"
                         data-tool-keywords="<?php echo htmlspecialchars($tool['keywords'] ?? ''); ?>">
                        <?php
                        // Check if tool was created within last 10 days
                        $createdDate = strtotime($tool['created_at']);
                        $now = time();
                        $daysDiff = floor(($now - $createdDate) / (60 * 60 * 24));
                        $isNew = ($daysDiff <= 10);
                        
                        // Check if this is one of the top 3 most popular tools
                        $isPopular = in_array($tool['id'], $popularToolIds);
                        
                        if ($isPopular): ?>
                            <div class="tools-portal-badge tools-portal-badge-fire"><i class="fas fa-fire"></i> HOT</div>
                        <?php elseif ($isNew): ?>
                            <div class="tools-portal-badge tools-portal-badge-new">NEW</div>
                        <?php endif; ?>
                        <div class="tools-portal-card-body">
                       <div class="tools-portal-card-header">
                                        <div class="tools-portal-icon">
                                            <?php echo renderToolIcon($tool['icon'], $tool['icon_type'], $tool['name']); ?>
                                        </div>
                                        <h5 class="tools-portal-card-title"><?php echo htmlspecialchars($tool['name']); ?></h5>
                                    </div>
                                    <h6 class="tools-portal-card-subtitle"><?php echo htmlspecialchars($tool['category']); ?></h6>
                                    <p class="tools-portal-card-text">
                                        <?php 
                                        $description = htmlspecialchars($tool['description']);
                                        echo (strlen($description) > 100) ? substr($description, 0, 97) . '...' : $description;
                                        ?>
                                    </p>
          <div class="tools-portal-card-footer">
    <div class="tools-portal-card-actions">
        <a href="/tools/<?php echo urlencode($tool['slug']); ?>" class="tools-portal-btn-primary tool-link">Use Tool</a>
    </div>
    <!-- Add view count display here -->
    <div class="tools-portal-view-count">
        <i class="fas fa-eye"></i>
        <span class="formatted-count"><?php echo formatViewCount($tool['views'] ?? 0); ?></span>
        <span class="exact-count"><?php echo number_format($tool['views'] ?? 0); ?></span>
    </div>
</div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <!-- Loading indicator for infinite scroll -->
                <div class="tools-portal-loading-indicator" style="display: none;">
                    <div class="tools-portal-spinner" role="status">
                        <span class="tools-portal-visually-hidden">Loading...</span>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
        
        <!-- Recent Tools View (initially hidden) -->
        <div id="tools-portal-category-view-recent" class="tools-portal-category-view" style="display: none;">
            <div class="tools-portal-category-view-header">
                <h1 class="tools-portal-category-view-title">Recent Tools</h1>
                <button class="tools-portal-back-btn">
                    <i class="fas fa-arrow-left"></i> Back to Tools
                </button>
            </div>
            
            <div class="tools-portal-row tools-portal-tools-container">
                <?php foreach ($recentTools as $index => $tool): ?>
                    <div class="tools-portal-col tools-portal-tool-card" data-index="<?php echo $index; ?>">
                        <div class="tools-portal-card" 
                             data-tool-slug="<?php echo urlencode($tool['slug']); ?>"
                             data-tool-name="<?php echo htmlspecialchars($tool['name']); ?>"
                             data-tool-category="<?php echo htmlspecialchars($tool['category']); ?>"
                             data-tool-description="<?php echo htmlspecialchars($tool['description']); ?>"
                             data-tool-keywords="<?php echo htmlspecialchars($tool['keywords'] ?? ''); ?>">
                            <?php
                            // Show NEW badge only if created within last 10 days
                            $createdDate = strtotime($tool['created_at']);
                            $now = time();
                            $daysDiff = floor(($now - $createdDate) / (60 * 60 * 24));
                            
                            if ($daysDiff <= 10): 
                            ?>
                                <div class="tools-portal-badge tools-portal-badge-new">NEW</div>
                            <?php endif; ?>
                            <div class="tools-portal-card-body">
                                <div class="tools-portal-card-header">
                                    <div class="tools-portal-icon">
                                        <?php echo renderToolIcon($tool['icon'], $tool['icon_type'], $tool['name']); ?>
                                    </div>
                                    <h5 class="tools-portal-card-title"><?php echo htmlspecialchars($tool['name']); ?></h5>
                                </div>
                                <h6 class="tools-portal-card-subtitle"><?php echo htmlspecialchars($tool['category']); ?></h6>
                                <p class="tools-portal-card-text">
                                    <?php 
                                    $description = htmlspecialchars($tool['description']);
                                    echo (strlen($description) > 100) ? substr($description, 0, 97) . '...' : $description;
                                    ?>
                                </p>
         <div class="tools-portal-card-footer">
    <div class="tools-portal-card-actions">
        <a href="/tools/<?php echo urlencode($tool['slug']); ?>" class="tools-portal-btn-primary tool-link">Use Tool</a>
    </div>
    <!-- Add view count display here -->
    <div class="tools-portal-view-count">
        <i class="fas fa-eye"></i>
        <span class="formatted-count"><?php echo formatViewCount($tool['views'] ?? 0); ?></span>
        <span class="exact-count"><?php echo number_format($tool['views'] ?? 0); ?></span>
    </div>
</div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <!-- Loading indicator for infinite scroll -->
            <div class="tools-portal-loading-indicator" style="display: none;">
                <div class="tools-portal-spinner" role="status">
                    <span class="tools-portal-visually-hidden">Loading...</span>
                </div>
            </div>
        </div>

        <!-- Popular Tools View (initially hidden) -->
        <div id="tools-portal-category-view-popular" class="tools-portal-category-view" style="display: none;">
            <div class="tools-portal-category-view-header">
                <h1 class="tools-portal-category-view-title">Popular Tools</h1>
                <button class="tools-portal-back-btn">
                    <i class="fas fa-arrow-left"></i> Back to Tools
                </button>
            </div>
            
            <div class="tools-portal-row tools-portal-tools-container">
                <?php foreach ($popularTools as $index => $tool): ?>
                    <div class="tools-portal-col tools-portal-tool-card" data-index="<?php echo $index; ?>">
                        <div class="tools-portal-card" 
                             data-tool-slug="<?php echo urlencode($tool['slug']); ?>"
                             data-tool-name="<?php echo htmlspecialchars($tool['name']); ?>"
                             data-tool-category="<?php echo htmlspecialchars($tool['category']); ?>"
                             data-tool-description="<?php echo htmlspecialchars($tool['description']); ?>"
                             data-tool-keywords="<?php echo htmlspecialchars($tool['keywords'] ?? ''); ?>">
                  <?php if ($tool['views'] > 300000): ?>
    <div class="tools-portal-badge tools-portal-badge-fire"><i class="fas fa-fire"></i> HOT</div>
<?php endif; ?>
                            <div class="tools-portal-card-body">
                                <div class="tools-portal-card-header">
                                    <div class="tools-portal-icon">
                                        <?php echo renderToolIcon($tool['icon'], $tool['icon_type'], $tool['name']); ?>
                                    </div>
                                    <h5 class="tools-portal-card-title"><?php echo htmlspecialchars($tool['name']); ?></h5>
                                </div>
                                <h6 class="tools-portal-card-subtitle"><?php echo htmlspecialchars($tool['category']); ?></h6>
                                <p class="tools-portal-card-text">
                                    <?php 
                                    $description = htmlspecialchars($tool['description']);
                                    echo (strlen($description) > 100) ? substr($description, 0, 97) . '...' : $description;
                                    ?>
                                </p>
                                <div class="tools-portal-card-footer">
                                    <div class="tools-portal-card-actions">
                                        <a href="/tools/<?php echo urlencode($tool['slug']); ?>" class="tools-portal-btn-primary tool-link">Use Tool</a>
                                    </div>
                                    <!-- Add view count display here -->
                                    <div class="tools-portal-view-count">
                                        <i class="fas fa-eye"></i>
                                        <span class="formatted-count"><?php echo formatViewCount($tool['views'] ?? 0); ?></span>
                                        <span class="exact-count"><?php echo number_format($tool['views'] ?? 0); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <!-- Loading indicator for infinite scroll -->
            <div class="tools-portal-loading-indicator" style="display: none;">
                <div class="tools-portal-spinner" role="status">
                    <span class="tools-portal-visually-hidden">Loading...</span>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Store current state in browser history
    function updateBrowserHistory(categoryName = null) {
        if (categoryName) {
            // When viewing a specific category
            history.pushState(
                { category: categoryName }, 
                document.title, 
                "#" + categoryName.toLowerCase().replace(/[^a-z0-9]/g, '-')
            );
        } else {
            // When returning to main view
            history.pushState(
                { category: null }, 
                document.title, 
                "/tools"
            );
        }
    }
    
    // View All button click handler
    document.querySelectorAll('.tools-portal-view-all-btn').forEach(button => {
        button.addEventListener('click', function() {
            const categoryName = this.getAttribute('data-category');
            const categoryId = categoryName.toLowerCase().replace(/[^a-z0-9]/g, '-');
            
            // Hide main view
            document.getElementById('tools-portal-main-view').style.display = 'none';
            
            // Show specific category view
            document.getElementById('tools-portal-category-view-' + categoryId).style.display = 'block';
            
            // Set up infinite scroll for this category
            setupInfiniteScroll(categoryId);
            
            // Update browser history
            updateBrowserHistory(categoryName);
            
            // Scroll to top
            window.scrollTo(0, 0);
        });
    });
    
    // Special category pills click handler (Recent and Popular)
document.querySelectorAll('.tools-portal-special-pill').forEach(pill => {
    pill.addEventListener('click', function(e) {
        e.preventDefault();
        const specialCategory = this.getAttribute('data-special-category');
        
        // Hide main view
        document.getElementById('tools-portal-main-view').style.display = 'none';
        
        // Hide all category views
        document.querySelectorAll('.tools-portal-category-view').forEach(view => {
            view.style.display = 'none';
        });
        
        // Show specific special category view
        document.getElementById('tools-portal-category-view-' + specialCategory).style.display = 'block';
        
        // Set up infinite scroll for this category
        setupInfiniteScroll(specialCategory);
        
        // Update browser history
        updateBrowserHistory(specialCategory);
        
        // Scroll to top
        window.scrollTo(0, 0);
    });
});

    // Back button click handler
    document.querySelectorAll('.tools-portal-back-btn').forEach(button => {
        button.addEventListener('click', function() {
            // Hide all category views
            document.querySelectorAll('.tools-portal-category-view').forEach(view => {
                view.style.display = 'none';
            });
            
            // Show main view
            document.getElementById('tools-portal-main-view').style.display = 'block';
            
            // Update browser history
            updateBrowserHistory();
            
            // Restore scroll position (optional)
            if (sessionStorage.getItem('mainViewScrollPos')) {
                window.scrollTo(0, parseInt(sessionStorage.getItem('mainViewScrollPos')));
            }
        });
    });
    
    // Handle anchor link clicks
    document.querySelectorAll('.tools-portal-category-pill').forEach(link => {
        link.addEventListener('click', function(e) {
            // The href="#category-xyz" will work naturally with scroll-behavior: smooth
            // Optional: store the clicked category for better back button handling
            const categoryId = this.getAttribute('href').substring(1);
            sessionStorage.setItem('lastClickedCategoryId', categoryId);
        });
    });
    
   // Handle browser back/forward buttons
window.addEventListener('popstate', function(event) {
    // Check if we have a hash in the URL
    const hash = window.location.hash;
    
    if (hash) {
        // If we have a hash, try to extract the category name
        const categoryId = hash.substring(1);
        const categoryView = document.getElementById('tools-portal-category-view-' + categoryId);
        
        // Check for special categories (recent, popular)
        if (categoryId === 'recent' || categoryId === 'popular') {
            // Hide main view
            document.getElementById('tools-portal-main-view').style.display = 'none';
            
            // Hide all category views
            document.querySelectorAll('.tools-portal-category-view').forEach(view => {
                view.style.display = 'none';
            });
            
            // Show the special category view
            document.getElementById('tools-portal-category-view-' + categoryId).style.display = 'block';
            setupInfiniteScroll(categoryId);
            return;
        }
        
        if (categoryView) {
            // If we have a matching category view, show it
            document.getElementById('tools-portal-main-view').style.display = 'none';
            
            // Hide all category views
            document.querySelectorAll('.tools-portal-category-view').forEach(view => {
                view.style.display = 'none';
            });
            
            // Show this category view
            categoryView.style.display = 'block';
            setupInfiniteScroll(categoryId);
        } else {
            // If no matching category view but we have a hash, scroll to that section
            document.querySelectorAll('.tools-portal-category-view').forEach(view => {
                view.style.display = 'none';
            });
            document.getElementById('tools-portal-main-view').style.display = 'block';
            
            if (document.querySelector(hash)) {
                document.querySelector(hash).scrollIntoView();
            }
        }
    } else {
        // If no hash, switch back to main view
        document.querySelectorAll('.tools-portal-category-view').forEach(view => {
            view.style.display = 'none';
        });
        document.getElementById('tools-portal-main-view').style.display = 'block';
    }
});
    
    // Save main view scroll position when navigating away
    window.addEventListener('scroll', function() {
        if (document.getElementById('tools-portal-main-view').style.display !== 'none') {
            sessionStorage.setItem('mainViewScrollPos', window.scrollY);
        }
    });
    
    // Check for hash in URL for direct category navigation
    const hash = window.location.hash;
    
    if (hash && document.querySelector(hash)) {
        // Allow time for page to render before scrolling
        setTimeout(() => {
            document.querySelector(hash).scrollIntoView();
        }, 100);
    }
    
    // Scroll horizontally with mouse wheel on category pills container
    const categoryContainer = document.querySelector('.tools-portal-categories-scroll-container');
    if (categoryContainer) {
        categoryContainer.addEventListener('wheel', function(e) {
            if (e.deltaY !== 0) {
                e.preventDefault();
                this.scrollLeft += e.deltaY;
            }
        });
    }
    
    // Make cards clickable
    document.querySelectorAll('.tools-portal-card').forEach(card => {
        card.addEventListener('click', function(e) {
            // If the click was on the link button itself, let the default handler work
            if (e.target.closest('.tool-link')) {
                return;
            }
            
            // Otherwise, navigate to the tool page
            const toolSlug = this.getAttribute('data-tool-slug');
            window.location.href = '/tools/' + toolSlug;
        });
    });
    
    // Infinite scroll setup function
function setupInfiniteScroll(categoryId) {
    const categoryView = document.getElementById('tools-portal-category-view-' + categoryId);
    const toolsContainer = categoryView.querySelector('.tools-portal-tools-container');
    const loadingIndicator = categoryView.querySelector('.tools-portal-loading-indicator');
    
    // Remove any existing load more button first (in case of category switching)
    const existingLoadMoreBtn = categoryView.querySelector('.tools-portal-load-more-btn');
    if (existingLoadMoreBtn) {
        existingLoadMoreBtn.remove();
    }
    
    // Create the load more button
    const loadMoreBtn = document.createElement('button');
    loadMoreBtn.className = 'tools-portal-load-more-btn';
    loadMoreBtn.innerHTML = 'Load More Tools';
    
    // Insert the button after the tools container
    toolsContainer.parentNode.insertBefore(loadMoreBtn, loadingIndicator);
    
    // Initially show only first 9 tools
    const allTools = toolsContainer.querySelectorAll('.tools-portal-tool-card');
    const batchSize = 10;
    let visibleCount = 0;
    
    // Function to load more tools
function loadMoreTools() {
    loadingIndicator.style.display = 'block';
    loadMoreBtn.style.display = 'none'; // Hide button while loading
    
    // Alternative: Keep button visible but show loading state
    // loadMoreBtn.classList.add('loading');
    // loadMoreBtn.innerHTML = 'Loading';
    
    // Simulate loading delay
    setTimeout(() => {
        const end = Math.min(visibleCount + batchSize, allTools.length);
        
        // Show the next batch of tools
        for (let i = visibleCount; i < end; i++) {
            allTools[i].style.display = 'block';
            // Add a small delay between each card animation
            allTools[i].style.animationDelay = `${(i - visibleCount) * 0.1}s`;
        }
        
        visibleCount = end;
        loadingIndicator.style.display = 'none';
        
        // If using loading state:
        // loadMoreBtn.classList.remove('loading');
        // loadMoreBtn.innerHTML = 'Load More Tools';
        
        // If all tools are now visible, hide the load more button
        if (visibleCount >= allTools.length) {
            loadMoreBtn.style.display = 'none';
        } else {
            loadMoreBtn.style.display = 'block';
        }
    }, 600);
}
    
    // Initially hide all tools except first batch
    allTools.forEach((tool, index) => {
        if (index < batchSize) {
            tool.style.display = 'block';
            visibleCount++;
        } else {
            tool.style.display = 'none';
        }
    });
    
    // Hide load more button if there are no more tools to show
    if (visibleCount >= allTools.length) {
        loadMoreBtn.style.display = 'none';
    }
    
    // Add click event listener to load more button
    loadMoreBtn.addEventListener('click', function() {
        loadMoreTools();
    });
    
    // Remove scroll event listener if it was previously attached
    window.removeEventListener('scroll', window.infiniteScrollHandler);
}
    
    // =============================================
// SEARCH FUNCTIONALITY
// =============================================

const searchInput = document.getElementById('tools-portal-search');
const searchClear = document.getElementById('tools-portal-search-clear');
const searchResults = document.getElementById('tools-portal-search-results');
const searchResultsContainer = document.getElementById('tools-portal-search-results-container');
const noResultsMsg = document.getElementById('tools-portal-no-results');
const categorySections = document.querySelectorAll('.tools-portal-category-section');
const categoriesPills = document.querySelector('.tools-portal-categories-scroll-container');

// Helper function to show/hide the clear button
function toggleClearButton() {
    if (searchInput.value.length > 0) {
        searchClear.style.display = 'block';
    } else {
        searchClear.style.display = 'none';
    }
}

// Helper function to highlight search terms
function highlightSearchTerms(text, searchTerm) {
    if (!searchTerm) return text;
    
    const regex = new RegExp(`(${searchTerm})`, 'gi');
    return text.replace(regex, '<span class="search-highlight">$1</span>');
}

// Function to create a search result card
function createSearchResultCard(tool, searchTerm) {
    const toolName = tool.getAttribute('data-tool-name');
    const toolCategory = tool.getAttribute('data-tool-category');
    const toolDescription = tool.getAttribute('data-tool-description');
    const toolSlug = tool.getAttribute('data-tool-slug');
    
    // Create a clone of the tool card
    const cardClone = tool.cloneNode(true);
    
    // Update the title with highlighted search term
    const titleElem = cardClone.querySelector('.tools-portal-card-title');
    if (titleElem) {
        titleElem.innerHTML = highlightSearchTerms(toolName, searchTerm);
    }
    
    // Update the category with highlighted search term
    const categoryElem = cardClone.querySelector('.tools-portal-card-subtitle');
    if (categoryElem) {
        categoryElem.innerHTML = highlightSearchTerms(toolCategory, searchTerm);
    }
    
    // Update the description with highlighted search term
    const descriptionElem = cardClone.querySelector('.tools-portal-card-text');
    if (descriptionElem) {
        // Ensure we show the full description in search results
        let displayDesc = toolDescription;
        descriptionElem.innerHTML = highlightSearchTerms(displayDesc, searchTerm);
    }
    
    // Check if this tool is in the Popular or Recent sections
    // First remove any existing badges to avoid duplicates
    const existingBadge = cardClone.querySelector('.tools-portal-badge');
    if (existingBadge) {
        existingBadge.remove();
    }
    
   // Check if tool has a badge in the original views
const badgeInPopular = document.querySelector('#tools-portal-category-view-popular .tools-portal-card[data-tool-slug="' + toolSlug + '"] .tools-portal-badge-fire');
const badgeInRecent = document.querySelector('#tools-portal-category-view-recent .tools-portal-card[data-tool-slug="' + toolSlug + '"] .tools-portal-badge-new');

// Add badges only if they exist in the original views
if (badgeInPopular) {
    const badge = document.createElement('div');
    badge.className = 'tools-portal-badge tools-portal-badge-fire';
    badge.innerHTML = '<i class="fas fa-fire"></i> HOT';
    cardClone.appendChild(badge);
} else if (badgeInRecent) {
    const badge = document.createElement('div');
    badge.className = 'tools-portal-badge tools-portal-badge-new';
    badge.innerHTML = 'NEW';
    cardClone.appendChild(badge);
}
    
    // Wrap in a column div
    const colDiv = document.createElement('div');
    colDiv.className = 'tools-portal-col';
    colDiv.appendChild(cardClone);
    
    return colDiv;
}

// Function to perform real-time search
function performSearch() {
    const searchTerm = searchInput.value.trim().toLowerCase();
    
    if (searchTerm.length === 0) {
        // Reset to normal view
        searchResults.style.display = 'none';
        categorySections.forEach(section => {
            section.style.display = 'block';
            section.classList.remove('collapsed', 'has-results');
        });
        categoriesPills.style.display = 'block';
        return;
    }
    
    // Show search results section
    searchResults.style.display = 'block';
    
    // Clear previous results
    searchResultsContainer.innerHTML = '';
    
    // Get all tools from the main view only to avoid duplicates
    const mainViewTools = document.querySelectorAll('#tools-portal-main-view .tools-portal-card');
    let matchCount = 0;
    
    // Track which categories have matching tools
    const categoryHasMatch = {};
    
    // Keep track of unique tool slugs to prevent duplicates
    const processedSlugs = new Set();
    
    // Filter tools based on search term
    mainViewTools.forEach(tool => {
        const toolSlug = tool.getAttribute('data-tool-slug');
        
        // Skip if we've already processed this tool
        if (processedSlugs.has(toolSlug)) {
            return;
        }
        
        processedSlugs.add(toolSlug);
        
        const toolName = tool.getAttribute('data-tool-name').toLowerCase();
        const toolCategory = tool.getAttribute('data-tool-category').toLowerCase();
        const toolDescription = tool.getAttribute('data-tool-description').toLowerCase();
        const toolKeywords = (tool.getAttribute('data-tool-keywords') || '').toLowerCase();
        
        // Check if tool matches search term
        if (toolName.includes(searchTerm) || 
            toolCategory.includes(searchTerm) || 
            toolDescription.includes(searchTerm) || 
            toolKeywords.includes(searchTerm)) {
            
            // Add to search results
            const resultCard = createSearchResultCard(tool, searchTerm);
            searchResultsContainer.appendChild(resultCard);
            
            // Track this category as having a match
            categoryHasMatch[toolCategory] = true;
            
            matchCount++;
        }
    });
    
    // Show/hide no results message
    if (matchCount === 0) {
        noResultsMsg.style.display = 'block';
    } else {
        noResultsMsg.style.display = 'none';
    }
    
    // Hide categories in the main view
    categorySections.forEach(section => {
        section.classList.add('collapsed');
    });
    
    // Hide categories scroll pills when searching
    categoriesPills.style.display = 'none';
    
    // Add animation class to search results
    searchResultsContainer.classList.add('tools-portal-search-active');
    
    // Update search result counts
    updateSearchUI(searchTerm);
}

// Search input event listeners
searchInput.addEventListener('input', function() {
    toggleClearButton();
    performSearch();
});

// Clear button event listener
searchClear.addEventListener('click', function() {
    searchInput.value = '';
    toggleClearButton();
    performSearch();
    searchInput.focus();
});

// Initialize clear button state
toggleClearButton();

// Handle Enter key in search input
searchInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        performSearch();
    }
});

// Focus search input when pressing '/' key (common shortcut)
document.addEventListener('keydown', function(e) {
    // Only trigger if not already focused on an input element
    if (e.key === '/' && document.activeElement.tagName !== 'INPUT' && 
        document.activeElement.tagName !== 'TEXTAREA') {
        e.preventDefault();
        searchInput.focus();
    }
    
    // Escape key clears search
    if (e.key === 'Escape' && searchInput.value) {
        searchInput.value = '';
        toggleClearButton();
        performSearch();
    }
});

// Update search result counts and UI
function updateSearchUI(searchTerm) {
    const resultsHeading = document.querySelector('.tools-portal-search-results-heading');
    const count = searchResultsContainer.querySelectorAll('.tools-portal-col').length;
    
    if (count > 0) {
        resultsHeading.textContent = `Found ${count} result${count !== 1 ? 's' : ''} for "${searchTerm}"`;
    } else {
        resultsHeading.textContent = `Search Results`;
    }
}
});

</script>

<?php include_once __DIR__ . '/../footer.php'; ?>