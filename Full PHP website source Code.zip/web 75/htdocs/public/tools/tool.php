<?php
/**
 * Single Tool Display Page
 * 
 * Displays and executes a single tool based on the slug in the URL
 * Includes icon/SVG display and details from JSON file
 * Redesigned for better isolation of tool code from template
 */

require_once __DIR__ . '/../../private/config.php';
require_once __DIR__ . '/../../private/db.php';

// Start the session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Get the tool slug from the URL
$slug = isset($_GET['slug']) ? $_GET['slug'] : null;

if (!$slug) {
    // Redirect to the tools index if no slug is provided
    header('Location: /');
    exit;
}

// Fetch the tool from the database
$tool = dbSelectOne("SELECT t.*, ts.views FROM tools t 
                     LEFT JOIN tool_stats ts ON t.id = ts.tool_id
                     WHERE t.slug = ?", [$slug]);

if (!$tool) {
    // Tool not found
    header('HTTP/1.0 404 Not Found');
    include_once __DIR__ . '/../header.php'; 
    ?>
   <div style="display: flex; justify-content: center; align-items: center; min-height: 100vh; padding: 16px; background-color: white; width: 100%; margin: 0; font-family: Arial, sans-serif; box-sizing: border-box;">
  <div style="max-width: 500px; width: 100%; background-color: #fff; border-radius: 8px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); overflow: hidden; border: 1px solid #e2e8f0; text-align: center;">
    <!-- Error icon - moved up after removing header -->
    <div style="display: flex; justify-content: center; padding: 40px 0 20px;">
      <div style="width: 100px; height: 100px; display: flex; align-items: center; justify-content: center; background-color: rgba(58, 123, 213, 0.1); border-radius: 50%; font-size: 3rem; color: #3a7bd5; box-shadow: 0 5px 15px rgba(58, 123, 213, 0.2);">
        <span>⚠️</span>
      </div>
    </div>
    <!-- Error message -->
    <div style="text-align: center; padding: 0 24px 32px;">
      <h2 style="margin: 0 0 16px; color: #3a7bd5; font-size: 1.8rem;">Tool Not Found</h2>
      <p style="font-size: 1.1rem; color: #4a5568; margin: 0 auto 24px; line-height: 1.5;">We couldn't find the tool you were looking for. It might have been moved or deleted.</p>
      <!-- Action buttons -->
      <div style="display: flex; justify-content: center; flex-wrap: wrap; gap: 16px; margin-top: 24px;">
        <a href="/" style="display: inline-block; padding: 12px 24px; border-radius: 6px; text-decoration: none; font-weight: 600; transition: all 0.25s ease; min-width: 130px; text-align: center; box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1); background: linear-gradient(135deg, #3a7bd5, #2e66c9); color: #fff;">Back to Home</a>
        <a href="/tools/" style="display: inline-block; padding: 12px 24px; border-radius: 6px; text-decoration: none; font-weight: 600; transition: all 0.25s ease; min-width: 130px; text-align: center; box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1); background-color: #f8fafc; color: #3a7bd5; border: 1px solid rgba(58, 123, 213, 0.3);">Browse Tools</a>
      </div>
    </div>
    <!-- Footer with suggestions -->
    <div style="padding: 16px; background-color: #f8fafc; border-top: 1px solid #e2e8f0; text-align: center; color: #4a5568;">
      <p style="margin: 0; font-size: 0.95rem;">Looking for something specific? Try searching or checking our popular tools.</p>
    </div>
  </div>
</div>
    <?php
    include_once __DIR__ . '/../footer.php';
    exit;
}

// Update view count
dbExecute("UPDATE tool_stats SET views = views + 1, last_viewed = NOW() WHERE tool_id = ?", [$tool['id']]);

// Get user ID from session if logged in
$userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0; // 0 for guest users

// Log the tool usage
logToolUsage($userId, $tool['id'], $details);

// Get tool details from JSON file if available
$toolDetails = dbSelectOne("SELECT markdown_content FROM tool_details WHERE tool_id = ?", [$tool['id']]);

// Get tool details from JSON file if available
$toolDetails = dbSelectOne("SELECT markdown_content FROM tool_details WHERE tool_id = ?", [$tool['id']]);
$details = $toolDetails ? $toolDetails['markdown_content'] : null;

// Page title
$pageTitle = htmlspecialchars($tool['name']);

// Function to render tool icon
function renderToolIcon($icon, $iconType, $toolName) {
    if (!$icon || !$iconType) {
        // Default icon if none is provided
        return '<div class="tdp-icon-default"><i class="fas fa-tools"></i></div>';
    }
    
    switch ($iconType) {
        case 'svg':
            return $icon;
        case 'class':
            return '<i class="' . htmlspecialchars($icon) . '" aria-hidden="true"></i>';
        case 'image':
            return '<img src="' . htmlspecialchars('/assets/images/tools/' . $icon) . '" alt="' . htmlspecialchars($toolName) . ' icon" class="tdp-icon-img">';
        default:
            return '<div class="tdp-icon-default"><i class="fas fa-tools"></i></div>';
    }
}

// Get popular tools based on view count
$popularTools = dbSelect("SELECT t.id, t.name, t.slug, t.description, t.icon, t.icon_type, ts.views 
                         FROM tools t 
                         JOIN tool_stats ts ON t.id = ts.tool_id
                         ORDER BY ts.views DESC LIMIT 4");

// Get related tools
$relatedTools = dbSelect(
    "SELECT t.id, t.name, t.slug, t.description, t.icon, t.icon_type FROM tools t 
     WHERE t.category = ? AND t.id != ? 
     ORDER BY RAND() LIMIT 3", 
    [$tool['category'], $tool['id']]
);

// Include header
include_once __DIR__ . '/../header.php';
?>
<!-- Link to external CSS for the tool template -->
<link rel="stylesheet" href="/assets/css/tool-display.css">
<link rel="stylesheet" href="/assets/css/markdown-extra.css">

<div class="tdp-wrapper">
    <div class="tdp-container">
        <!-- 1. Breadcrumb navigation -->
        <nav aria-label="breadcrumb">
            <ol class="tdp-breadcrumb">
                <li class="tdp-breadcrumb-item"><a href="<?php echo SITE_URL; ?>">Home</a></li>
                <li class="tdp-breadcrumb-item"><a href="<?php echo SITE_URL; ?>/tools/">Tools</a></li>
                <li class="tdp-breadcrumb-item"><?php echo htmlspecialchars($tool['category']); ?></li>
                <li class="tdp-breadcrumb-item"><?php echo htmlspecialchars($tool['name']); ?></li>
            </ol>
        </nav>

        <!-- 2. Tool title and description -->
<div class="tdp-header-section">
    <div class="tdp-title-wrapper">
        <div class="tdp-icon">
            <?php echo renderToolIcon($tool['icon'], $tool['icon_type'], $tool['name']); ?>
        </div>
        <h1 class="tdp-title"><?php echo htmlspecialchars($tool['name']); ?></h1>
    </div>
    <p class="tdp-description"><?php echo htmlspecialchars($tool['description']); ?></p>
    <div class="tdp-separator"></div>
</div>
        
        <!-- 3. Main tool content - No container here to prevent CSS conflicts -->
        <div class="tdp-content-box">
            
            <div class="tdp-content">
                <?php
                $toolFile = PUBLIC_PATH . $tool['file_path'];
                if (file_exists($toolFile)) {
                    // Start output buffering to capture any errors
                    ob_start();
                    try {
                        include $toolFile;
                    } catch (Exception $e) {
                        echo '<div class="tdp-alert-danger">Error loading tool: ' . htmlspecialchars($e->getMessage()) . '</div>';
                    }
                    $content = ob_get_clean();
                    echo $content;
                } else {
                    echo '<div class="tdp-alert-danger">Tool file not found.</div>';
                }
                ?>
            </div>
        </div>
        
       <!-- 4. Markdown file content (Tool details) -->
<?php if ($details): ?>
<div class="tdp-details-box">
    <div class="tdp-details-content">
        <?php
        // Include Parsedown libraries
        require_once __DIR__ . '/../../private/lib/Parsedown/Parsedown.php';
        require_once __DIR__ . '/../../private/lib/Parsedown/ParsedownExtra.php';
        
        // Initialize ParsedownExtra
        $parsedown = new ParsedownExtra();
        
        // Render markdown content using Parsedown Extra
        $htmlContent = $parsedown->text($details);
        
        echo '<div class="tdp-details-grid">';
        echo $htmlContent;
        echo '</div>';
        ?>
    </div>
</div>
<?php endif; ?>
        
      <!-- 5. Social sharing section -->
<div class="tdp-sharing-box">
    <div class="tdp-sharing-header">
        <h3>Share This Tool</h3>
    </div>
    <div class="tdp-sharing-content">
        <div class="tdp-social-buttons">
            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode(SITE_URL . '/tools/' . $slug); ?>" class="tdp-social-btn tdp-facebook-btn" target="_blank" aria-label="Share on Facebook">
                <i class="fab fa-facebook-f"></i>
                <span class="tdp-btn-text">Facebook</span>
            </a>
            <a href="https://twitter.com/intent/tweet?url=<?php echo urlencode(SITE_URL . '/tools/' . $slug); ?>&text=<?php echo urlencode('Check out this awesome tool: ' . $tool['name']); ?>" class="tdp-social-btn tdp-twitter-btn" target="_blank" aria-label="Share on Twitter">
                <i class="fab fa-twitter"></i>
                <span class="tdp-btn-text">Twitter</span>
            </a>
            <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo urlencode(SITE_URL . '/tools/' . $slug); ?>&title=<?php echo urlencode($tool['name']); ?>" class="tdp-social-btn tdp-linkedin-btn" target="_blank" aria-label="Share on LinkedIn">
                <i class="fab fa-linkedin-in"></i>
                <span class="tdp-btn-text">LinkedIn</span>
            </a>
            <a href="mailto:?subject=<?php echo urlencode('Check out this tool: ' . $tool['name']); ?>&body=<?php echo urlencode('I found this useful tool that you might like: ' . $tool['name'] . ' - ' . SITE_URL . '/tools/' . $slug); ?>" class="tdp-social-btn tdp-email-btn" target="_blank" aria-label="Share via Email">
                <i class="fas fa-envelope"></i>
                <span class="tdp-btn-text">Email</span>
            </a>

            <!-- Telegram -->
<a href="https://t.me/share/url?url=<?php echo urlencode(SITE_URL . '/tools/' . $slug); ?>&text=<?php echo urlencode('Check out this awesome tool: ' . $tool['name']); ?>" class="tdp-social-btn tdp-telegram-btn" target="_blank" aria-label="Share on Telegram">
    <i class="fab fa-telegram-plane"></i>
    <span class="tdp-btn-text">Telegram</span>
</a>

<!-- WhatsApp -->
<a href="https://api.whatsapp.com/send?text=<?php echo urlencode('Check out this awesome tool: ' . $tool['name'] . ' - ' . SITE_URL . '/tools/' . $slug); ?>" class="tdp-social-btn tdp-whatsapp-btn" target="_blank" aria-label="Share on WhatsApp">
    <i class="fab fa-whatsapp"></i>
    <span class="tdp-btn-text">WhatsApp</span>
</a>

<!-- Pinterest -->
<a href="https://pinterest.com/pin/create/button/?url=<?php echo urlencode(SITE_URL . '/tools/' . $slug); ?>&description=<?php echo urlencode($tool['name'] . ' - ' . $tool['description']); ?>" class="tdp-social-btn tdp-pinterest-btn" target="_blank" aria-label="Share on Pinterest">
    <i class="fab fa-pinterest-p"></i>
    <span class="tdp-btn-text">Pinterest</span>
</a>

<!-- Reddit -->
<a href="https://www.reddit.com/submit?url=<?php echo urlencode(SITE_URL . '/tools/' . $slug); ?>&title=<?php echo urlencode($tool['name']); ?>" class="tdp-social-btn tdp-reddit-btn" target="_blank" aria-label="Share on Reddit">
    <i class="fab fa-reddit-alien"></i>
    <span class="tdp-btn-text">Reddit</span>
</a>

            <button class="tdp-social-btn tdp-copy-btn" onclick="copyToolLink('<?php echo SITE_URL . '/tools/' . $slug; ?>')">
                <i class="fas fa-link"></i>
                <span class="tdp-btn-text">Copy Link</span>
            </button>
 
        </div>
    </div>
</div>

<!-- Toast notification for copy confirmation -->
<div id="tdp-copy-toast" class="tdp-toast">Link copied to clipboard!</div>
        
        <!-- 6. Popular tools (by view count) -->
        <?php if (!empty($popularTools)): ?>
        <div class="tdp-tools-section">
            <div class="tdp-tools-header">
                <h3>Popular Tools</h3>
            </div>
            <div class="tdp-tools-content">
                <div class="tdp-tools-grid">
                    <?php foreach ($popularTools as $popularTool): ?>
                        <?php if($popularTool['id'] != $tool['id']): ?>
                        <div class="tdp-tool-card">
                            <div class="tdp-card-body">
                                <div class="tdp-card-header">
                                    <div class="tdp-card-icon">
                                        <?php echo renderToolIcon($popularTool['icon'], $popularTool['icon_type'], $popularTool['name']); ?>
                                    </div>
                                    <h5 class="tdp-card-title"><?php echo htmlspecialchars($popularTool['name']); ?></h5>
                                </div>
                                <p class="tdp-card-description">
                                    <?php 
                                    $description = htmlspecialchars($popularTool['description']);
                                    echo (strlen($description) > 80) ? substr($description, 0, 77) . '...' : $description;
                                    ?>
                                </p>
                            </div>
                            <div class="tdp-card-footer">
                                <a href="tool.php?slug=<?php echo urlencode($popularTool['slug']); ?>" class="tdp-card-button">Try this tool</a>
                            </div>
                        </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- 7. Related tools -->
        <?php if (!empty($relatedTools)): ?>
        <div class="tdp-tools-section">
            <div class="tdp-tools-header">
                <h3>Related Tools</h3>
            </div>
            <div class="tdp-tools-content">
                <div class="tdp-tools-grid">
                    <?php foreach ($relatedTools as $relatedTool): ?>
                    <div class="tdp-tool-card">
                        <div class="tdp-card-body">
                            <div class="tdp-card-header">
                                <div class="tdp-card-icon">
                                    <?php echo renderToolIcon($relatedTool['icon'], $relatedTool['icon_type'], $relatedTool['name']); ?>
                                </div>
                                <h5 class="tdp-card-title"><?php echo htmlspecialchars($relatedTool['name']); ?></h5>
                            </div>
                            <p class="tdp-card-description">
                                <?php 
                                $description = htmlspecialchars($relatedTool['description']);
                                echo (strlen($description) > 80) ? substr($description, 0, 77) . '...' : $description;
                                ?>
                            </p>
                        </div>
                        <div class="tdp-card-footer">
                            <a href="tool.php?slug=<?php echo urlencode($relatedTool['slug']); ?>" class="tdp-card-button">Try this tool</a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- 8. Contact us button -->
        <div class="tdp-contact-section">
            <a href="<?php echo SITE_URL; ?>/page/contact" class="tdp-contact-button">Contact Us</a>
        </div>
    </div>
</div>

<script>
// Isolated JS function for the tool template
// Function to copy tool link to clipboard with visual feedback
function copyToolLink(text) {
    // Try to use the modern clipboard API first
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text)
            .then(() => showToast('Link copied to clipboard!'))
            .catch(err => {
                console.error('Failed to copy: ', err);
                fallbackCopyToClipboard(text);
            });
    } else {
        // Fallback for browsers that don't support the Clipboard API
        fallbackCopyToClipboard(text);
    }
}

// Fallback copy method using document.execCommand
function fallbackCopyToClipboard(text) {
    // Create a temporary input element
    const tempInput = document.createElement('input');
    tempInput.style.position = 'absolute';
    tempInput.style.left = '-9999px'; // Position offscreen
    tempInput.value = text;
    document.body.appendChild(tempInput);
    
    // Select and copy the text
    tempInput.select();
    tempInput.setSelectionRange(0, 99999); // For mobile devices
    
    try {
        // Execute copy command
        const successful = document.execCommand('copy');
        if (successful) {
            showToast('Link copied to clipboard!');
        } else {
            showToast('Unable to copy link', 'error');
        }
    } catch (err) {
        console.error('Error copying text: ', err);
        showToast('Failed to copy link. Please try again.', 'error');
    }
    
    // Remove the temporary input
    document.body.removeChild(tempInput);
}

// Function to display toast notifications
function showToast(message, type = 'success') {
    let toast = document.getElementById('tdp-copy-toast');
    
    if (!toast) {
        // Create toast if it doesn't exist
        toast = document.createElement('div');
        toast.id = 'tdp-copy-toast';
        toast.className = 'tdp-toast';
        document.body.appendChild(toast);
    }
    
    // Set toast message and add class based on type
    toast.textContent = message;
    toast.className = 'tdp-toast';
    if (type === 'error') {
        toast.classList.add('tdp-toast-error');
    }
    
    // Show the toast
    setTimeout(() => {
        toast.classList.add('show');
        // Hide toast after 3 seconds
        setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    }, 10);
}

// Add event listeners for keyboard users
document.addEventListener('DOMContentLoaded', function() {
    const socialButtons = document.querySelectorAll('.tdp-social-btn');
    
    socialButtons.forEach(button => {
        if (button.tagName.toLowerCase() === 'button') {
            button.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    button.click();
                }
            });
        }
    });
});

</script>

<?php
// Include footer
include_once __DIR__ . '/../footer.php';
?>