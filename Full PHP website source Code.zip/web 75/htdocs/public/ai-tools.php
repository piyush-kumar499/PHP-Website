<?php

// This would typically connect to your database or include necessary PHP files
// $tools = [Your tools data would be fetched here];
include 'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include_once ('../private/favicon.php'); ?>
    <title> Advance Tools</title>
    <style>
    :root {
        --primary-color: #6b46c1;
        --secondary-color: #f6f8fa;
        --accent-color: #4c8df6;
        --text-dark: #1a202c;
        --text-light: #4a5568;
        --background-light: #ffffff;
        --transition-speed: 0.3s;
        --box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
        --box-shadow-hover: 0 20px 25px -5px rgba(0, 0, 0, 0.15);
        --section-spacing: 2rem;
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,
            Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        background-color: var(--secondary-color);
        color: var(--text-dark);
        line-height: 1.6;
    }

    .tools-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 2rem 1rem;
        width: 100%;
    }

    .tools-hero {
        text-align: center;
        margin-bottom: var(--section-spacing);
        border-radius: 20px;
        overflow: hidden;
        background-color: var(--background-light);
        padding: 3rem 2rem;
        max-width: 1200px;
        box-shadow: var(--box-shadow);
        position: relative;
    }

    .tools-hero::before {
        content: '';
        position: absolute;
        top: 0;
        right: 0;
        width: 150px;
        height: 150px;
        background-image: url('assets/images/pattern.svg');
        background-repeat: no-repeat;
        opacity: 0.1;
        z-index: 0;
    }

    .tools-hero-content {
        max-width: 800px;
        margin: 0 auto;
        position: relative;
        z-index: 1;
    }

    .tools-hero-title {
        font-size: 3.2rem;
        font-weight: 800;
        color: var(--text-dark);
        margin-bottom: 1rem;
        background: linear-gradient(to right, #6a11cb, #2575fc);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        line-height: 1.2;
    }

    .tools-hero-subtitle {
        font-size: 1.25rem;
        color: var(--text-light);
        margin-bottom: 2rem;
        max-width: 700px;
        margin-left: auto;
        margin-right: auto;
    }

    /* Search bar styling */
    .search-container {
        position: relative;
        max-width: 600px;
        margin: 0 auto 2.5rem;
        z-index: 100; /* Added higher z-index to ensure it stays above other elements */
    }

    .search-input {
        width: 100%;
        padding: 1rem 1.5rem;
        font-size: 1rem;
        border: 2px solid rgba(107, 70, 193, 0.2);
        border-radius: 50px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        transition: all var(--transition-speed) ease;
    }

    .search-input:focus {
        outline: none;
        border-color: var(--primary-color);
        box-shadow: 0 4px 15px rgba(107, 70, 193, 0.2);
    }

    .search-icon {
        position: absolute;
        right: 1.5rem;
        top: 50%;
        transform: translateY(-50%);
        color: var(--primary-color);
        pointer-events: none;
    }

    .search-results {
        position: absolute;
        top: 100%;
        left: 0;
        width: 100%;
        background: white;
        border-radius: 0.75rem;
        box-shadow: var(--box-shadow);
        z-index: 100; /* Increased z-index */
        max-height: 0;
        overflow: hidden;
        transition: max-height var(--transition-speed) ease;
    }

    .search-results.active {
        max-height: 400px;
        overflow-y: auto;
        margin-top: 0.5rem;
    }

    .result-item {
        padding: 1rem;
        border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        cursor: pointer;
        transition: background-color var(--transition-speed) ease;
    }

    .result-item:hover {
        background-color: rgba(107, 70, 193, 0.05);
    }

    .result-item:last-child {
        border-bottom: none;
    }

    .result-title {
        font-weight: 600;
        color: var(--text-dark);
        margin-bottom: 0.25rem;
    }

    .result-description {
        font-size: 0.875rem;
        color: var(--text-light);
    }

    /* Tools grid */
    .tools-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
        gap: 1.5rem;
        margin-bottom: 3rem;
        position: relative;
        z-index: 1; /* Lower z-index than search */
    }

    .tool-card {
        background-color: var(--background-light);
        padding: 1.75rem;
        border-radius: 1rem;
        text-align: center;
        box-shadow: var(--box-shadow);
        transition: all var(--transition-speed) ease;
        position: relative;
        overflow: hidden;
        display: flex;
        flex-direction: column;
        height: 100%;
    }

    /* Style for the tool card link */
    .tool-card a {
        text-decoration: none;
        color: inherit;
        display: flex;
        flex-direction: column;
        height: 100%;
        width: 100%;
    }

    .tool-card::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 3px;
        background: linear-gradient(to right, #6a11cb, #2575fc);
        transform: scaleX(0);
        transform-origin: left;
        transition: transform 0.3s ease;
    }

    .tool-card:hover {
        transform: translateY(-10px);
        box-shadow: var(--box-shadow-hover);
    }

    .tool-card:hover::after {
        transform: scaleX(1);
    }

    .tool-icon {
        color: var(--primary-color);
        width: 3.5rem;
        height: 3.5rem;
        margin: 0 auto 1.25rem;
        transition: transform 0.3s ease;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .tool-icon svg {
        width: 100%;
        height: 100%;
    }

    .tool-card:hover .tool-icon {
        transform: scale(1.1);
    }

    .tool-title {
        font-size: 1.25rem;
        margin-bottom: 0.75rem;
        color: var(--text-dark);
    }

    .tool-description {
        color: var(--text-light);
        margin-top: auto;
    }

    /* Load more button */
    .load-more-container {
        text-align: center;
        margin: 2rem 0 3rem;
    }

    .load-more-btn {
        background: linear-gradient(to right, #6a11cb, #2575fc);
        color: white;
        border: none;
        padding: 0.75rem 2.5rem;
        border-radius: 50px;
        font-size: 1rem;
        font-weight: 600;
        cursor: pointer;
        transition: all var(--transition-speed) ease;
        box-shadow: 0 4px 10px rgba(107, 70, 193, 0.3);
    }

    .load-more-btn:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(107, 70, 193, 0.4);
    }

    .load-more-btn:focus {
        outline: none;
    }

    /* Animation for tool cards */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .tool-card {
        animation: fadeInUp 0.8s ease-out forwards;
        opacity: 0;
    }

    .tool-card:nth-child(1) { animation-delay: 0.1s; }
    .tool-card:nth-child(2) { animation-delay: 0.2s; }
    .tool-card:nth-child(3) { animation-delay: 0.3s; }
    .tool-card:nth-child(4) { animation-delay: 0.4s; }
    .tool-card:nth-child(5) { animation-delay: 0.5s; }
    .tool-card:nth-child(6) { animation-delay: 0.6s; }

    /* Loading animation */
    .loader {
        display: none;
        width: 48px;
        height: 48px;
        border: 5px solid #6b46c1;
        border-bottom-color: transparent;
        border-radius: 50%;
        margin: 0 auto;
        animation: rotation 1s linear infinite;
    }

    @keyframes rotation {
        0% {
            transform: rotate(0deg);
        }
        100% {
            transform: rotate(360deg);
        }
    }

    /* Responsive Design */
    @media screen and (max-width: 1200px) {
        .tools-grid {
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        }
    }

    @media screen and (max-width: 1024px) {
        .tools-hero-title {
            font-size: 2.8rem;
        }
    }

    @media screen and (max-width: 768px) {
        .tools-grid {
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 1.25rem;
        }
        
        .tools-hero-title {
            font-size: 2.5rem;
        }
        
        .tools-hero {
            padding: 2.5rem 1.5rem;
        }
    }

    @media screen and (max-width: 640px) {
        .tools-grid {
            grid-template-columns: 1fr;
        }
    }

    @media screen and (max-width: 480px) {
        .tools-hero {
            padding: 2rem 1rem;
        }
        
        .tools-hero-title {
            font-size: 2rem;
        }
        
        .tools-hero-subtitle {
            font-size: 1rem;
        }
        
        .tool-card {
            padding: 1.5rem;
        }
        
        .search-input {
            padding: 0.875rem 1.25rem;
        }
        
        .search-icon {
            right: 1.25rem;
        }
    }
    </style>
</head>
<body>
    <main class="tools-container">
        <section class="tools-hero">
            <div class="tools-hero-content">
                <h1 class="tools-hero-title">All Tools</h1>
                <p class="tools-hero-subtitle">Discover our comprehensive collection of powerful tools to enhance your productivity and creativity</p>
            </div>
        </section>

        <!-- Search bar -->
        <div class="search-container">
            <input type="text" class="search-input" placeholder="Search for tools..." id="toolSearch">
            <svg xmlns="http://www.w3.org/2000/svg" class="search-icon" width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <div class="search-results" id="searchResults">
                <!-- Search results will be populated here dynamically -->
            </div>
        </div>
        
        <!-- Tools grid -->
        <section class="tools-grid" id="toolsGrid">
            <!-- Tool cards will be populated here dynamically from JavaScript -->
        </section>

        <!-- Loading animation -->
        <div class="loader" id="loader"></div>

        <!-- Load more button -->
        <div class="load-more-container">
            <button class="load-more-btn" id="loadMoreBtn">Load More</button>
        </div>
    </main>

    <script>
        // Sample tools data (in a real application, this would come from your backend)
        const allTools = [
            {
                id: 1,
                title: "Text Editor",
                description: "A powerful text editor with syntax highlighting and AI-powered suggestions.",
                icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>',
                url: '/tools/text-editor.php' // Added URL for the tool
            },
            {
                id: 2,
                title: "Image Optimizer",
                description: "Compress and optimize your images without losing quality for faster websites.",
                icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>',
                url: '/tools/image-optimizer.php'
            },
            {
                id: 3,
                title: "SEO Analyzer",
                description: "Analyze your content for SEO improvements and get actionable recommendations.",
                icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>',
                url: '/tools/seo-analyzer.php'
            },
            {
                id: 4,
                title: "Code Generator",
                description: "Generate clean, optimized code snippets for various programming languages.",
                icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" /></svg>',
                url: '/tools/code-generator.php'
            },
            {
                id: 5,
                title: "Color Palette Generator",
                description: "Create beautiful color palettes for your design projects with AI assistance.",
                icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" /></svg>',
                url: '/tools/color-palette.php'
            },
            {
                id: 6,
                title: "PDF Converter",
                description: "Convert documents to and from PDF format with ease and precision.",
                icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>',
                url: '/tools/pdf-converter.php'
            },
            {
                id: 7,
                title: "Data Visualizer",
                description: "Create beautiful and interactive charts and graphs from your data.",
                icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 8v8m-4-5v5m-4-2v2m-2 4h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>',
                url: '/tools/data-visualizer.php'
            },
            {
                id: 8,
                title: "Password Generator",
                description: "Generate secure, random passwords with customizable settings.",
                icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>',
                url: '/tools/password-generator.php'
            },
            {
                id: 9,
                title: "Form Builder",
                description: "Create professional forms with validation, logic, and analytics.",
                icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>',
                url: '/tools/form-builder.php'
            },
            {
                id: 10,
                title: "QR Code Generator",
                description: "Generate custom QR codes for links, text, contacts, and more.",
                icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z" /></svg>',
                url: '/tools/qr-code-generator.php'
            },
            {
                id: 11,
                title: "Website Speed Test",
                description: "Analyze your website's loading speed and get suggestions for improvement.",
                icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>',
                url: '/tools/speed-test.php'
            },
            {
                id: 12,
                title: "Email Signature Creator",
                description: "Design professional email signatures with customizable templates.",
                icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>',
                url: '/tools/email-signature.php'
            }
        ];

        // Variables
        const toolsGrid = document.getElementById('toolsGrid');
        const loadMoreBtn = document.getElementById('loadMoreBtn');
        const loader = document.getElementById('loader');
        const searchInput = document.getElementById('toolSearch');
        const searchResults = document.getElementById('searchResults');
        
        let currentPage = 1;
        const toolsPerPage = 6;
        let filteredTools = [...allTools];

        // Initialize the page
        window.addEventListener('DOMContentLoaded', () => {
            loadTools();
            initializeSearch();
        });

        // Load tools function
        function loadTools() {
            const startIndex = (currentPage - 1) * toolsPerPage;
            const endIndex = startIndex + toolsPerPage;
            const toolsToShow = filteredTools.slice(startIndex, endIndex);
            
            // Check if there are more tools to load
            if (endIndex >= filteredTools.length) {
                loadMoreBtn.style.display = 'none';
            } else {
                loadMoreBtn.style.display = 'inline-block';
            }
            
            // Generate HTML for each tool
            toolsToShow.forEach((tool, index) => {
                const toolCard = document.createElement('div');
                toolCard.className = 'tool-card';
                toolCard.style.animationDelay = `${0.1 * (index + 1)}s`;
                
                // Make the tool card clickable by wrapping it in an anchor tag
                toolCard.innerHTML = `
                    <a href="${tool.url}" title="Open ${tool.title}">
                        <div class="tool-icon">${tool.icon}</div>
                        <h3 class="tool-title">${tool.title}</h3>
                        <p class="tool-description">${tool.description}</p>
                    </a>
                `;
                
                toolsGrid.appendChild(toolCard);
            });
        }

        // Load more tools
        loadMoreBtn.addEventListener('click', () => {
            // Show loading animation
            loader.style.display = 'block';
            loadMoreBtn.style.display = 'none';
            
            // Simulate loading delay
            setTimeout(() => {
                currentPage++;
                loadTools();
                loader.style.display = 'none';
            }, 800);
        });

        // Initialize search functionality
        function initializeSearch() {
            searchInput.addEventListener('input', handleSearch);
            searchInput.addEventListener('focus', () => {
                if (searchResults.children.length > 0) {
                    searchResults.classList.add('active');
                }
            });
            
            // Close search results when clicking outside
            document.addEventListener('click', (e) => {
                if (!searchInput.contains(e.target) && !searchResults.contains(e.target)) {
                    searchResults.classList.remove('active');
                }
            });
        }

        // Handle search input
        function handleSearch() {
            const searchTerm = searchInput.value.toLowerCase().trim();
            
            if (searchTerm === '') {
                searchResults.innerHTML = '';
                searchResults.classList.remove('active');
                return;
            }
            
            // Filter tools based on search term
            const matchingTools = allTools.filter(tool => 
                tool.title.toLowerCase().includes(searchTerm) || 
                tool.description.toLowerCase().includes(searchTerm)
            );
            
            // Display search results
            displaySearchResults(matchingTools);
        }

        // Display search results
        function displaySearchResults(results) {
            searchResults.innerHTML = '';
            
            if (results.length === 0) {
                const noResults = document.createElement('div');
                noResults.className = 'result-item';
                noResults.innerHTML = `
                    <div class="result-title">No tools found</div>
                    <div class="result-description">Try a different search term</div>
                `;
                searchResults.appendChild(noResults);
            } else {
                results.forEach(tool => {
                    const resultItem = document.createElement('div');
                    resultItem.className = 'result-item';
                    resultItem.innerHTML = `
                        <div class="result-title">${tool.title}</div>
                        <div class="result-description">${tool.description}</div>
                    `;
                    
                    // Add click event to navigate to the tool
                    resultItem.addEventListener('click', () => {
                        // Navigate to the tool page
                        window.location.href = tool.url;
                    });
                    
                    searchResults.appendChild(resultItem);
                });
            }
            
            searchResults.classList.add('active');
        }

        // Highlight a tool in the grid
        function highlightTool(toolId) {
            // Reset first
            resetToolsGrid();
            
            // Filter for the selected tool
            filteredTools = allTools.filter(tool => tool.id === toolId);
            
            // Reset page and load the filtered tool
            currentPage = 1;
            toolsGrid.innerHTML = '';
            loadTools();
            
            // Scroll to tools grid
            toolsGrid.scrollIntoView({ behavior: 'smooth' });
        }

        // Reset tools grid to show all tools
        function resetToolsGrid() {
            filteredTools = [...allTools];
            currentPage = 1;
            toolsGrid.innerHTML = '';
            loadTools();
        }

        // Add a reset button event listener (could be added to a clear button in the search)
        searchInput.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' || (e.key === 'Backspace' && searchInput.value === '')) {
                searchResults.classList.remove('active');
                resetToolsGrid();
            }
        });
    </script>
</body>
</html>