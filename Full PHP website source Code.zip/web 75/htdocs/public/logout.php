<?php
session_start();
require_once($_SERVER['DOCUMENT_ROOT'] . '/private/messages.php');
require_once($_SERVER['DOCUMENT_ROOT'] . '/private/auth.php');

// Check if confirmed parameter exists
if (isset($_GET['confirm']) && $_GET['confirm'] === '1') {
    // Set logout message
    set_success_message('You have been successfully logged out.');

    // Log out the user
    logoutUser();

    // Redirect to the main homepage
    header("Location: /");
    exit();
} else {
    // Redirect to the previous page or homepage if no confirmation
    $redirect_url = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '/';
    header("Location: $redirect_url");
    exit();
}