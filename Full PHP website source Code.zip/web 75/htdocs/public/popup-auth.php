<?php
session_start();
$isAuthenticated = isset($_SESSION['user_id']);

// Only continue for non-authenticated users - all popups are skipped for authenticated users
if (!$isAuthenticated) {
    
    if (!isset($popupTimeLimit)) {
        $popupTimeLimit = 3; // Default time limit in hours
    }

    if (!isset($showOnEveryReload)) {
        $showOnEveryReload = false; // Default is not to show on every reload
    }

    if (!isset($isMandatoryPage)) {
        $isMandatoryPage = false; // Default is not mandatory
    }
    
    // Cookie management
    $showPopup = false;
    $currentTime = time();
    
    // If set to show on every reload, always show the popup
    if ($showOnEveryReload) {
        $showPopup = true;
    } 
    // If mandatory page, always show
    else if ($isMandatoryPage) {
        $showPopup = true;
    }
    // Time-based logic
    else {
        // Check for existing cookie and time passed
        if (isset($_COOKIE['auth_popup_last_shown'])) {
            $lastShown = (int)$_COOKIE['auth_popup_last_shown'];
            $timePassedHours = ($currentTime - $lastShown) / 3600;
            
            // Debug: Uncomment to check time calculations
            // error_log("Time passed: $timePassedHours hours, Limit: $popupTimeLimit hours");
            
            if ($timePassedHours >= $popupTimeLimit) {
                $showPopup = true;
            }
        } else {
            // First visit - no cookie exists
            $showPopup = true;
        }
    }
    
    if ($showPopup && !$showOnEveryReload) {
        setcookie('auth_popup_last_shown', $currentTime, time() + 30 * 24 * 60 * 60, '/');
    }
?>
<style>
/* Auth Popup Variables */
:root {
    --primary-color: #6366f1;
    --primary-dark: #4f46e5;
    --primary-light: #818cf8;
    --secondary-color: #10b981;
    --secondary-dark: #059669;
    --text-dark: #1f2937;
    --text-light: #6b7280;
    --text-white: #ffffff;
    --background-light: #ffffff;
    --background-gray: #f3f4f6;
    --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
    --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    --border-radius-sm: 4px;
    --border-radius-md: 8px;
    --border-radius-lg: 12px;
    --border-color: #e5e7eb;
    --transition-fast: 0.2s ease;
    --transition-normal: 0.3s ease;
    --transition-slow: 0.5s ease;
}

/* Auth Popup Overlay */
.auth-popup-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.65);
    display: none;
    justify-content: center;
    align-items: center;
    z-index: 9999;
    -webkit-backdrop-filter: blur(4px);
    backdrop-filter: blur(4px);
    opacity: 0;
    transition: opacity var(--transition-normal);
}

.auth-popup-overlay.active {
    opacity: 1;
}

/* Auth Popup Container */
.auth-popup-container {
    background-color: var(--background-light);
    border-radius: var(--border-radius-lg);
    box-shadow: var(--shadow-lg);
    width: 95%;
    max-width: 450px;
    overflow: hidden;
    opacity: 0;
    transform: scale(0.95) translateY(-20px);
    transition: all var(--transition-normal);
    position: relative;
    border: 1px solid var(--border-color);
}

.auth-popup-overlay.active .auth-popup-container {
    opacity: 1;
    transform: scale(1) translateY(0);
}

/* Auth Popup Header */
.auth-popup-header {
    padding: 25px 30px 15px;
    text-align: center;
    position: relative;
}

.auth-popup-header h2 {
    margin: 0;
    font-size: 28px;
    font-weight: 700;
    background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    color: transparent;
    letter-spacing: -0.5px;
}

.auth-popup-header .auth-popup-tagline {
    margin-top: 8px;
    font-size: 14px;
    color: var(--text-light);
    font-weight: 500;
}

.auth-popup-close {
    background: rgba(99, 102, 241, 0.05);
    border: 1px solid rgba(99, 102, 241, 0.1);
    font-size: 25px;
    cursor: pointer;
    color: var(--text-light);
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    position: absolute;
    top: 16px;
    right: 16px;
    width: 36px;
    height: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
    overflow: hidden;
    z-index: 10;
}

.auth-popup-close span {
    line-height: 1;
    position: relative;
    z-index: 2;
    transition: all 0.3s ease;
}

.auth-popup-close::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
    opacity: 0;
    transition: opacity 0.3s ease;
    z-index: 1;
}

.auth-popup-close:hover {
    transform: rotate(90deg) scale(1.1);
    border-color: rgba(99, 102, 241, 0.2);
    box-shadow: 0 3px 10px rgba(99, 102, 241, 0.2);
}

.auth-popup-close:hover::before {
    opacity: 1;
}

.auth-popup-close:hover span {
    color: var(--text-white);
}

/* Auth Popup Body */
.auth-popup-body {
    padding: 15px 30px 30px;
    text-align: center;
}

.auth-popup-body p {
    margin-bottom: 30px;
    font-size: 16px;
    color: var(--text-light);
    line-height: 1.6;
}

/* Auth Benefits List */
.auth-benefits {
    list-style: none;
    padding: 0;
    margin: 0 0 25px;
    text-align: left;
}

.auth-benefit-item {
    display: flex;
    align-items: center;
    padding: 8px 0;
    color: var(--text-light);
    font-size: 14px;
}

.auth-benefit-icon {
    margin-right: 12px;
    width: 20px;
    height: 20px;
    background-color: rgba(99, 102, 241, 0.1);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--primary-color);
}

/* Auth Buttons */
.auth-popup-buttons {
    display: flex;
    justify-content: space-between;
    gap: 15px;
    margin-top: 20px;
}

.auth-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    padding: 12px 16px;
    border-radius: var(--border-radius-md);
    font-size: 16px;
    font-weight: 600;
    text-align: center;
    text-decoration: none;
    transition: all var(--transition-normal);
    box-shadow: var(--shadow-sm);
    position: relative;
    overflow: hidden;
    z-index: 1;
    letter-spacing: 0.3px;
}

.auth-btn-icon {
    margin-right: 8px;
    font-size: 18px;
}

.auth-btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(to right, rgba(255, 255, 255, 0), rgba(255, 255, 255, 0.3), rgba(255, 255, 255, 0));
    transition: all 0.6s ease;
    z-index: -1;
}

.auth-btn:hover::before {
    left: 100%;
}

.auth-login-btn {
    background: rgba(99, 102, 241, 0.1);
    color: var(--primary-color);
    border: 1px solid rgba(99, 102, 241, 0.2);
}

.auth-login-btn:hover {
    transform: translateY(-3px);
    box-shadow: var(--shadow-md);
    background: rgba(99, 102, 241, 0.15);
    border-color: rgba(99, 102, 241, 0.3);
}

.auth-signup-btn {
    background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
    color: var(--text-white);
    border: none;
}

.auth-signup-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 20px rgba(99, 102, 241, 0.4);
    background: linear-gradient(135deg, var(--primary-light), var(--primary-color));
}

.auth-btn:active {
    transform: translateY(-1px);
    box-shadow: var(--shadow-sm);
}

/* Social Logins */
.auth-social-divider {
    display: flex;
    align-items: center;
    margin: 25px 0 20px;
    color: var(--text-light);
    font-size: 14px;
}

.auth-social-divider::before,
.auth-social-divider::after {
    content: "";
    flex: 1;
    height: 1px;
    background-color: var(--border-color);
}

.auth-social-divider::before {
    margin-right: 15px;
}

.auth-social-divider::after {
    margin-left: 15px;
}

.auth-social-buttons {
    display: flex;
    justify-content: center;
    gap: 15px;
    margin-bottom: 20px;
}

.auth-social-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 44px;
    height: 44px;
    border-radius: 50%;
    background-color: var(--background-gray);
    color: var(--text-dark);
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    text-decoration: none;
    border: 1px solid var(--border-color);
    position: relative;
    overflow: hidden;
    z-index: 1;
}

.auth-social-btn i {
    font-size: 18px;
    position: relative;
    z-index: 2;
    transition: color 0.3s ease;
}

.auth-social-btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    opacity: 0;
    transition: opacity 0.3s ease;
    z-index: 1;
}

.auth-social-btn:hover {
    transform: translateY(-2px) scale(1.05);
    box-shadow: var(--shadow-md);
    border-color: rgba(99, 102, 241, 0.2);
}

.auth-social-btn:hover i {
    color: var(--text-white);
}

.auth-social-btn:hover::before {
    opacity: 1;
}

/* Brand-specific gradients for social buttons */
.auth-social-btn[href*="google"]::before {
    background: linear-gradient(135deg, #4285F4, #34A853);
}

.auth-social-btn[href*="facebook"]::before {
    background: linear-gradient(135deg, #3b5998, #1877f2);
}

.auth-social-btn[href*="twitter"]::before {
    background: linear-gradient(135deg, #1da1f2, #0c85d0);
}

.auth-social-btn[href*="apple"]::before {
    background: linear-gradient(135deg, #555, #111);
}

/* Terms Text */
.auth-terms-text {
    font-size: 12px;
    color: var(--text-light);
    margin-top: 20px;
}

.auth-terms-text a {
    color: var(--primary-color);
    text-decoration: none;
    transition: color var(--transition-fast);
}

.auth-terms-text a:hover {
    color: var(--primary-dark);
    text-decoration: underline;
}

/* Hide close button when mandatory */
.auth-popup-mandatory .auth-popup-close {
    display: none;
}

/* Animation for benefits */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.auth-benefit-item {
    animation: fadeInUp 0.6s ease forwards;
    opacity: 0;
}

.auth-benefit-item:nth-child(1) {
    animation-delay: 0.2s;
}

.auth-benefit-item:nth-child(2) {
    animation-delay: 0.35s;
}

.auth-benefit-item:nth-child(3) {
    animation-delay: 0.5s;
}

/* Responsive design */
@media (max-width: 480px) {
    .auth-popup-container {
        width: 95%;
        max-width: 380px;
    }
    
    .auth-popup-header {
        padding: 20px 20px 10px;
    }
    
    .auth-popup-body {
        padding: 10px 20px 25px;
    }
    
    .auth-popup-header h2 {
        font-size: 24px;
    }
    
    .auth-btn {
        font-size: 15px;
        padding: 10px 14px;
    }
    
    .auth-social-buttons {
        gap: 10px;
    }
    
    .auth-social-btn {
        width: 40px;
        height: 40px;
    }
}
</style>

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<!-- Auth Popup Container -->
<div id="auth-popup-overlay" class="auth-popup-overlay <?php echo $isMandatoryPage ? 'auth-popup-mandatory' : ''; ?>">
    <div class="auth-popup-container">
        <div class="auth-popup-header">
            <h2>Join Our Community</h2>
            <div class="auth-popup-tagline">Unlock premium features and personalized content</div>
            <?php if (!$isMandatoryPage): ?>
                <button id="auth-popup-close" class="auth-popup-close"><span>&times;</span></button>
            <?php endif; ?>
        </div>
        <div class="auth-popup-body">
            <p><?php echo $isMandatoryPage ? 'Please sign up or log in to continue accessing our exclusive content' : 'Create an account to enjoy these benefits:'; ?></p>
            
            <ul class="auth-benefits">
                <li class="auth-benefit-item">
                    <span class="auth-benefit-icon"><i class="fas fa-check"></i></span>
                    <span>Access to exclusive premium content</span>
                </li>
                <li class="auth-benefit-item">
                    <span class="auth-benefit-icon"><i class="fas fa-check"></i></span>
                    <span>Save your favorites and continue where you left off</span>
                </li>
                <li class="auth-benefit-item">
                    <span class="auth-benefit-icon"><i class="fas fa-check"></i></span>
                    <span>Personalized recommendations based on your interests</span>
                </li>
            </ul>
            
            <div class="auth-popup-buttons">
                <a href="login.php" class="auth-btn auth-login-btn">
                    <span class="auth-btn-icon"><i class="fas fa-sign-in-alt"></i></span>
                    <span>Log In</span>
                </a>
                <a href="register.php" class="auth-btn auth-signup-btn">
                    <span class="auth-btn-icon"><i class="fas fa-user-plus"></i></span>
                    <span>Sign Up Free</span>
                </a>
            </div>
            
            <div class="auth-social-divider">or continue with</div>
            
            <div class="auth-social-buttons">
                <a href="social-login.php?provider=google" class="auth-social-btn">
                    <i class="fab fa-google"></i>
                </a>
                <a href="social-login.php?provider=facebook" class="auth-social-btn">
                    <i class="fab fa-facebook-f"></i>
                </a>
                <a href="social-login.php?provider=twitter" class="auth-social-btn">
                    <i class="fab fa-twitter"></i>
                </a>
                <a href="social-login.php?provider=apple" class="auth-social-btn">
                    <i class="fab fa-apple"></i>
                </a>
            </div>
            
            <div class="auth-terms-text">
                By signing up, you agree to our <a href="terms.php">Terms of Service</a> and <a href="privacy.php">Privacy Policy</a>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const popupOverlay = document.getElementById('auth-popup-overlay');
    const popupContainer = document.querySelector('.auth-popup-container');
    const closeButton = document.getElementById('auth-popup-close');
    
    // Should we show the popup?
    const shouldShowPopup = <?php echo ($showPopup ? 'true' : 'false'); ?>;
    const isMandatoryPage = <?php echo ($isMandatoryPage ? 'true' : 'false'); ?>;
    const showOnEveryReload = <?php echo ($showOnEveryReload ? 'true' : 'false'); ?>;
    
    // Function to show popup with animation
    function showAuthPopup() {
        popupOverlay.style.display = 'flex';
        document.body.style.overflow = 'hidden'; // Prevent scrolling
        
        // Trigger animation
        setTimeout(() => {
            popupOverlay.classList.add('active');
        }, 10);
        
        // Add class to body for potential styling
        document.body.classList.add('auth-popup-visible');
    }
    
    // Function to hide popup with animation
    function hideAuthPopup() {
        if (!isMandatoryPage) {
            popupOverlay.classList.remove('active');
            
            // After animation completes
            setTimeout(() => {
                popupOverlay.style.display = 'none';
                document.body.style.overflow = '';
                document.body.classList.remove('auth-popup-visible');
            }, 300);
            
            if (!showOnEveryReload) {
                sessionStorage.setItem('auth_popup_manually_closed', 'true');
            }
        }
    }
    
    // Add close button event listener if it exists
    if (closeButton) {
        closeButton.addEventListener('click', hideAuthPopup);
    }
    
    // Close when clicking outside the popup (only if not mandatory)
    if (!isMandatoryPage) {
        popupOverlay.addEventListener('click', function(e) {
            if (e.target === popupOverlay) {
                hideAuthPopup();
            }
        });
    }
    
    // Prevent closing when clicking inside the popup container
    popupContainer.addEventListener('click', function(e) {
        e.stopPropagation();
    });
    
    // Escape key should close the popup (if not mandatory)
    if (!isMandatoryPage) {
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && popupOverlay.classList.contains('active')) {
                hideAuthPopup();
            }
        });
    }
    
    let shouldDisplay = false;
    
    if (isMandatoryPage) {
        shouldDisplay = true;
    } else if (showOnEveryReload) {
        shouldDisplay = true;
    } else if (shouldShowPopup && !sessionStorage.getItem('auth_popup_manually_closed')) {
        shouldDisplay = true;
    }
    
    if (shouldDisplay) {
        setTimeout(function() {
            showAuthPopup();
        }, 800); // 0.8 second delay for better UX
    }
    
    // Override browser back button behavior if mandatory
    if (isMandatoryPage) {
        window.history.pushState(null, "", window.location.href);
        window.addEventListener("popstate", function() {
            window.history.pushState(null, "", window.location.href);
        });
    }
    
    // Make functions available globally
    window.showAuthPopup = showAuthPopup;
    window.hideAuthPopup = hideAuthPopup;
});
</script>
<?php
} 
?>