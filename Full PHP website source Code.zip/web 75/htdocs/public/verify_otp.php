<?php
session_start();
require_once('../private/config.php');
require_once('../private/db.php');
require_once('../private/auth.php');
require_once('../private/email_otp.php');

// Check if already logged in
if (isLoggedIn()) {
    header("Location: /");
    exit();
}

// Check if in verification mode
if (!isInVerificationMode()) {
    // Check if there's a pending verification email
    if (isset($_SESSION['pending_verification_email'])) {
        $email = $_SESSION['pending_verification_email'];
        
        // Check if registration has expired
        $isDeleted = deleteExpiredUnverifiedUser($email);
        if ($isDeleted) {
            // Clear verification session
            unset($_SESSION['temp_user_id']);
            unset($_SESSION['temp_user_name']);
            unset($_SESSION['temp_user_email']);
            unset($_SESSION['needs_verification']);
            unset($_SESSION['pending_verification_email']);
            
            // Redirect to registration with error message
            require_once($_SERVER['DOCUMENT_ROOT'] . '/private/messages.php');
            set_error_message('Your registration has expired. Please register again.');
            header("Location: /register");
            exit();
        }
        
        // Continue with verification process
    } else {
        header("Location: /login");
        exit();
    }
}

$error = '';
$success = '';
$otpSent = false;
$user = getVerificationUser();
$resendLimitData = null;

// Get user email from session
$userEmail = '';
if ($user && isset($user['email'])) {
    $userEmail = $user['email'];
} elseif (isset($_SESSION['pending_verification_email'])) {
    $userEmail = $_SESSION['pending_verification_email'];
}

// Get user ID
$userId = isset($_SESSION['temp_user_id']) ? $_SESSION['temp_user_id'] : null;

// Process verification actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get user IP
    $userIp = $_SERVER['REMOTE_ADDR'];
    
    // Check if it's a send OTP request
    if (isset($_POST['send_otp'])) {
        // Request verification OTP
        $result = requestVerificationOTP($userId);
        
        if ($result['success']) {
            $success = "A verification code has been sent to your email. Please check your inbox.";
            $otpSent = true;
            // Store OTP sent status for this specific email
            $_SESSION['otp_sent_for_email'] = $userEmail;
        } else {
            $error = $result['message'];
        }
    }
    // Check if it's a resend OTP request
    elseif (isset($_POST['resend_otp'])) {
        // Check resend limits
        $resendLimitData = checkOTPResendLimit($userId, $userEmail, $userIp);
        
        if ($resendLimitData['allowed']) {
            $result = requestVerificationOTP($userId);
            
            if ($result['success']) {
                $success = "A new verification code has been sent to your email address. Please check your inbox.";
                $otpSent = true;
                // Store OTP sent status for this specific email
                $_SESSION['otp_sent_for_email'] = $userEmail;
                // Store resend attempt count in session
                $_SESSION['otp_resend_attempts'] = $resendLimitData['attempts'];
                // Store the timestamp for when resend was triggered
                $_SESSION['otp_last_resend_time'] = time();
            } else {
                $error = $result['message'];
            }
        } else {
            $error = "Please wait " . $resendLimitData['readable_time'] . " before requesting another code.";
            $otpSent = true; // Keep showing the OTP input
        }
    } 
    // Check if it's an OTP verification request
    elseif (isset($_POST['otp'])) {
        $otp = $_POST['otp'] ?? '';
        
        if (empty($otp)) {
            $error = "Please enter the verification code.";
            $otpSent = true; // Keep showing the OTP input
        } elseif (strlen($otp) !== 6 || !ctype_digit($otp)) {
            $error = "Please enter a valid 6-digit verification code.";
            $otpSent = true; // Keep showing the OTP input
        } else {
            if ($userId) {
                $result = verifyOTP($userId, $otp);
                
                if ($result === true) {
                    // Reset OTP resend tracking after successful verification
                    resetOTPResendTracking($userEmail ?: $userIp);
                    
                    // Complete registration and redirect to homepage
                    completeRegistration($userId);
                    // Clear OTP session variables
                    unset($_SESSION['otp_sent_for_email']);
                    unset($_SESSION['otp_sent']);
                    unset($_SESSION['otp_resend_attempts']);
                    unset($_SESSION['otp_last_resend_time']);

           require_once($_SERVER['DOCUMENT_ROOT'] . '/private/messages.php');
    set_success_message('Your email has been verified successfully! You can now access all features.');
         
                    header("Location: /");
                    exit();
                } else {
                    $error = $result;
                    $otpSent = true; // Keep showing the OTP input
                }
            } else {
                $error = "Your verification session has expired. Please try again.";
            }
        }
    }
}

// Check if an OTP has been sent before for the current email
if (isset($_SESSION['otp_sent_for_email']) && $_SESSION['otp_sent_for_email'] === $userEmail) {
    $otpSent = true;
}

// Update the session state for backwards compatibility
if ($otpSent) {
    $_SESSION['otp_sent'] = true;
}

// Get current resend attempts count from session
$resendAttempts = isset($_SESSION['otp_resend_attempts']) ? $_SESSION['otp_resend_attempts'] : 0;
$lastResendTime = isset($_SESSION['otp_last_resend_time']) ? $_SESSION['otp_last_resend_time'] : 0;

// Calculate wait time based on attempts
$waitTime = 0;
$canResend = true;
$currentTime = time();

if ($resendAttempts > 0 && $lastResendTime > 0) {
    if ($resendAttempts == 1) {
        $waitTime = 45;
    } else if ($resendAttempts == 2) {
        $waitTime = 70; 
    } else if ($resendAttempts == 3) {
        $waitTime = 150;
    } else if ($resendAttempts == 4) {
        $waitTime = 300; 
    } else if ($resendAttempts >= 5) {
        $waitTime = 3600;
    }
    
    $timeElapsed = $currentTime - $lastResendTime;
    
    if ($timeElapsed < $waitTime) {
        $canResend = false;
        $remainingTime = $waitTime - $timeElapsed;
    } else {
        $canResend = true;
        $remainingTime = 0;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include_once ('../private/favicon.php'); ?>
    <title>Email Verification - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="/assets/css/auth.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    
    <style>
        /* General Styles */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            color: #333;
        }

        /* Authentication Container */
        .auth-container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            width: 100%;
            padding: 20px;
        }

        .auth-form {
            background: #ffffff;
            padding: 35px 40px;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 450px;
            text-align: center;
            transition: all 0.3s ease;
            border: 1px solid rgba(0, 0, 0, 0.05);
        }

        /* Brand Header */
        .brand-header {
            margin-bottom: 30px;
        }

        .logo-icon {
            font-size: 36px;
            margin-bottom: 10px;
            color: #4a00e0;
        }

        /* Title */
        .auth-form h1 {
            font-size: 26px;
            color: #2d3748;
            font-weight: 700;
            margin-bottom: 24px;
            position: relative;
            display: inline-block;
        }

        .auth-form h1:after {
            content: '';
            position: absolute;
            width: 60px;
            height: 3px;
            background: linear-gradient(to right, #8e2de2, #4a00e0);
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            border-radius: 3px;
        }

        /* Success & Error Messages */
        .success-message {
            background: rgba(72, 187, 120, 0.1);
            color: #2f855a;
            padding: 14px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            border-left: 4px solid #2f855a;
            text-align: left;
            display: flex;
            align-items: center;
        }

        .success-message:before {
            content: '\f058';
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
            margin-right: 10px;
            font-size: 16px;
        }

        .error-message {
            background: rgba(229, 62, 62, 0.1);
            color: #c53030;
            padding: 14px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            border-left: 4px solid #c53030;
            text-align: left;
            display: flex;
            align-items: center;
        }

        .error-message:before {
            content: '\f06a';
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
            margin-right: 10px;
            font-size: 16px;
        }

        /* Form Group */
        .form-group {
            margin-bottom: 25px;
            text-align: left;
        }

        label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: #4a5568;
            font-size: 15px;
        }

        .otp-field {
            position: relative;
        }

        input[type="text"] {
            width: 100%;
            padding: 16px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            font-size: 18px;
            box-sizing: border-box;
            text-align: center;
            letter-spacing: 10px;
            font-weight: 600;
            transition: all 0.3s ease;
            background-color: #f8fafc;
            color: #2d3748;
        }

        input[type="text"]:focus {
            border-color: #8e2de2;
            outline: none;
            box-shadow: 0 0 0 3px rgba(138, 43, 226, 0.1);
            background-color: #fff;
        }

        /* Button Section */
        .button-section {
            display: flex;
            justify-content: space-between;
            margin-top: 25px;
        }

        .btn-primary {
            width: 100%;
            padding: 14px 20px;
            font-size: 16px;
            font-weight: 600;
            text-align: center;
            color: #ffffff;
            background: linear-gradient(135deg, #8e2de2, #4a00e0);
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(74, 0, 224, 0.2);
            position: relative;
            overflow: hidden;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 7px 14px rgba(74, 0, 224, 0.25);
        }

        .btn-primary:active {
            transform: translateY(1px);
            box-shadow: 0 3px 5px rgba(74, 0, 224, 0.2);
        }

        .btn-primary:before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: all 0.6s;
        }

        .btn-primary:hover:before {
            left: 100%;
        }

        .btn-secondary {
            background: #f7fafc;
            color: #4a5568;
            border: 1px solid #e2e8f0;
            margin-right: 12px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        }

        .btn-secondary:hover {
            background: #edf2f7;
            border-color: #cbd5e0;
        }

        /* Info Text */
        .info-text {
            margin: 20px 0;
            color: #4a5568;
            font-size: 15px;
            line-height: 1.6;
            text-align: left;
        }

        .email-highlight {
            color: #4a00e0;
            font-weight: 600;
            border-bottom: 1px dotted #4a00e0;
            padding-bottom: 1px;
        }

        /* Timer */
        .resend-timer {
            margin-top: 20px;
            color: #4a5568;
            font-size: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-wrap: wrap;
        }

        /* Send OTP Button */
        .send-otp-btn {
            width: 100%;
            padding: 16px;
            font-size: 16px;
            font-weight: 600;
            text-align: center;
            color: #ffffff;
            background: linear-gradient(135deg, #8e2de2, #4a00e0);
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(74, 0, 224, 0.2);
            margin: 25px 0;
            position: relative;
            overflow: hidden;
        }

        .send-otp-btn:before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: all 0.6s;
        }

        .send-otp-btn:hover:before {
            left: 100%;
        }

        .send-otp-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 7px 14px rgba(74, 0, 224, 0.25);
        }

        .send-otp-btn:active {
            transform: translateY(1px);
            box-shadow: 0 3px 5px rgba(74, 0, 224, 0.2);
        }

        /* Auth Links Section */
        .auth-links {
            margin-top: 25px;
            padding-top: 15px;
            border-top: 1px solid #edf2f7;
        }

        .auth-links a {
            color: #4a5568;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: color 0.3s ease;
            display: inline-flex;
            align-items: center;
        }

        .auth-links a:hover {
            color: #4a00e0;
        }

        .auth-links a i {
            margin-right: 6px;
            font-size: 13px;
        }

        /* Resend Button */
        .resend-btn {
            background: none;
            border: none;
            color: #4a00e0;
            cursor: pointer;
            padding: 0;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            margin-left: 5px;
        }

        .resend-btn:hover {
            color: #8e2de2;
            text-decoration: underline;
        }

        .resend-btn:disabled {
            color: #a0aec0;
            cursor: not-allowed;
            text-decoration: none;
        }

        .resend-btn i {
            margin-right: 5px;
            font-size: 12px;
        }

        /* Timer Display */
        .timer-display {
            display: inline-block;
            margin: 0 5px;
            font-weight: 600;
            color: #4a00e0;
        }

        .timer-info {
            width: 100%;
            text-align: center;
            margin-top: 5px;
            color: #718096;
            font-size: 12px;
        }

        /* Responsive Design */
        @media (max-width: 576px) {
            .auth-form {
                padding: 25px 20px;
                width: 95%;
                border-radius: 12px;
            }

            .button-section {
                flex-direction: column;
            }

            .btn-secondary {
                margin-right: 0;
                margin-bottom: 12px;
            }

            input[type="text"] {
                font-size: 16px;
                letter-spacing: 8px;
                padding: 14px;
            }

            .auth-form h1 {
                font-size: 22px;
            }
        }

/* Expiry Timer Styling - Compact Version */
.expiry-timer {
    background-color: #fff8e1;
    border-left: 3px solid #ffc107;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    border-radius: 3px;
    margin: 12px 0;
    padding: 8px 10px;
    display: flex;
    align-items: center;
    max-width: 280px;
    margin-left: auto;
    margin-right: auto;
}

.timer-icon {
    color: #ffa000;
    font-size: 18px;
    margin-right: 5px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.timer-content {
    flex: 1;
}

.timer-label {
    margin: 0 0 3px 0;
    color: #5d4037;
    font-size: 12px;
    font-weight: 500;
}

.countdown-display {
    display: flex;
    align-items: center;
    justify-content: center;
}

.time-block {
    display: flex;
    flex-direction: column;
    align-items: center;
    min-width: 30px;
}

.time-block span:first-child {
    font-family: 'Courier New', monospace;
    font-size: 18px;
    font-weight: bold;
    color: #e53935;
    line-height: 1;
}

.time-label {
    font-size: 10px;
    color: #795548;
    margin-top: 1px;
    text-transform: uppercase;
}

.time-separator {
    font-family: 'Courier New', monospace;
    font-size: 18px;
    font-weight: bold;
    color: #795548;
    margin: 0 1px;
    line-height: 1;
    padding-bottom: 12px;
}

.hidden {
    display: none;
}

/* Add a subtle animation when time gets low */
@media (prefers-reduced-motion: no-preference) {
    .countdown-display.urgent .time-block span:first-child {
        animation: pulse-urgent 1s infinite;
    }
}

@keyframes pulse-urgent {
    0% { color: #e53935; }
    50% { color: #ff8f00; }
    100% { color: #e53935; }
}

/* Add these fade-out animation styles */
    @keyframes fadeOut {
        from { opacity: 1; }
        to { opacity: 0; }
    }
    
    .fade-out {
        animation: fadeOut 0.5s ease forwards;
    }
    
    /* Message container with position relative for progress bar */
    .error-message, .success-message {
        transition: opacity 0.5s ease;
        position: relative;
        padding-bottom: 22px; /* Extra space for the progress bar */
    }
    
    /* Progress bar container */
    .message-progress-container {
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 4px;
        background: rgba(0, 0, 0, 0.1);
        border-radius: 0 0 8px 8px;
        overflow: hidden;
    }
    
    /* Progress bar indicator */
    .message-progress-bar {
        height: 100%;
        width: 100%;
        background: linear-gradient(to right, #8e2de2, #4a00e0);
        transform-origin: left;
    }
    
    /* Different color for error message progress bar */
    .error-message .message-progress-bar {
        background: linear-gradient(to right, #e53935, #c53030);
    }
    
    /* Progress bar animation */
    @keyframes countdown {
        from { transform: scaleX(1); }
        to { transform: scaleX(0); }
    }
    
    .countdown-active {
        animation: countdown 5s linear forwards;
    }

    .spam-notice {
    background: #f8f9fa;
    border-left: 4px solid #ffc107;
    color: #495057;
    font-weight: bold;
    margin-top: 10px;
    padding: 10px;
    border-radius: 4px;
    text-align: left;
}

.spam-icon {
    text-align: center;
    margin-bottom: 10px;
}

.spam-icon i {
    font-size: 24px;
    color: #ffc107;
    display: block;
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0% {
        transform: scale(1);
    }
    50% {
        transform: scale(1.1);
    }
    100% {
        transform: scale(1);
    }
}

/* Spam notice progress bar */
.spam-notice {
    transition: opacity 0.5s ease;
    position: relative;
    padding-bottom: 22px; /* Extra space for the progress bar */
}

.spam-progress-container {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 4px;
    background: rgba(0, 0, 0, 0.1);
    border-radius: 0 0 8px 8px;
    overflow: hidden;
}

.spam-progress-bar {
    height: 100%;
    width: 100%;
    background: linear-gradient(to right, #ffc107, #ff9800);
    transform-origin: left;
}

/* Longer countdown animation for spam notice */
@keyframes spam-countdown {
    from { transform: scaleX(1); }
    to { transform: scaleX(0); }
}

.spam-countdown-active {
    animation: spam-countdown 25s linear forwards;
}
</style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-form">
            <div class="brand-header">
                <div class="logo-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
            </div>
            
            <h1>Account Verification</h1>
            
           <?php if (!empty($error)): ?>
    <div class="error-message">
        <?php echo $error; ?>
        <div class="message-progress-container">
            <div class="message-progress-bar"></div>
        </div>
    </div>
<?php endif; ?>

<?php if (!empty($success)): ?>
    <div class="success-message">
        <?php echo $success; ?>
        <div class="message-progress-container">
            <div class="message-progress-bar"></div>
        </div>
    </div>
<?php endif; ?>

<?php if ($otpSent && empty($error)): ?>
<div class="spam-notice">
    <div class="spam-icon"><i class="fas fa-exclamation-triangle"></i></div>
    <p>Please check both your inbox and spam folder, as sometimes these emails are filtered as spam.</p>
    <div class="message-progress-container spam-progress-container">
        <div class="message-progress-bar spam-progress-bar"></div>
    </div>
</div>
<?php endif; ?>

<?php
// Calculate time remaining before account deletion
if ($userId) {
    $user = dbSelectOne("SELECT registration_date FROM users WHERE id = ?", [$userId]);
    if ($user && isset($user['registration_date'])) {
        $registrationTime = strtotime($user['registration_date']);
        $currentTime = time();
        $expiryTimeMinutes = 10; // 10 minutes
        $totalSeconds = ($expiryTimeMinutes * 60);
        $remainingSeconds = max(0, $totalSeconds - ($currentTime - $registrationTime));
        
        // Calculate minutes and seconds for display
        $minutes = floor($remainingSeconds / 60);
        $seconds = $remainingSeconds % 60;
        ?>
        <div class="expiry-timer">
            <div class="timer-icon">
                <i class="fas fa-clock"></i>
            </div>
            <div class="timer-content">
                <p class="timer-label">Your Registration expires in:</p>
                <div class="countdown-display">
                    <div class="time-block">
                        <span id="expiry-minutes"><?php echo str_pad($minutes, 2, '0', STR_PAD_LEFT); ?></span>
                        <span class="time-label">min</span>
                    </div>
                    <div class="time-separator">:</div>
                    <div class="time-block">
                        <span id="expiry-seconds"><?php echo str_pad($seconds, 2, '0', STR_PAD_LEFT); ?></span>
                        <span class="time-label">sec</span>
                    </div>
                </div>
                <div id="expiry-countdown" data-remaining="<?php echo $remainingSeconds; ?>" class="hidden"></div>
            </div>
        </div>
    <?php } ?>
<?php } ?>

            <p class="info-text">
                <?php if (!$otpSent): ?>
                    We need to verify that <span class="email-highlight"><?php echo htmlspecialchars($userEmail); ?></span> 
                    belongs to you. Click the button below to receive a secure verification code.
                <?php else: ?>
                    We've sent a 6-digit verification code to 
                    <span class="email-highlight"><?php echo htmlspecialchars($userEmail); ?></span>. 
                    Enter the code below to complete your account verification.
                <?php endif; ?>
            </p>
            
            <?php if (!$otpSent): ?>
                <!-- Initial state - Send OTP button -->
                <form method="post" action="verify_otp">
                    <button type="submit" name="send_otp" value="1" class="send-otp-btn">
                        <i class="fas fa-paper-plane"></i> Send Verification Code
                    </button>
                </form>
            <?php else: ?>
                <!-- After OTP is sent - OTP Input and Verify button -->
                <form method="post" action="verify_otp">
                    <div class="form-group">
                        <label for="otp"><i class="fas fa-key"></i> Verification Code</label>
                        <div class="otp-field">
                            <input type="text" id="otp" name="otp" maxlength="6" autocomplete="off" autofocus 
                                   placeholder="· · · · · ·">
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-check-circle"></i> Verify & Continue
                    </button>
                    
                    <div class="resend-timer">
                        <span>Didn't receive the code?</span>
                        <?php if (!$canResend): ?>
                            <span class="timer-display" id="timer-countdown">00:00</span>
                            <button type="submit" name="resend_otp" value="1" class="resend-btn" disabled>
                                <i class="fas fa-sync-alt"></i> Resend Code
                            </button>
                            <?php if ($resendAttempts > 0): ?>
                                <div class="timer-info">
    Resend attempt <?php echo $resendAttempts; ?>/5. 
    <?php if ($resendAttempts >= 5): ?>
        Wait time: 1 hour.
    <?php elseif ($resendAttempts == 4): ?>
        Wait time: 5 minutes.
    <?php elseif ($resendAttempts == 3): ?>
        Wait time: 2 min 30 sec.
    <?php elseif ($resendAttempts == 2): ?>
        Wait time: 1 min 10 sec.
    <?php else: ?>
        Wait time: 45 seconds.
    <?php endif; ?>
</div>
                            <?php endif; ?>
                        <?php else: ?>
                            <button type="submit" name="resend_otp" value="1" class="resend-btn">
                                <i class="fas fa-sync-alt"></i> Resend Code
                            </button>
                        <?php endif; ?>
                    </div>
                </form>
            <?php endif; ?>
            
            <div class="auth-links">
                <p>
                    <a href="/login" onclick="return confirm('Are you sure you want to cancel the verification process? You will need to start over again.');">
                        <i class="fas fa-arrow-left"></i> Cancel Verification
                    </a>
                </p>
            </div>
        </div>
    </div>

    <script>
        // Auto-focus on OTP input when page loads (if in OTP input state)
        document.addEventListener('DOMContentLoaded', function() {
            const otpInput = document.getElementById('otp');
            if (otpInput) {
                otpInput.focus();
            }
            
            // Initialize countdown timer if needed
            <?php if (!$canResend && isset($remainingTime)): ?>
            startCountdown(<?php echo $remainingTime; ?>);
            <?php endif; ?>
        });
        
        // Only allow numbers in the OTP input
        const otpInput = document.getElementById('otp');
        if (otpInput) {
            otpInput.addEventListener('input', function(e) {
                this.value = this.value.replace(/[^0-9]/g, '');
            });
            
            // Add placeholder effect
            otpInput.addEventListener('focus', function() {
                this.placeholder = '';
            });
            
            otpInput.addEventListener('blur', function() {
                if (this.value === '') {
                    this.placeholder = '· · · · · ·';
                }
            });
        }
        
        // Countdown timer function
        function startCountdown(seconds) {
            const timerDisplay = document.getElementById('timer-countdown');
            const resendButton = document.querySelector('.resend-btn');
            
            if (!timerDisplay) return;
            
            let remainingTime = seconds;
            updateTimerDisplay(remainingTime);
            
            const countdownInterval = setInterval(function() {
                remainingTime--;
                
                if (remainingTime <= 0) {
                    clearInterval(countdownInterval);
                    if (resendButton) {
                        resendButton.disabled = false;
                    }
                    timerDisplay.textContent = "Ready";
                } else {
                    updateTimerDisplay(remainingTime);
                }
            }, 1000);
            
            function updateTimerDisplay(seconds) {
                const minutes = Math.floor(seconds / 60);
                const secs = seconds % 60;
                timerDisplay.textContent = `${padZero(minutes)}:${padZero(secs)}`;
            }
            
            function padZero(num) {
                return num.toString().padStart(2, '0');
            }
        }

// Expiry countdown timer
document.addEventListener('DOMContentLoaded', function() {
    // Expiry countdown timer
    const expiryCountdown = document.getElementById('expiry-countdown');
    if (expiryCountdown) {
        const minutesElement = document.getElementById('expiry-minutes');
        const secondsElement = document.getElementById('expiry-seconds');
        const countdownDisplay = document.querySelector('.countdown-display');
        let remainingTime = parseInt(expiryCountdown.getAttribute('data-remaining'));
        
        // Update timer immediately to ensure correct display
        updateExpiryDisplay(remainingTime);
        
        // Set up interval to update every second
        const expiryInterval = setInterval(function() {
            remainingTime--;
            
            if (remainingTime <= 0) {
                clearInterval(expiryInterval);
                minutesElement.textContent = "00";
                secondsElement.textContent = "00";
                
                // Show alert and redirect
                alert("Your registration has expired. Please register again.");
                window.location.href = "/register";
            } else {
                updateExpiryDisplay(remainingTime);
                
                // Add urgent class when less than 60 seconds remain
                if (remainingTime <= 60) {
                    countdownDisplay.classList.add('urgent');
                }
            }
        }, 1000);
        
        // Function to update the timer display
        function updateExpiryDisplay(timeInSeconds) {
            const minutes = Math.floor(timeInSeconds / 60);
            const seconds = timeInSeconds % 60;
            
            minutesElement.textContent = padZero(minutes);
            secondsElement.textContent = padZero(seconds);
        }
        
        // Function to pad numbers with leading zeros
        function padZero(num) {
            return num.toString().padStart(2, '0');
        }
    }
});

// Auto-hide messages after a few seconds
document.addEventListener('DOMContentLoaded', function() {

    const messages = document.querySelectorAll('.success-message, .error-message');
    
    if (messages.length > 0) {
        
        messages.forEach(function(message) {
            const progressBar = message.querySelector('.message-progress-bar');
            if (progressBar) {
                progressBar.classList.add('countdown-active');
            }
        });
        
        setTimeout(function() {
            messages.forEach(function(message) {
        message.classList.add('fade-out');
         
                setTimeout(function() {
                    if (message.parentNode) {
                        message.parentNode.removeChild(message);
                    }
                }, 500);
            });
        }, 5000);
    }
    
    // Handle spam notice with longer timeout
    const spamNotice = document.querySelector('.spam-notice');
    if (spamNotice) {
        const spamProgressBar = spamNotice.querySelector('.spam-progress-bar');
        if (spamProgressBar) {
            spamProgressBar.classList.add('spam-countdown-active');
        }
        
        setTimeout(function() {
            spamNotice.classList.add('fade-out');
         
            setTimeout(function() {
                if (spamNotice.parentNode) {
                    spamNotice.parentNode.removeChild(spamNotice);
                }
            }, 500);
        }, 25000);
    }
});
    </script>
</body>
</html>