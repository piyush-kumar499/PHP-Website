<?php
/**
 * Temporary admin script to run sync-tools.php
 * IMPORTANT: DELETE THIS FILE AFTER USE
 */

// Check for a secret key for security
if (isset($_GET['key']) && $_GET['key'] === 'SyncT00ls_T3mp@cce$$') {
    // Set a longer execution time limit for larger tool directories
    set_time_limit(300);
    
    // Set timezone to Indian Standard Time
    date_default_timezone_set('Asia/Kolkata');
    
    // Display output as HTML with styling
    header('Content-Type: text/html; charset=UTF-8');
    
    // Output HTML header with CSS styling
    echo '<!DOCTYPE html>
    <html>
    <head>
        <title>Tool Synchronization</title>
        <style>
            :root {
                --primary-color: #1e88e5;
                --primary-dark: #1565c0;
                --secondary-color: #f5f5f5;
                --text-color: #333333;
                --light-text: #757575;
                --border-color: #e0e0e0;
                --success-color: #43a047;
                --warning-color: #ff9800;
                --error-color: #e53935;
                --info-color: #039be5;
                --added-bg: #e8f5e9;
                --updated-bg: #e1f5fe;
                --removed-bg: #ffebee;
            }
            
            * {
                box-sizing: border-box;
                margin: 0;
                padding: 0;
            }
            
            body {
                font-family: "Segoe UI", Roboto, -apple-system, BlinkMacSystemFont, Arial, sans-serif;
                line-height: 1.6;
                color: var(--text-color);
                background-color: #f9f9f9;
                padding: 0;
                margin: 0;
            }
            
            .container {
                max-width: 1100px;
                margin: 2rem auto;
                background: #fff;
                padding: 2rem;
                border-radius: 8px;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            }
            
            h1 {
                color: var(--primary-dark);
                font-size: 1.8rem;
                font-weight: 600;
                margin-bottom: 1.5rem;
                padding-bottom: 1rem;
                border-bottom: 2px solid var(--primary-color);
            }
            
            h2 {
                color: var(--primary-dark);
                font-size: 1.4rem;
                font-weight: 500;
                margin: 1.5rem 0 1rem;
                padding-bottom: 0.5rem;
                border-bottom: 1px solid var(--border-color);
            }
            
            h3 {
                color: var(--primary-dark);
                font-size: 1.2rem;
                font-weight: 500;
                margin: 1rem 0 0.8rem;
            }
            
            pre {
                background-color: #fafafa;
                padding: 1.25rem;
                border-radius: 6px;
                overflow-x: auto;
                border-left: 4px solid var(--primary-color);
                box-shadow: inset 0 0 4px rgba(0, 0, 0, 0.05);
                font-family: "Cascadia Code", Consolas, Monaco, "Andale Mono", monospace;
                font-size: 0.9rem;
                line-height: 1.5;
                margin: 1rem 0;
            }
            
            .success {
                color: var(--success-color);
                font-weight: 600;
            }
            
            .warning {
                color: var(--warning-color);
                font-weight: 600;
            }
            
            .error {
                color: var(--error-color);
                font-weight: 600;
            }
            
            .info {
                color: var(--info-color);
                font-weight: 600;
            }
            
            .added {
                background-color: var(--added-bg);
                padding: 4px 8px;
                border-radius: 4px;
                display: inline-block;
                margin: 2px 0;
                line-height: 1.5;
            }
            
            .updated {
                background-color: var(--updated-bg);
                padding: 4px 8px;
                border-radius: 4px;
                display: inline-block;
                margin: 2px 0;
                line-height: 1.5;
            }
            
            .removed {
                background-color: var(--removed-bg);
                padding: 4px 8px;
                border-radius: 4px;
                display: inline-block;
                margin: 2px 0;
                line-height: 1.5;
            }
            
            .alert {
                background-color: #fdeeee;
                color: #bf2c24;
                padding: 1.25rem;
                margin: 1.5rem 0 0.5rem;
                border-radius: 6px;
                border-left: 5px solid #e53935;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
                font-weight: 500;
            }
            
            .stats-panel {
                background-color: #f8fcff;
                border: 1px solid #e3f2fd;
                border-radius: 8px;
                padding: 1.5rem;
                margin: 1.5rem 0;
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
            }
            
            .stats-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
                gap: 1rem;
                margin: 1.25rem 0;
            }
            
            .stat-box {
                background-color: white;
                border-radius: 6px;
                padding: 1.25rem 1rem;
                box-shadow: 0 2px 6px rgba(0, 0, 0, 0.06);
                text-align: center;
                transition: transform 0.2s ease, box-shadow 0.2s ease;
                border: 1px solid #f0f0f0;
            }
            
            .stat-box:hover {
                transform: translateY(-2px);
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            }
            
            .stat-value {
                font-size: 2rem;
                font-weight: 600;
                color: var(--primary-color);
                margin: 0.5rem 0;
                line-height: 1.2;
            }
            
            .stat-label {
                font-size: 0.95rem;
                color: var(--light-text);
                font-weight: 500;
            }
            
            .last-sync {
                text-align: right;
                font-style: italic;
                color: var(--light-text);
                margin-top: 1rem;
                font-size: 0.9rem;
            }
            
            .category-stats {
                margin-top: 1.5rem;
                padding-top: 1rem;
                border-top: 1px solid var(--border-color);
            }
            
            .category-list {
                display: flex;
                flex-wrap: wrap;
                gap: 0.6rem;
                margin-top: 0.8rem;
            }
            
            .category-tag {
                background-color: #e3f2fd;
                border-radius: 20px;
                padding: 0.4rem 0.9rem;
                font-size: 0.85rem;
                color: var(--primary-color);
                font-weight: 500;
                transition: background-color 0.15s ease;
                border: 1px solid #bbdefb;
            }
            
            .category-tag:hover {
                background-color: #bbdefb;
            }
            
            @media (max-width: 768px) {
                .container {
                    margin: 1rem;
                    padding: 1.5rem;
                }
                
                .stats-grid {
                    grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
                }
                
                .stat-value {
                    font-size: 1.6rem;
                }
            }
        </style>
    </head>
    <body>
    <div class="container">
        <h1>Tool Synchronization Dashboard</h1>';
    
    // Include config and DB connection
    require_once '../private/config.php';
    require_once '../private/db.php';

    // Get statistics before running sync
    $toolsCount = dbSelectOne("SELECT COUNT(*) as count FROM tools");
    $detailsCount = dbSelectOne("SELECT COUNT(*) as count FROM tool_details");
    $categoriesResult = dbSelect("SELECT category, COUNT(*) as count FROM tools GROUP BY category ORDER BY count DESC");
    $lastSyncLog = dbSelectOne("SELECT MAX(accessed_at) as last_sync FROM access_logs WHERE action = 'sync'");
    
    // If access_logs table doesn't exist, create it
    dbExecute("CREATE TABLE IF NOT EXISTS `access_logs` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `action` varchar(50) NOT NULL,
        `accessed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `ip_address` varchar(45) DEFAULT NULL,
        `details` text,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    
    // Log this sync operation
    $currentTime = date('Y-m-d H:i:s');
    dbExecute("INSERT INTO access_logs (action, accessed_at, ip_address, details) VALUES (?, ?, ?, ?)",
        ['sync', $currentTime, $_SERVER['REMOTE_ADDR'], 'Manual sync via admin-sync.php']);
    
    // Display statistics panel
    echo '<div class="stats-panel">
        <h2>Synchronization Statistics</h2>
        <div class="stats-grid">
            <div class="stat-box">
                <div class="stat-value">' . ($toolsCount ? $toolsCount['count'] : 0) . '</div>
                <div class="stat-label">Total Tools</div>
            </div>
            <div class="stat-box">
                <div class="stat-value">' . ($detailsCount ? $detailsCount['count'] : 0) . '</div>
                <div class="stat-label">Tools with Details</div>
            </div>
            <div class="stat-box">
                <div class="stat-value">' . count(glob(PUBLIC_PATH . '/tools/files/*.php')) . '</div>
                <div class="stat-label">PHP Files</div>
            </div>
            <div class="stat-box">
                <div class="stat-value">' . count(glob(PUBLIC_PATH . '/tools/details/*.json')) . '</div>
                <div class="stat-label">JSON Files</div>
            </div>
        </div>';
        
    // Display last sync time if available
    if ($lastSyncLog && $lastSyncLog['last_sync']) {
        echo '<div class="last-sync">Last synchronized: ' . $lastSyncLog['last_sync'] . '</div>';
    } else {
        echo '<div class="last-sync">First synchronization in progress</div>';
    }
    
    // Show categories if available
    if ($categoriesResult && count($categoriesResult) > 0) {
        echo '<div class="category-stats">
            <h3>Tool Categories</h3>
            <div class="category-list">';
        foreach ($categoriesResult as $cat) {
            echo '<span class="category-tag">' . htmlspecialchars($cat['category']) . ' (' . $cat['count'] . ')</span>';
        }
        echo '</div></div>';
    }
    
    echo '</div>'; // Close stats panel
    
    echo '<h2>Synchronization Log</h2>
    <pre id="sync-output">';
    
    // Output will be captured and processed
    ob_start();
    
    echo "<span class='info'>Starting tool synchronization process at " . date('Y-m-d H:i:s') . "...</span>\n\n";
    
    // Include the sync-tools.php file
    require_once '../private/sync-tools.php';
    
    // Time how long the sync took
    $syncEndTime = date('Y-m-d H:i:s');
    $syncDuration = strtotime($syncEndTime) - strtotime($currentTime);
    
    // Get the output
    $output = ob_get_clean();
    
    // Process the output to add styling
    $styledOutput = preg_replace('/Added new tool: (.*?)\\n/', "<span class='added'>➕ Added new tool: $1</span>\n", $output);
    $styledOutput = preg_replace('/Updated tool: (.*?)\\n/', "<span class='updated'>🔄 Updated tool: $1</span>\n", $styledOutput);
    $styledOutput = preg_replace('/Removed tool: (.*?)\\n/', "<span class='removed'>❌ Removed tool: $1</span>\n", $styledOutput);
    $styledOutput = preg_replace('/Added details for tool: (.*?)\\n/', "<span class='added'>📄 Added details for tool: $1</span>\n", $styledOutput);
    $styledOutput = preg_replace('/Updated details for tool: (.*?)\\n/', "<span class='updated'>📄 Updated details for tool: $1</span>\n", $styledOutput);
    $styledOutput = preg_replace('/No valid details file found for tool: (.*?)\\n/', "<span class='warning'>⚠️ No valid details file found for tool: $1</span>\n", $styledOutput);
    $styledOutput = preg_replace('/Error: (.*?)\\n/', "<span class='error'>🚫 Error: $1</span>\n", $styledOutput);
    $styledOutput = preg_replace('/Done!/', "<span class='success'>✅ Done!</span>", $styledOutput);
    
    echo $styledOutput;
    
    // Get updated statistics after sync
    $updatedToolsCount = dbSelectOne("SELECT COUNT(*) as count FROM tools");
    $updatedDetailsCount = dbSelectOne("SELECT COUNT(*) as count FROM tool_details");
    
    // Display sync summary
    echo "\n\n<span class='info'>Synchronization completed at " . $syncEndTime . "</span>";
    echo "\n<span class='info'>Process took " . $syncDuration . " seconds</span>";
    echo "\n<span class='info'>Final count: " . ($updatedToolsCount ? $updatedToolsCount['count'] : 0) . " tools, " . 
        ($updatedDetailsCount ? $updatedDetailsCount['count'] : 0) . " with details files</span>";
    
    // Finish HTML structure
    echo '</pre>
        <div class="alert">
            <strong>IMPORTANT:</strong> Delete this file immediately for security reasons.
        </div>
    </div>
    </body>
    </html>';
    
    // Log access for security
    error_log("Tool sync was executed via admin-sync.php at " . date('Y-m-d H:i:s'));
    
    exit;
} else {
    // Access denied
    http_response_code(403);
    echo "<h1>Access Denied</h1>";
    echo "<p>You do not have permission to access this resource.</p>";
    
    // Log failed access attempt
    error_log("Failed access attempt to admin-sync.php at " . date('Y-m-d H:i:s') . " from IP: " . $_SERVER['REMOTE_ADDR']);
}