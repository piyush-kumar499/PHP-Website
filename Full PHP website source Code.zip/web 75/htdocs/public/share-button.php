<style>
/* share-button.css */
.custom-share-container {
    position: fixed;
    left: 20px;
    top: 50%;
    transform: translateY(-50%);
    z-index: 999;
    cursor: default;
    /* Remove background, padding, and margin */
    background: none;
    padding: 0;
    margin: 0;
}

.custom-share-container:hover {
    cursor: move;
    cursor: grab;
}

.custom-share-container.dragging {
    cursor: grabbing;
}

.custom-share-btn {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background: linear-gradient(45deg, #2196F3, #3F51B5);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 22px;
    cursor: pointer;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
    transition: all 0.3s ease;
    position: relative;
    z-index: 2;
    /* No margin or padding that would cause overlap */
    margin: 0;
    padding: 0;
}

.custom-share-btn:hover {
    transform: scale(1.05);
    box-shadow: 0 6px 16px rgba(0, 0, 0, 0.3);
}

/* Icon transition styling */
.custom-share-btn i {
    transition: opacity 0.3s ease, transform 0.3s ease;
}

.custom-share-btn .fa-share-alt {
    opacity: 1;
    position: absolute;
}

.custom-share-btn .fa-times {
    opacity: 0;
    position: absolute;
    transform: rotate(-90deg);
}

.show-options .custom-share-btn .fa-share-alt {
    opacity: 0;
    transform: rotate(90deg);
}

.show-options .custom-share-btn .fa-times {
    opacity: 1;
    transform: rotate(0);
}

/* Share options container */
.custom-share-options {
    position: absolute;
    left: 0;
    top: 0;
    width: 50px;
    height: 50px;
    pointer-events: none;
    opacity: 0;
    transition: opacity 0.3s ease;
    /* Remove any background */
    background: none; 
}

/* Individual share option button */
.custom-share-option {
    position: absolute;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 18px;
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    transform: scale(0);
    transition: transform 0.5s cubic-bezier(0.68, -0.55, 0.27, 1.55), box-shadow 0.3s ease;
    z-index: 1;
    left: 5px;
    top: 5px;
    /* No margin or padding */
    margin: 0;
    padding: 0;
}

.custom-share-option:hover {
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
    transform: scale(1.1) !important;
}

/* Platform-specific colors */
.custom-share-option:nth-child(1) {
    background-color: #3b5998; /* Facebook */
}

.custom-share-option:nth-child(2) {
    background-color: #1DA1F2; /* Twitter */
}

.custom-share-option:nth-child(3) {
    background-color: #0077b5; /* LinkedIn */
}

.custom-share-option:nth-child(4) {
    background-color: #E60023; /* Pinterest */
}

.custom-share-option:nth-child(5) {
    background-color: #FF4500; /* Reddit */
}

.custom-share-option:nth-child(6) {
    background-color: #25D366; /* WhatsApp */
}

.custom-share-option:nth-child(7) {
    background-color: #0088cc; /* Telegram */
}

.custom-share-option:nth-child(8) {
    background-color: #D44638; /* Email */
}

.custom-share-option:nth-child(9) {
    background-color: #4285F4; /* Native Share */
}

/* Tooltip for each share option */
.custom-share-option::after {
    content: attr(data-title);
    position: absolute;
    left: 50px;
    background: rgba(0, 0, 0, 0.8);
    color: white;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 500;
    white-space: nowrap;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.3s ease, transform 0.3s ease;
    transform: translateX(-10px);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
}

.custom-share-option:hover::after {
    opacity: 1;
    transform: translateX(0);
}

/* Expanded share options container */
.show-options .custom-share-options {
    opacity: 1;
    pointer-events: all;
    width: 300px;
    height: 300px;
}

/* Positioning for half-circle with better spacing */
.show-options .custom-share-option:nth-child(1) {
    transform: translate(0, -120px) scale(1);
    transition-delay: 0.1s;
}

.show-options .custom-share-option:nth-child(2) {
    transform: translate(50px, -105px) scale(1);
    transition-delay: 0.15s;
}

.show-options .custom-share-option:nth-child(3) {
    transform: translate(90px, -80px) scale(1);
    transition-delay: 0.2s;
}

.show-options .custom-share-option:nth-child(4) {
    transform: translate(115px, -45px) scale(1);
    transition-delay: 0.25s;
}

.show-options .custom-share-option:nth-child(5) {
    transform: translate(125px, 0) scale(1);
    transition-delay: 0.3s;
}

.show-options .custom-share-option:nth-child(6) {
    transform: translate(115px, 45px) scale(1);
    transition-delay: 0.35s;
}

.show-options .custom-share-option:nth-child(7) {
    transform: translate(90px, 80px) scale(1);
    transition-delay: 0.4s;
}

.show-options .custom-share-option:nth-child(8) {
    transform: translate(50px, 105px) scale(1);
    transition-delay: 0.45s;
}

.show-options .custom-share-option:nth-child(9) {
    transform: translate(0, 120px) scale(1);
    transition-delay: 0.5s;
}

/* Overlay for closing menu when clicking outside */
.custom-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: transparent;
    display: none;
    z-index: 1;
}

.show-options .custom-overlay {
    display: block;
}

/* Visual path indicator with subtle gradient */
.custom-share-container::after {
    content: '';
    position: absolute;
    top: 25px;
    left: 25px;
    width: 0;
    height: 0;
    border-radius: 100px;
    z-index: 0;
    opacity: 0;
    transition: opacity 0.5s ease, width 0.5s ease, height 0.5s ease;
    border: 1px dashed rgba(33, 150, 243, 0.2);
    pointer-events: none;
}

.show-options .custom-share-container::after {
    width: 240px;
    height: 240px;
    opacity: 0.5;
}

/* Pulse animation for the share button */
@keyframes pulse {
    0% { transform: scale(1); box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25); }
    50% { transform: scale(1.05); box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3); }
    100% { transform: scale(1); box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25); }
}

.pulse {
    animation: pulse 2s infinite;
}

/* Mobile responsiveness with improved spacing */
@media (max-width: 768px) {
    .custom-share-container {
        left: 10px;
    }
    
    .custom-share-btn {
        width: 40px;
        height: 40px;
        font-size: 18px;
    }
    
    .custom-share-option {
        width: 35px;
        height: 35px;
        font-size: 15px;
    }
    
    .show-options .custom-share-options {
        width: 250px;
        height: 250px;
    }
    
    .show-options .custom-share-option:nth-child(1) {
        transform: translate(0, -100px) scale(1);
    }
    
    .show-options .custom-share-option:nth-child(2) {
        transform: translate(40px, -90px) scale(1);
    }
    
    .show-options .custom-share-option:nth-child(3) {
        transform: translate(75px, -65px) scale(1);
    }
    
    .show-options .custom-share-option:nth-child(4) {
        transform: translate(95px, -35px) scale(1);
    }
    
    .show-options .custom-share-option:nth-child(5) {
        transform: translate(105px, 0) scale(1);
    }
    
    .show-options .custom-share-option:nth-child(6) {
        transform: translate(95px, 35px) scale(1);
    }
    
    .show-options .custom-share-option:nth-child(7) {
        transform: translate(75px, 65px) scale(1);
    }
    
    .show-options .custom-share-option:nth-child(8) {
        transform: translate(40px, 90px) scale(1);
    }
    
    .show-options .custom-share-option:nth-child(9) {
        transform: translate(0, 100px) scale(1);
    }
    
    .show-options .custom-share-container::after {
        width: 200px;
        height: 200px;
    }
}
</style>

<!-- share-button.php -->
<div class="custom-share-container">
    <div class="custom-share-btn pulse">
        <i class="fas fa-share-alt"></i>
        <i class="fas fa-times"></i>
    </div>
    <div class="custom-overlay"></div>
    <div class="custom-share-options">
        <div class="custom-share-option" data-title="Share on Facebook">
            <i class="fab fa-facebook-f"></i>
        </div>
        <div class="custom-share-option" data-title="Share on Twitter">
            <i class="fab fa-twitter"></i>
        </div>
        <div class="custom-share-option" data-title="Share on LinkedIn">
            <i class="fab fa-linkedin-in"></i>
        </div>
        <div class="custom-share-option" data-title="Share on Pinterest">
            <i class="fab fa-pinterest-p"></i>
        </div>
        <div class="custom-share-option" data-title="Share on Reddit">
            <i class="fab fa-reddit-alien"></i>
        </div>
        <div class="custom-share-option" data-title="Share on WhatsApp">
            <i class="fab fa-whatsapp"></i>
        </div>
        <div class="custom-share-option" data-title="Share on Telegram">
            <i class="fab fa-telegram-plane"></i>
        </div>
        <div class="custom-share-option" data-title="Share via Email">
            <i class="fas fa-envelope"></i>
        </div>
        <div class="custom-share-option native-share" data-title="Native Share">
            <i class="fas fa-share-from-square"></i>
        </div>
    </div>
</div>


<script>
// share-button.js
document.addEventListener('DOMContentLoaded', function() {
  const shareBtn = document.querySelector('.custom-share-btn');
  const shareContainer = document.querySelector('.custom-share-container');
  const overlay = document.querySelector('.custom-overlay');
  const shareOptions = document.querySelectorAll('.custom-share-option');
  const nativeShareBtn = document.querySelector('.native-share');
  
  // Toggle share options
  shareBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    shareContainer.classList.toggle('show-options');
    shareBtn.classList.remove('pulse');
  });
  
  // Close share options when clicking on overlay
  overlay.addEventListener('click', function() {
    shareContainer.classList.remove('show-options');
  });
  
  // Close share options when clicking anywhere outside the share container
  document.addEventListener('click', function(e) {
    const isClickInsideContainer = shareContainer.contains(e.target);
    if (!isClickInsideContainer && shareContainer.classList.contains('show-options')) {
      shareContainer.classList.remove('show-options');
    }
  });
  
  // Close share options when hovering outside the share container
  let hoverTimeoutId = null;
  const handleMouseOut = function(e) {
    if (shareContainer.classList.contains('show-options')) {
      const rect = shareContainer.getBoundingClientRect();
      // Add buffer zone around the container (100px in all directions - reduced from original)
      const buffer = 100;
      
      // Check if mouse is outside the container plus buffer
      if (
        e.clientX < rect.left - buffer ||
        e.clientX > rect.right + buffer ||
        e.clientY < rect.top - buffer ||
        e.clientY > rect.bottom + buffer
      ) {
        clearTimeout(hoverTimeoutId);
        hoverTimeoutId = setTimeout(() => {
          shareContainer.classList.remove('show-options');
        }, 300); // Added a slight delay so it's not too sensitive
      }
    }
  };
  
  document.addEventListener('mousemove', handleMouseOut);
  
  // Cancel the closing when hovering over the share container
  shareContainer.addEventListener('mouseenter', function() {
    clearTimeout(hoverTimeoutId);
  });
  
  // Handle share clicks for standard platforms
  shareOptions.forEach((option, index) => {
    if (!option.classList.contains('native-share')) {
      option.addEventListener('click', function(e) {
        e.stopPropagation();
        
        // Current page URL and title
        const url = encodeURIComponent(window.location.href);
        const title = encodeURIComponent(document.title);
        const text = encodeURIComponent('Check out this page!');
        
        // Specific platform sharing based on index
        switch (index) {
          case 0: // Facebook
            window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}`, '_blank');
            break;
          case 1: // Twitter
            window.open(`https://twitter.com/intent/tweet?url=${url}&text=${text}`, '_blank');
            break;
          case 2: // LinkedIn
            window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${url}`, '_blank');
            break;
          case 3: // Pinterest
            window.open(`https://pinterest.com/pin/create/button/?url=${url}&description=${text}`, '_blank');
            break;
          case 4: // Reddit
            window.open(`https://www.reddit.com/submit?url=${url}&title=${title}`, '_blank');
            break;
          case 5: // WhatsApp
            window.open(`https://wa.me/?text=${text} ${url}`, '_blank');
            break;
          case 6: // Telegram
            window.open(`https://t.me/share/url?url=${url}&text=${text}`, '_blank');
            break;
          case 7: // Email
            window.location.href = `mailto:?subject=${title}&body=${text} ${url}`;
            break;
        }
        
        // Close share options after sharing
        setTimeout(() => {
          shareContainer.classList.remove('show-options');
        }, 50);
      });
    }
  });
  
  // Handle native sharing (Web Share API)
  if (nativeShareBtn) {
    nativeShareBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      
      if (navigator.share) {
        navigator.share({
            title: document.title,
            text: 'Check out this page!',
            url: window.location.href
          })
          .then(() => console.log('Shared successfully'))
          .catch((error) => console.log('Error sharing:', error));
      } else {
        // Fallback for browsers that don't support Web Share API
        const textArea = document.createElement('textarea');
        textArea.value = window.location.href;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        alert('URL copied to clipboard! Native sharing not supported in this browser.');
      }
      
      // Close share options after sharing
      setTimeout(() => {
        shareContainer.classList.remove('show-options');
      }, 300);
    });
  }

  // --- Draggable Functionality ---
  let isDragging = false;
  let startY = 0;
  let startTop = 0;
  const padding = 10; // Reduced padding from top and bottom of the screen
  
  // Function to set share container position
  function setContainerPosition(top) {
    const windowHeight = window.innerHeight;
    const containerHeight = shareContainer.offsetHeight;
    
    // Set limits: prevent from going offscreen
    if (top < padding) {
      top = padding;
    } else if (top > windowHeight - containerHeight - padding) {
      top = windowHeight - containerHeight - padding;
    }
    
    // Set position using CSS
    shareContainer.style.top = `${top}px`;
    shareContainer.style.transform = 'none';
  }
  
  // Initialize dragging
  shareContainer.addEventListener('mousedown', function(e) {
    // Only allow dragging when clicking directly on the share container or button
    if (e.target.closest('.custom-share-option')) {
      return;
    }
    
    // If menu is open, only allow dragging from the main button
    if (shareContainer.classList.contains('show-options') && !e.target.closest('.custom-share-btn')) {
      return;
    }
    
    e.preventDefault();
    isDragging = true;
    shareContainer.classList.add('dragging');
    
    // Get initial positions
    const rect = shareContainer.getBoundingClientRect();
    startY = e.clientY;
    startTop = rect.top;
  });
  
  // Same for touch devices
  shareContainer.addEventListener('touchstart', function(e) {
    // Only allow dragging when touching directly on the share container or button
    if (e.target.closest('.custom-share-option')) {
      return;
    }
    
    // If menu is open, only allow dragging from the main button
    if (shareContainer.classList.contains('show-options') && !e.target.closest('.custom-share-btn')) {
      return;
    }
    
    const touch = e.touches[0];
    isDragging = true;
    shareContainer.classList.add('dragging');
    
    // Get initial positions
    const rect = shareContainer.getBoundingClientRect();
    startY = touch.clientY;
    startTop = rect.top;
  }, { passive: false });
  
  // Handle drag movement
  document.addEventListener('mousemove', function(e) {
    if (!isDragging) return;
    
    e.preventDefault();
    const deltaY = e.clientY - startY;
    const newTop = startTop + deltaY;
    
    setContainerPosition(newTop);
  });
  
  // Same for touch devices
  document.addEventListener('touchmove', function(e) {
    if (!isDragging) return;
    
    const touch = e.touches[0];
    const deltaY = touch.clientY - startY;
    const newTop = startTop + deltaY;
    
    setContainerPosition(newTop);
  }, { passive: false });
  
  // End dragging
  document.addEventListener('mouseup', function() {
    if (isDragging) {
      isDragging = false;
      shareContainer.classList.remove('dragging');
    }
  });
  
  // Same for touch devices
  document.addEventListener('touchend', function() {
    if (isDragging) {
      isDragging = false;
      shareContainer.classList.remove('dragging');
    }
  });
  
  // Handle window resize to keep the container in bounds
  window.addEventListener('resize', function() {
    if (shareContainer.style.top) {
      const currentTop = parseInt(shareContainer.style.top);
      setContainerPosition(currentTop);
    }
  });
});
</script>
