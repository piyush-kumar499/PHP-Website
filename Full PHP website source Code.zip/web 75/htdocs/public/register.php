<?php
session_start();
require_once('../private/config.php');
require_once('../private/db.php');
require_once('../private/auth.php');
require_once('../private/email_otp.php');

deleteExpiredUnverifiedUser();

// Check if user is already logged in
if (isLoggedIn()) {
    header("Location: /");
    exit();
}

$error = '';
$success = '';
$verificationRequired = false;
$userEmail = '';

// Process registration form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Validate inputs
    if (empty($name) || empty($email) || empty($password) || empty($confirm_password)) {
        $error = "Please fill in all required fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } elseif (strlen($password) < 8) {
        $error = "Password must be at least 8 characters long.";
    } elseif (!preg_match('/[0-9]/', $password)) {
        $error = "Password must contain at least one number.";
    } elseif (!preg_match('/[a-zA-Z]/', $password)) {
        $error = "Password must contain at least one letter (uppercase or lowercase).";
    } else {
        // Check if email already exists but is unverified
        $existingUser = dbSelectOne("SELECT * FROM users WHERE email = ? AND email_verified = 0", [$email]);
        
        if ($existingUser) {
            // Email exists but is unverified, show verification modal
            $verificationRequired = true;
            $userEmail = $email;
            $_SESSION['pending_verification_email'] = $email;
            $_SESSION['temp_user_id'] = $existingUser['id'];
            $_SESSION['temp_user_name'] = $existingUser['name'];
            $_SESSION['temp_user_email'] = $existingUser['email'];
        } else {
            // Attempt to register the user
            $result = registerUser($name, $email, $password);
            
            if (is_array($result) && isset($result['requires_verification'])) {
                // Redirect to OTP verification page
                header("Location: /verify_otp");
                exit();
            } elseif ($result !== true) {
                $error = $result; // Error message returned from registration function
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include_once ('../private/favicon.php'); ?>
    <title>Register - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="/assets/css/auth.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <style> 
    /* General Styles */
body {
    font-family: Arial, sans-serif;
    background: #f4f7f6;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}

/* Authentication Container */
.auth-container {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    width: 100%;
    padding: 10px;
}

.auth-form {
    background: #ffffff;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 400px;
    text-align: center;
}

/* Title */
.auth-form h1 {
    font-size: 24px;
    color: #4a00e0;
    font-weight: 700;
    background: linear-gradient(to right, #8e2de2, #4a00e0);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin-bottom: 20px;
}

/* Success & Error Messages */
.success-message {
    background: rgba(0, 255, 0, 0.1);
    color: #28a745;
    padding: 10px;
    border-radius: 5px;
    margin-bottom: 15px;
    font-size: 14px;
}

.error-message {
    background: rgba(255, 0, 0, 0.1);
    color: #d9534f;
    padding: 10px;
    border-radius: 5px;
    margin-bottom: 15px;
    font-size: 14px;
}

/* Form Group */
.form-group {
    margin-bottom: 15px;
    text-align: left;
}

label {
    display: block;
    font-weight: bold;
    margin-bottom: 5px;
    color: #333;
}

input[type="text"],
input[type="email"],
input[type="password"] {
    width: 100%;
    max-width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
    box-sizing: border-box;
}

input[type="text"]:focus,
input[type="email"]:focus,
input[type="password"]:focus {
    border-color: #8e2de2;
    outline: none;
}

/* Password Hint */
small {
    display: block;
    margin-top: 5px;
    color: #666;
}

/* Terms and Conditions */
.terms {
    display: flex;
    align-items: center;
    font-size: 14px;
}

.terms input {
    margin-right: 5px;
}

.terms a {
    color: #8e2de2;
    text-decoration: none;
    font-weight: 600;
}

.terms a:hover {
    color: #4a00e0;
    text-decoration: underline;
}

/* Register Button */
.btn-primary {
    display: inline-block;
    width: 100%;
    padding: 12px;
    font-size: 16px;
    font-weight: 600;
    text-align: center;
    color: #ffffff;
    background: linear-gradient(to right, #8e2de2, #4a00e0);
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease-in-out;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    position: relative;
    overflow: hidden;
    z-index: 1;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 15px rgba(142, 45, 226, 0.4);
    background: linear-gradient(to right, #7d28c7, #3900c9);
}

.btn-primary::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(to right, rgba(255, 255, 255, 0), rgba(255, 255, 255, 0.3), rgba(255, 255, 255, 0));
    transition: all 0.5s ease;
    z-index: -1;
}

.btn-primary:hover::before {
    left: 100%;
}

.btn-primary:active {
    transform: translateY(0);
    box-shadow: 0 3px 4px rgba(0, 0, 0, 0.15);
}

/* Authentication Links */
.auth-links {
    margin-top: 15px;
}

.auth-links p {
    font-size: 14px;
    color: #333;
}

.auth-links a {
    color: #8e2de2;
    font-weight: 600;
    text-decoration: none;
    transition: color 0.3s ease-in-out;
}

.auth-links a:hover {
    color: #4a00e0;
    text-decoration: underline;
}

/* Responsive Design */
@media (max-width: 480px) {
    .auth-form {
        padding: 20px;
        width: 90%;
    }

    .btn-primary {
        font-size: 14px;
        padding: 10px;
    }
}
/* Password visibility toggle */
.password-container {
    position: relative;
    display: flex;
    width: 100%;
}

.password-container input[type="password"],
.password-container input[type="text"] {
    flex: 1;
}

.toggle-password {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    border: none;
    background: transparent;
    cursor: pointer;
    color: #8e2de2;
    font-size: 16px;
    z-index: 10;
    padding: 0;
    height: 20px;
    width: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.toggle-password:hover {
    color: #4a00e0;
}

.toggle-password:focus {
    outline: none;
}

/* Modal Overlay */
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 1000;
    visibility: hidden;
    opacity: 0;
    transition: visibility 0s linear 0.25s, opacity 0.25s;
}

.modal-overlay.active {
    visibility: visible;
    opacity: 1;
    transition-delay: 0s;
}

/* Verification Modal */
.verification-modal {
    background: white;
    padding: 30px;
    border-radius: 8px;
    box-shadow: 0px 5px 20px rgba(0, 0, 0, 0.2);
    max-width: 400px;
    width: 90%;
    text-align: center;
    position: relative;
    transform: scale(0.7);
    transition: transform 0.3s;
}

.modal-overlay.active .verification-modal {
    transform: scale(1);
}

.verification-modal h2 {
    margin-top: 0;
    color: #4a00e0;
    font-size: 20px;
}

.verification-modal p {
    margin-bottom: 20px;
    color: #555;
    font-size: 14px;
    line-height: 1.5;
}

.btn-verify {
    background: linear-gradient(to right, #8e2de2, #4a00e0);
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s;
}

.btn-verify:hover {
    box-shadow: 0 4px 10px rgba(142, 45, 226, 0.4);
    transform: translateY(-2px);
}

.close-modal {
    position: absolute;
    top: 10px;
    right: 10px;
    background: none;
    border: none;
    font-size: 18px;
    color: #888;
    cursor: pointer;
}

.close-modal:hover {
    color: #333;
}
    
/* Password Requirements Styles */
.password-requirements {
    margin-top: 8px;
    max-height: 0;
    overflow: hidden;
    opacity: 0;
    transition: max-height 0.4s ease-in-out, opacity 0.3s ease-in-out, margin-top 0.3s ease;
}

.password-requirements.visible {
    max-height: 200px; /* Adjust this value based on your content height */
    opacity: 1;
    margin-top: 8px;
}

.requirements-list {
    margin: 5px 0 0 15px;
    padding: 0;
    font-size: 12px;
    color: #666;
    list-style-type: none;
}

.requirements-list li {
    position: relative;
    padding-left: 15px;
    margin-bottom: 3px;
    line-height: 1.4;
    transform: translateY(0);
    transition: transform 0.2s ease;
}

.requirements-list li:before {
    content: '✕';
    color: #ff4d4d;
    position: absolute;
    left: 0;
}

.requirements-list li.met:before {
    content: '✓';
    color: #2ecc71;
}

.optional {
    font-style: italic;
    color: #888;
}
    </style>
</head>
<body>
    
    <div class="auth-container">
        <div class="auth-form">
            <h1>Create an Account</h1>
            
            <?php if (!empty($error)): ?>
                <div class="error-message"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if (!empty($success)): ?>
                <div class="success-message"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <form method="post" action="register" id="registerForm">
                <div class="form-group">
                    <label for="name">Full Name</label>
                    <input type="text" id="name" name="name" value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="password-container">
                        <input type="password" id="password" name="password" required>
                        <button type="button" class="toggle-password" data-target="password">
                            <i class="fa fa-eye"></i>
                        </button>
                    </div>
                    <div class="password-requirements" style="display: none;">
                        <small>Password must have:</small>
                        <ul class="requirements-list">
                            <li id="length-check">At least 8 characters</li>
                            <li id="letter-check">At least 1 letter (uppercase or lowercase)</li>
                            <li id="number-check">At least 1 number</li>
                            <li id="uppercase-check" class="optional">Uppercase letter (optional)</li>
                            <li id="lowercase-check" class="optional">Lowercase letter (optional)</li>
                            <li id="special-check" class="optional">Special character (optional)</li>
                        </ul>
                    </div>
                </div>

                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <div class="password-container">
                        <input type="password" id="confirm_password" name="confirm_password" required>
                        <button type="button" class="toggle-password" data-target="confirm_password">
                            <i class="fa fa-eye"></i>
                        </button>
                    </div>
                </div>
                
                <div class="form-group terms">
                    <input type="checkbox" id="terms" name="terms" required>
                    <label for="terms">I agree to the <a href="/page/terms">Terms of Service</a> and <a href="/page/privacy">Privacy Policy</a></label>
                </div>
                
                <button type="submit" class="btn btn-primary" id="registerButton">Register</button>
            </form>
            
            <div class="auth-links">
                <p>Already have an account? <a href="/login">Login</a></p>
            </div>
        </div>
    </div>
   
    <!-- Verification Modal -->
    <div class="modal-overlay" id="verification-modal-overlay">
        <div class="verification-modal">
            <button class="close-modal">&times;</button>
          <h2>Email Already Registered - Verification Needed</h2>
<p>We noticed you've previously started registration with this email address but haven't completed the verification process. To access your account, please verify your email by clicking the button below. We'll send you a verification code to ensure your account security.</p>
            <form action="/verify_otp" method="get">
                <input type="hidden" name="email" value="<?php echo htmlspecialchars($userEmail); ?>">
                <button type="submit" class="btn-verify">Verify Email</button>
            </form>
        </div>
    </div>
   
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Password visibility toggle
            const toggleButtons = document.querySelectorAll('.toggle-password');
            
            toggleButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const targetId = this.getAttribute('data-target');
                    const inputField = document.getElementById(targetId);
                    
                    // Toggle the input type
                    if (inputField.type === 'password') {
                        inputField.type = 'text';
                        this.innerHTML = '<i class="fa fa-eye-slash"></i>';
                    } else {
                        inputField.type = 'password';
                        this.innerHTML = '<i class="fa fa-eye"></i>';
                    }
                });
            });
            
            // Get password elements
            const passwordInput = document.getElementById('password');
            const passwordRequirements = document.querySelector('.password-requirements');
            const lengthCheck = document.getElementById('length-check');
            const letterCheck = document.getElementById('letter-check');
            const uppercaseCheck = document.getElementById('uppercase-check');
            const lowercaseCheck = document.getElementById('lowercase-check');
            const numberCheck = document.getElementById('number-check');
            const specialCheck = document.getElementById('special-check');
            const registerForm = document.getElementById('registerForm');
            const registerButton = document.getElementById('registerButton');
            
            // Show password requirements when password field is focused
            passwordInput.addEventListener('focus', function() {
                passwordRequirements.style.display = 'block';
                
                // Use setTimeout to allow the display change to take effect first
                setTimeout(function() {
                    passwordRequirements.classList.add('visible');
                }, 10);
                
                checkPasswordStrength(); // Check initial state
            });
            
            // Hide password requirements when focus moves away from password field
            passwordInput.addEventListener('blur', function() {
                passwordRequirements.classList.remove('visible');
                
                // Wait for the transition to complete before hiding
                setTimeout(function() {
                    if (!passwordInput.matches(':focus')) {
                        passwordRequirements.style.display = 'none';
                    }
                }, 400); // Match this to your longest transition duration
            });
            
            // Function to check password strength
            function checkPasswordStrength() {
                const password = passwordInput.value;
                let isValid = true;
                
                // Reset checks
                lengthCheck.classList.remove('met');
                letterCheck.classList.remove('met');
                uppercaseCheck.classList.remove('met');
                lowercaseCheck.classList.remove('met');
                numberCheck.classList.remove('met');
                specialCheck.classList.remove('met');
                
                // Check length (required)
                if (password.length >= 8) {
                    lengthCheck.classList.add('met');
                } else {
                    isValid = false;
                }
                
                // Check for any letter - uppercase or lowercase (required)
                if (/[a-zA-Z]/.test(password)) {
                    letterCheck.classList.add('met');
                } else {
                    isValid = false;
                }
                
                // Check uppercase (optional)
                if (/[A-Z]/.test(password)) {
                    uppercaseCheck.classList.add('met');
                }
                
                // Check lowercase (optional)
                if (/[a-z]/.test(password)) {
                    lowercaseCheck.classList.add('met');
                }
                
                // Check numbers (required)
                if (/[0-9]/.test(password)) {
                    numberCheck.classList.add('met');
                } else {
                    isValid = false;
                }
                
                // Check special characters (optional)
                if (/[^A-Za-z0-9]/.test(password)) {
                    specialCheck.classList.add('met');
                }
                
                return isValid;
            }
            
            // Check password on input while focused
            passwordInput.addEventListener('input', checkPasswordStrength);
            
            // Check matching passwords
            const confirmPasswordInput = document.getElementById('confirm_password');
            confirmPasswordInput.addEventListener('input', function() {
                const password = passwordInput.value;
                const confirmPassword = this.value;
                
                if (password !== confirmPassword) {
                    this.setCustomValidity("Passwords don't match");
                } else {
                    this.setCustomValidity('');
                }
            });
            
            // Form submission validation
            registerForm.addEventListener('submit', function(event) {
                const password = passwordInput.value;
                
                // Check if password meets requirements
                if (password.length < 8 || 
                    !(/[0-9]/.test(password)) || 
                    !(/[a-zA-Z]/.test(password))) {
                    
                    event.preventDefault();
                    alert('Password must meet all the required criteria: at least 8 characters, one letter (uppercase or lowercase), and one number.');
                    return false;
                }
                
                // Check if passwords match
                if (password !== confirmPasswordInput.value) {
                    event.preventDefault();
                    alert('Passwords do not match.');
                    return false;
                }
                
                return true;
            });
            
            // Verification modal
            const showVerificationModal = <?php echo $verificationRequired ? 'true' : 'false'; ?>;
            const modalOverlay = document.getElementById('verification-modal-overlay');
            const closeModalBtn = document.querySelector('.close-modal');
            
            if (showVerificationModal) {
                modalOverlay.classList.add('active');
            }
            
            if (closeModalBtn) {
                closeModalBtn.addEventListener('click', function() {
                    modalOverlay.classList.remove('active');
                });
            }
        });
    </script>   
</body>
</html>