<?php
// Include your database connection and functions
require_once __DIR__ . '/../private/config.php';
require_once __DIR__ . '/../private/db.php';

// Format view count function (from the original code)
function formatViewCount($views) {
    if ($views >= 1000000) {
        return number_format($views / 1000000, 2) . 'M';
    } elseif ($views >= 1000) {
        return number_format($views / 1000, 2) . 'K';
    } else {
        return number_format($views);
    }
}

// Define search query function for different content types
function getSearchResults($searchTerm = '') {
    $results = [
        'tools' => [],
        'pages' => [],
        'blogs' => [],
        'total' => 0
    ];
    
    if (empty($searchTerm)) {
        return $results;
    }
    
    // 1. Search tools
    $toolsQuery = "SELECT t.*, si.keywords, ts.views FROM tools t 
                  LEFT JOIN tools_search_index si ON t.id = si.tool_id
                  LEFT JOIN tool_stats ts ON t.id = ts.tool_id
                  WHERE 
                    t.name LIKE ? OR 
                    t.description LIKE ? OR 
                    t.category LIKE ? OR 
                    si.keywords LIKE ?
                  ORDER BY ts.views DESC, t.created_at DESC";
    
    $searchParam = '%' . $searchTerm . '%';
    $toolResults = dbSelect($toolsQuery, [$searchParam, $searchParam, $searchParam, $searchParam]);
    
    if ($toolResults) {
        $results['tools'] = $toolResults;
        $results['total'] += count($toolResults);
    }
    
    // 2. Search pages (this would depend on your database structure)
    // If you have pages stored in the database, add another query here
    
    // 3. Search any other content types you might have
    
    return $results;
}

// Get search term from URL parameter
$searchTerm = isset($_GET['q']) ? trim($_GET['q']) : '';
$searchResults = getSearchResults($searchTerm);

// Page title
$pageTitle = !empty($searchTerm) ? "Search Results for: {$searchTerm}" : "Search";

// Include header
include('header.php');
?>

<link rel="stylesheet" href="/assets/css/search.css">

<!-- Search Page Container -->
<div class="sp_page_container">
    <div class="sp_full_height_wrapper">
        <div class="sp_inner_container">
            <div class="sp_header">
                <h1 class="sp_page_title">
                    <?php if (!empty($searchTerm)): ?>
                        <span class="sp_title_prefix">Search Results for:</span>
                        <span class="sp_title_term"><?php echo htmlspecialchars($searchTerm); ?></span>
                    <?php else: ?>
                        Search
                    <?php endif; ?>
                </h1>
                
                <!-- New Modern Search Form -->
                <div class="sp_form_container">
                    <div class="sp_search_container">
    <form method="GET" action="search.php" class="sp_search_form" role="search">
        <input type="text" name="q" class="sp_search_input" 
            placeholder="Search for tools, pages, and more..." 
            value="<?php echo htmlspecialchars($searchTerm); ?>" 
            aria-label="Search" autofocus>
        <button type="button" class="sp_clear_button" aria-label="Clear search">
            <i class="fas fa-times"></i>
        </button>
        <button type="submit" class="sp_search_button" aria-label="Search">
            <i class="fas fa-search"></i>
        </button>
    </form>
</div>
                </div>
                
                <?php if (!empty($searchTerm)): ?>
                    <!-- Search Results Summary -->
                    <div class="sp_results_summary">
                        <p>Found <span class="sp_results_count"><?php echo $searchResults['total']; ?></span> result<?php echo $searchResults['total'] !== 1 ? 's' : ''; ?> for "<span class="sp_query"><?php echo htmlspecialchars($searchTerm); ?></span>"</p>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="sp_content">
                <?php if (!empty($searchTerm)): ?>
                    <?php if ($searchResults['total'] > 0): ?>
                        <!-- Tools Results -->
                        <?php if (!empty($searchResults['tools'])): ?>
                            <div class="sp_results_section">
                                <h2 class="sp_section_title">Tools (<?php echo count($searchResults['tools']); ?>)</h2>
                                <div class="sp_tools_grid">
                                    <?php foreach ($searchResults['tools'] as $index => $tool): ?>
                                        <div class="sp_tool_card_wrapper" style="--card-index: <?php echo $index; ?>">
                                            <div class="sp_tool_card"
                                                data-tool-slug="<?php echo urlencode($tool['slug']); ?>"
                                                data-tool-name="<?php echo htmlspecialchars($tool['name']); ?>"
                                                data-tool-category="<?php echo htmlspecialchars($tool['category']); ?>"
                                                data-tool-description="<?php echo htmlspecialchars($tool['description']); ?>"
                                                data-tool-keywords="<?php echo htmlspecialchars($tool['keywords'] ?? ''); ?>">
                                                <div class="sp_tool_card_body">
                                                    <h5 class="sp_tool_card_title">
                                                        <?php echo highlightSearchTerms(htmlspecialchars($tool['name']), $searchTerm); ?>
                                                    </h5>
                                                    <h6 class="sp_tool_card_subtitle">
                                                        <?php echo highlightSearchTerms(htmlspecialchars($tool['category']), $searchTerm); ?>
                                                    </h6>
                                                    <div class="sp_tool_card_description">
                                                        <div class="sp_tool_card_text">
                                                            <?php echo highlightSearchTerms(htmlspecialchars($tool['description']), $searchTerm); ?>
                                                        </div>
                                                        <a href="#" class="sp_read_more">Read more</a>
                                                    </div>
                                                </div>
                                                <div class="sp_tool_card_footer">
                                                    <a href="/tools/<?php echo urlencode($tool['slug']); ?>" class="sp_view_btn">
                                                        <span>View Tool</span>
                                                        <i class="fas fa-arrow-right sp_btn_icon"></i>
                                                    </a>
                                                    <?php if (!empty($tool['views'])): ?>
                                                    <div class="sp_view_count">
                                                        <i class="fas fa-eye"></i> <?php echo formatViewCount($tool['views']); ?> views
                                                    </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Pages Results - Add more result sections as needed -->
                        <?php if (!empty($searchResults['pages'])): ?>
                            <!-- Pages results here -->
                        <?php endif; ?>
                        
                    <?php else: ?>
                        <!-- No Results Found -->
                        <div class="sp_no_results">
                            <div class="sp_alert">
                                <h4 class="sp_alert_heading">No results found</h4>
                                <p>We couldn't find any content matching "<strong><?php echo htmlspecialchars($searchTerm); ?></strong>". Try different keywords or check your spelling.</p>
                                <hr class="sp_divider">
                                <div class="sp_tips">
                                    <ul class="sp_tips_list">
                                        <li>Try using more general terms</li>
                                        <li>Check for typos or misspellings</li>
                                        <li>Use fewer keywords</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <!-- Initial Search State - No search performed yet -->
                    <div class="sp_initial_state">
                        <div class="sp_illustration">
                            <div class="sp_icon_circle">
                                <i class="fas fa-search sp_big_icon"></i>
                            </div>
                        </div>
                        <h2 class="sp_welcome_title">Search across our entire website</h2>
                        <p class="sp_welcome_text">Find tools, pages, guides, and more</p>
                        <div class="sp_popular">
                            <h6 class="sp_popular_title">Popular searches:</h6>
                            <div class="sp_popular_tags">
                                <a href="search.php?q=AI" class="sp_tag"><i class="fas fa-robot sp_tag_icon"></i> AI Tools</a>
                                <a href="search.php?q=Generator" class="sp_tag"><i class="fas fa-magic sp_tag_icon"></i> Generators</a>
                                <a href="search.php?q=Converter" class="sp_tag"><i class="fas fa-exchange-alt sp_tag_icon"></i> Converters</a>
                                <a href="search.php?q=Premium" class="sp_tag"><i class="fas fa-crown sp_tag_icon"></i> Premium</a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php
// Function to highlight search terms in results
function highlightSearchTerms($text, $searchTerm) {
    if (empty($searchTerm)) return $text;
    
    $searchTerm = preg_quote($searchTerm, '/');
    
    // Check if search term contains multiple words
    $words = explode(' ', $searchTerm);
    
    if (count($words) > 1) {
        // For multi-word searches, highlight the exact phrase
        return preg_replace('/(' . $searchTerm . ')/i', '<span class="sp_highlight">$1</span>', $text);
    } else {
        // For single word searches, use a more careful approach
        // This pattern will match the search term within larger words without breaking them
        return preg_replace('/(' . $searchTerm . ')/i', '<span class="sp_highlight">$1</span>', $text);
    }
}
?>


<script>
document.addEventListener('DOMContentLoaded', function() {
    // Set the layout to be visible explicitly
    document.querySelector('.sp_page_container').style.opacity = '1';
    
    // Get search elements
    const searchInput = document.querySelector('.sp_search_input');
    const clearButton = document.querySelector('.sp_clear_button');
    
    // Show/hide clear button based on input content
    function toggleClearButton() {
        if (searchInput.value.length > 0) {
            clearButton.classList.add('visible');
        } else {
            clearButton.classList.remove('visible');
        }
    }
    
    // Initialize clear button visibility on page load
    toggleClearButton();
    
    // Listen for input changes to toggle clear button
    searchInput.addEventListener('input', toggleClearButton);
    
    // Clear button functionality
    clearButton.addEventListener('click', function() {
        searchInput.value = '';
        toggleClearButton();
        searchInput.focus(); // Keep focus on input after clearing
    });
    
    // Focus search input automatically on page load (if needed)
    if (window.location.search === '') {
        setTimeout(() => {
            searchInput.focus();
        }, 300);
    }
    
    // Search input focus shortcut
    document.addEventListener('keydown', function(e) {
        // Focus search input when pressing '/' key (common shortcut)
        if (e.key === '/' && document.activeElement.tagName !== 'INPUT' && 
            document.activeElement.tagName !== 'TEXTAREA') {
            e.preventDefault();
            searchInput.focus();
        }
        
        // Escape key clears search if input is focused
        if (e.key === 'Escape' && document.activeElement === searchInput) {
            if (searchInput.value) {
                searchInput.value = '';
                toggleClearButton(); // Update clear button visibility after clearing
            } else {
                searchInput.blur(); // Remove focus if already empty
            }
        }
    });
    
    // Add a small interaction effect
    searchInput.addEventListener('focus', function() {
        this.parentNode.classList.add('sp_form_focused');
    });
    
    searchInput.addEventListener('blur', function() {
        this.parentNode.classList.remove('sp_form_focused');
    });
    
    // Setup read more functionality
    const readMoreButtons = document.querySelectorAll('.sp_read_more');
    
    readMoreButtons.forEach(button => {
        const descriptionText = button.previousElementSibling;
        
        // Show "Read more" only if content is overflowing
        if (descriptionText.scrollHeight > descriptionText.clientHeight) {
            button.classList.remove('hidden');
        } else {
            button.classList.add('hidden');
        }
        
        button.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation(); // Prevent card click event from triggering
            
            if (descriptionText.classList.contains('expanded')) {
                // Collapse
                descriptionText.classList.remove('expanded');
                this.textContent = 'Read more';
                
                // Scroll back to the top of the card if needed
                const card = this.closest('.sp_tool_card');
                card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            } else {
                // Expand
                descriptionText.classList.add('expanded');
                this.textContent = 'Read less';
            }
        });
    });
    
    // Enhance search cards with interactive features
    const searchCards = document.querySelectorAll('.sp_tool_card');
    searchCards.forEach(card => {
        // Make whole card clickable
        card.addEventListener('click', function(e) {
            // Only trigger if not clicking on the View Tool button or Read More button
            if (!e.target.closest('.sp_view_btn') && !e.target.closest('.sp_read_more')) {
                const viewBtn = this.querySelector('.sp_view_btn');
                if (viewBtn) {
                    viewBtn.click();
                }
            }
        });
        
        // Add hover pointer style
        card.style.cursor = 'pointer';
    });
});
</script>

<?php
// Include footer
include('footer.php');
?>