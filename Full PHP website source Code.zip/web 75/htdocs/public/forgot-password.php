<?php
session_start();
require_once('../private/config.php');
require_once('../private/db.php');
require_once('../private/auth.php');

// If user is already logged in, redirect to homepage
if (isLoggedIn()) {
    header("Location: /");
    exit();
}

$success = false;
$error = '';

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $token = $_POST['csrf_token'] ?? '';
    
    // Validate CSRF token
    if (!verifyCSRFToken($token)) {
        $error = "Invalid request, please try again.";
    } elseif (empty($email)) {
        $error = "Please enter your email address.";
    } else {
        // Request password reset
        $result = requestPasswordReset($email);
        
        if ($result === true) {
            // Always show success, even if email doesn't exist (security)
            $success = true;
        } else {
            $error = $result;
        }
    }
}

// Generate CSRF token
$csrfToken = generateCSRFToken();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include_once ('../private/favicon.php'); ?>
    <title>Forgot Password - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="/assets/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    
    <style>
    /* Reusing login page styles */
    body {
        font-family: Arial, sans-serif;
        background: #f4f7f6;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }

    .auth-container {
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        width: 100%;
        padding: 10px;
    }

    .auth-form {
        background: #ffffff;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        width: 100%;
        max-width: 400px;
        text-align: center;
    }

    .auth-form h1 {
        font-size: 24px;
        color: #4a00e0;
        font-weight: 700;
        background: linear-gradient(to right, #8e2de2, #4a00e0);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 20px;
    }

    .form-group {
        margin-bottom: 15px;
        text-align: left;
    }

    label {
        display: block;
        font-weight: bold;
        margin-bottom: 5px;
        color: #333;
    }

    input[type="email"] {
        width: 100%;
        max-width: 100%;
        padding: 12px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 16px;
        box-sizing: border-box;
    }

    input[type="email"]:focus {
        border-color: #8e2de2;
        outline: none;
    }

    .btn-primary {
        display: inline-block;
        width: 100%;
        padding: 12px;
        font-size: 16px;
        font-weight: 600;
        text-align: center;
        color: #ffffff;
        background: linear-gradient(to right, #8e2de2, #4a00e0);
        border: none;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.3s ease-in-out;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        position: relative;
        overflow: hidden;
        z-index: 1;
    }

    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 15px rgba(142, 45, 226, 0.4);
        background: linear-gradient(to right, #7d28c7, #3900c9);
    }

    .error-message {
        background: rgba(255, 0, 0, 0.1);
        color: #d9534f;
        padding: 10px;
        border-radius: 5px;
        margin-bottom: 15px;
        font-size: 14px;
    }

    .success-message {
        background: rgba(40, 167, 69, 0.1);
        color: #28a745;
        padding: 10px;
        border-radius: 5px;
        margin-bottom: 15px;
        font-size: 14px;
    }

    .spam-notice {
        background: #f8f9fa;
        border-left: 4px solid #ffc107;
        color: #495057;
        font-weight: bold;
        margin-top: 10px;
        padding: 10px;
        border-radius: 4px;
        text-align: left;
    }

    .spam-icon {
        text-align: center;
        margin-bottom: 10px;
    }

    .spam-icon i {
        font-size: 24px;
        color: #ffc107;
        display: block;
        animation: pulse 2s infinite;
    }

@keyframes pulse {
    0% {
        transform: scale(1);
    }
    50% {
        transform: scale(1.1);
    }
    100% {
        transform: scale(1);
    }
}

    .instruction-box {
        background: linear-gradient(to right, rgba(142, 45, 226, 0.05), rgba(74, 0, 224, 0.05));
        border: 1px solid rgba(142, 45, 226, 0.2);
        border-radius: 8px;
        padding: 15px;
        margin-bottom: 20px;
        text-align: left;
        color: #333;
        font-size: 15px;
        line-height: 1.5;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
    }

    .instruction-box i {
        color: #8e2de2;
        margin-right: 8px;
    }

    .auth-links {
        margin-top: 15px;
    }

    .auth-links a {
        color: #8e2de2;
        font-weight: 600;
        text-decoration: none;
        transition: color 0.3s ease-in-out;
    }

    .auth-links a:hover {
        color: #4a00e0;
        text-decoration: underline;
    }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-form">
            <h1>Forgot Password</h1>
            
            <?php if ($success): ?>
                <div class="success-message">
                    <p>If your email address is registered in our system, you will receive a password reset link shortly.</p>
            <div class="spam-notice">
    <div class="spam-icon"><i class="fas fa-exclamation-triangle"></i></div>
    <p>Please check both your inbox and spam folder, as sometimes these emails are filtered as spam.</p>
</div>
                </div>
            <?php elseif (!empty($error)): ?>
                <div class="error-message"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if (!$success): ?>
                <div class="instruction-box">
                    <i class="fas fa-info-circle"></i> To reset your password, please enter your registered email address below. We'll send you a secure link to create a new password.
                </div>
                
                <form method="post" action="forgot-password">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                    
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Send Reset Link</button>
                </form>
            <?php endif; ?>
            
            <div class="auth-links">
                <p><a href="/login">Back to Login</a></p>
            </div>
        </div>
    </div>
    
    <script src="/assets/js/main.js"></script>
</body>
</html>