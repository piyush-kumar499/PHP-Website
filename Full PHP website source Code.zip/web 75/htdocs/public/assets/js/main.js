let countdownDate = new Date("April 5, 2025 12:00:00").getTime();

    function updateCountdown() {
        let now = new Date().getTime();
        let distance = countdownDate - now;

        let days = Math.floor(distance / (1000 * 60 * 60 * 24));
        let hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        let minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        let seconds = Math.floor((distance % (1000 * 60)) / 1000);

        animateChange("days", days);
        animateChange("hours", hours);
        animateChange("minutes", minutes);
        animateChange("seconds", seconds);

        if (distance < 0) {
            clearInterval(timer);
            document.getElementById("coming-soon").style.display = "none";
        }
    }

    function animateChange(id, newValue) {
        let element = document.getElementById(id);
        let currentValue = element.innerText;

        if (currentValue !== String(newValue).padStart(2, '0')) {
            let newDigit = document.createElement("span");
            newDigit.className = "time-digit drop-animation";
            newDigit.innerText = String(newValue).padStart(2, '0');

            element.parentNode.replaceChild(newDigit, element);
            newDigit.id = id;
        }
    }

    let timer = setInterval(updateCountdown, 1000);
    updateCountdown();
