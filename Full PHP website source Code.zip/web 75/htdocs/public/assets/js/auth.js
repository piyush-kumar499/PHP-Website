// Add Font Awesome for the eye icons
document.head.innerHTML += '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">';

// Password visibility toggle
document.addEventListener('DOMContentLoaded', function() {
    const toggleButtons = document.querySelectorAll('.toggle-password');
    
    toggleButtons.forEach(button => {
        button.addEventListener('click', function() {
            const targetId = this.getAttribute('data-target');
            const inputField = document.getElementById(targetId);
            
            // Toggle the input type
            if (inputField.type === 'password') {
                inputField.type = 'text';
                this.innerHTML = '<i class="fa fa-eye-slash"></i>';
            } else {
                inputField.type = 'password';
                this.innerHTML = '<i class="fa fa-eye"></i>';
            }
        });
    });
    
    // Set up countdown timer for blocked users
    const countdownElement = document.querySelector('.countdown');
    if (countdownElement) {
        const secondsRemaining = parseInt(countdownElement.getAttribute('data-seconds'), 10);
        
        if (!isNaN(secondsRemaining) && secondsRemaining > 0) {
            let remainingSeconds = secondsRemaining;
            
            // Store the block expiration time in localStorage
            const blockExpires = Date.now() + (remainingSeconds * 1000);
            localStorage.setItem('loginBlockExpires', blockExpires);
            
            // Update the countdown every second
            const countdownInterval = setInterval(() => {
                remainingSeconds--;
                
                if (remainingSeconds <= 0) {
                    clearInterval(countdownInterval);
                    localStorage.removeItem('loginBlockExpires');
                    window.location.reload(); // Refresh the page when the block expires
                } else {
                    countdownElement.textContent = formatTimeRemaining(remainingSeconds);
                }
            }, 1000);
        }
    }
    
    // Check for existing block in localStorage when the page loads
    const storedBlockExpires = localStorage.getItem('loginBlockExpires');
    if (storedBlockExpires && !countdownElement) {
        const now = Date.now();
        const blockExpires = parseInt(storedBlockExpires, 10);
        
        if (blockExpires > now) {
            // There's an active block, disable the form
            const form = document.getElementById('login-form');
            if (form) {
                const inputs = form.querySelectorAll('input, button');
                inputs.forEach(input => {
                    input.disabled = true;
                });
                
                // Create a block message
                const blockMessage = document.createElement('div');
                blockMessage.className = 'block-message';
                blockMessage.innerHTML = `
                    <p><strong>Account temporarily locked</strong></p>
                    <p>Too many failed login attempts. Please try again after <span class="countdown" data-seconds="${Math.floor((blockExpires - now) / 1000)}">${formatTimeRemaining(Math.floor((blockExpires - now) / 1000))}</span>.</p>
                `;
                
                // Insert the block message before the form
                form.parentNode.insertBefore(blockMessage, form);
                
                // Set up the countdown again
                const insertedCountdown = blockMessage.querySelector('.countdown');
                let remainingSeconds = Math.floor((blockExpires - now) / 1000);
                
                const countdownInterval = setInterval(() => {
                    remainingSeconds--;
                    
                    if (remainingSeconds <= 0) {
                        clearInterval(countdownInterval);
                        localStorage.removeItem('loginBlockExpires');
                        window.location.reload(); // Refresh the page when the block expires
                    } else {
                        insertedCountdown.textContent = formatTimeRemaining(remainingSeconds);
                    }
                }, 1000);
            }
        } else {
            // Block has expired
            localStorage.removeItem('loginBlockExpires');
        }
    }
});

/**
 * Format seconds into a human-readable time string
 * @param {number} seconds - Number of seconds to format
 * @return {string} Formatted time string
 */
function formatTimeRemaining(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
        return `${hours} hour${hours !== 1 ? 's' : ''} ${minutes} minute${minutes !== 1 ? 's' : ''}`;
    } else if (minutes > 0) {
        return `${minutes} minute${minutes !== 1 ? 's' : ''} ${secs} second${secs !== 1 ? 's' : ''}`;
    } else {
        return `${secs} second${secs !== 1 ? 's' : ''}`;
    }
}

// Function to store device fingerprint cookie
function setDeviceFingerprint() {
    // Create a simple fingerprint based on browser and screen information
    const fingerprint = {
        userAgent: navigator.userAgent,
        language: navigator.language,
        screenWidth: screen.width,
        screenHeight: screen.height,
        colorDepth: screen.colorDepth,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        platform: navigator.platform,
        plugins: Array.from(navigator.plugins).map(p => p.name).join(','),
        timestamp: new Date().getTime()
    };
    
    // Create a hash from the fingerprint
    const fingerprintJson = JSON.stringify(fingerprint);
    const fingerprintHash = hashString(fingerprintJson);
    
    // Store the fingerprint in localStorage with a long expiration
    localStorage.setItem('deviceFingerprint', fingerprintHash);
    
    // Also set as a cookie for server-side access
    document.cookie = `deviceFingerprint=${fingerprintHash}; path=/; max-age=31536000`; // 1 year
}

// Simple string hashing function
function hashString(str) {
    let hash = 0;
    if (str.length === 0) return hash;
    
    for (let i = 0; i < str.length; i++) {
        const char = str.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash; // Convert to 32bit integer
    }
    
    return hash.toString(16); // Convert to hex string
}

// Set the device fingerprint when the page loads
setDeviceFingerprint();