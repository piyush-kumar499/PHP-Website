<?php
// Start a session to maintain state securely
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);

// Get user notification count if available
$notificationCount = 0;
if ($isLoggedIn && isset($_SESSION['notification_count'])) {
    $notificationCount = (int)$_SESSION['notification_count'];
}

// Security headers to prevent common attacks
header("X-XSS-Protection: 1; mode=block");
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: SAMEORIGIN");
header("Content-Security-Policy: default-src 'self'; script-src 'self' https://cdnjs.cloudflare.com 'unsafe-inline'; style-src 'self' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com 'unsafe-inline'; font-src 'self' https://cdnjs.cloudflare.com;");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include_once('../private/favicon.php'); ?>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="/assets/css/remove-default-hover.css">
    
<style>
/* Header Styles */
body.bg-gray-50 {
    transition: background-color 0.3s ease;
}

.ai-main-site-header {
    background-color: #ffffff;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 9999;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
    transition: box-shadow 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}

.ai-main-site-header:hover {
    box-shadow: 0 4px 12px rgba(147, 51, 234, 0.1);
}

/* Desktop Navbar Styling */
.desktop-navbar {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: 0.45rem;
  padding-bottom: 0.45rem;
}

@media (min-width: 768px) {
  .desktop-navbar {
    padding-top: 0.65rem;
    padding-bottom: 0.65rem;
  }
}

/* Logo Container Styles */
.logo-container {
    padding-left: 1rem;
    position: relative;
    overflow: hidden;
    transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
}

.logo-container:hover {
    transform: translateY(-1px);
}

.logo-image {
    height: 2.6rem;
    width: auto;
    transition: transform 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94)
}


/* =================================== DESKTOP LAYOUTS STYLE START FROM HERE =================================== */


/* Desktop Navigation Container */
.desktop-nav-container {
    display: none;
    align-items: center;
    justify-content: center;
    flex: 1;
    height: 100%;
    position: relative;
    transition: transform 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94),
                opacity 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}

.desktop-nav-container:before {
    content: '';
    position: absolute;
    left: 0;
    bottom: -0.5rem;
    width: 100%;
    height: 2px;
    background: linear-gradient(90deg, rgba(147, 51, 234, 0), rgba(147, 51, 234, 0.1), rgba(147, 51, 234, 0));
    transform: scaleX(0.8);
    opacity: 0;
    transition: transform 0.5s cubic-bezier(0.22, 1, 0.36, 1),
                opacity 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}

.desktop-nav-container:hover:before {
    transform: scaleX(1);
    opacity: 1;
}

@media (min-width: 768px) {
    .desktop-nav-container {
        display: flex;
        transform: translateY(0);
        opacity: 1;
        animation: navFadeIn 0.5s cubic-bezier(0.34, 1.56, 0.64, 1);
    }
    
    @keyframes navFadeIn {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
}

/* Desktop Navigation Menu */
.desktop-nav-menu {
    display: flex;
    list-style: none;
    padding: 0;
    margin: 0;
    gap: 1.25rem;
    transition: gap 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
    position: relative;
}

@media (min-width: 1024px) {
    .desktop-nav-menu {
        gap: 1.5rem;
    }
}

.desktop-nav-menu:after {
    content: '';
    position: absolute;
    bottom: -5px;
    left: 0;
    width: 100%;
    height: 1px;
    background: linear-gradient(90deg, rgba(147, 51, 234, 0), rgba(147, 51, 234, 0.1), rgba(147, 51, 234, 0));
    transform: scaleX(0);
    opacity: 0;
    transition: transform 0.6s cubic-bezier(0.22, 1, 0.36, 1),
                opacity 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}

.desktop-nav-container:hover .desktop-nav-menu:after {
    transform: scaleX(1);
    opacity: 1;
}

/* Basic Nav Item and Link Styling */
.nav-item {
    position: relative;
    height: 100%;
    display: flex;
    align-items: center;
}

.nav-link {
    display: flex;
    align-items: center;
    height: 100%;
    padding: 0.25rem 0.3rem;
    color: #2d3748;
    text-decoration: none;
    transition: color 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94), 
                padding 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
    position: relative;
}

.nav-link:before {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 2px;
    background: linear-gradient(90deg, #4f46e5, #8b5cf6);
    transform: scaleX(0);
    transform-origin: left;
    transition: transform 0.6s cubic-bezier(0.22, 1, 0.36, 1);
}

.nav-link:hover {
    color: #4f46e5;
    padding-left: 0.5rem;
    padding-right: 0.5rem;
}

.nav-link:hover:before {
    transform: scaleX(1);
}

.nav-link:after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(79, 70, 229, 0.05);
    opacity: 0;
    z-index: -1;
    transition: opacity 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}

.nav-link:hover:after {
    opacity: 1;
}

.nav-link:active {
    transform: scale(0.98);
}

/* Dropdown Icon Animation */
.nav-icon {
    font-size: 0.75rem;
    margin-left: 0.5rem;
    transition: transform 0.5s cubic-bezier(0.34, 1.56, 0.64, 1), 
                color 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}

.nav-link:hover .nav-icon {
    transform: rotate(180deg);
    color: #4f46e5;
}

/* Dropdown Menu Styles */
.dropdown-menu {
    position: absolute;
    left: 0;
    top: 100%;
    margin-top: 0.5rem;
    padding: 0.7rem;
    background-color: #f5f7ff;
    border-radius: 0.5rem;
    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    width: 13rem;
    z-index: 50;
    transition: opacity 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94),
                visibility 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94),
                transform 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
    transform-origin: top;
    transform: translateY(10px);
    opacity: 0;
    visibility: hidden;
    list-style: none;
    border-top: 2px solid #4f46e5;
}

.dropdown-group:hover .dropdown-menu {
    opacity: 1;
    visibility: visible;
    transform: translateY(0);
}

/* Dropdown Item Styles */
.dropdown-item {
    display: block;
    padding: 0.5rem 1.25rem;
    color: #2d3748;
    border-radius: 5px;
    text-decoration: none;
    transition: color 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94),
                background-color 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94),
                padding-left 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
    position: relative;
    overflow: hidden;
}

.dropdown-item:before {
    content: '';
    position: absolute;
    bottom: 0;
    left: 1.25rem;
    width: calc(100% - 2.5rem);
    height: 1px;
    background: linear-gradient(90deg, #4f46e5, #8b5cf6);
    transform: scaleX(0);
    transform-origin: left;
    transition: transform 0.6s cubic-bezier(0.22, 1, 0.36, 1);
}

.dropdown-item:after {
    content: '';
    position: absolute;
    left: 1rem;
    top: 50%;
    width: 0;
    height: 0;
    background-color: transparent;
    border-radius: 50%;
    transform: translateY(-50%) scale(0);
    transition: transform 0.4s cubic-bezier(0.34, 1.56, 0.64, 1),
                background-color 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}

.dropdown-item:hover {
    background-color: rgba(79, 70, 229, 0.05);
    color: #4f46e5;
    padding-left: 1.75rem;
}

.dropdown-item:hover:before {
    transform: scaleX(1);
}

.dropdown-item:hover:after {
    width: 4px;
    height: 4px;
    background-color: #4f46e5;
    transform: translateY(-50%) scale(1);
}

.dropdown-item:active {
    background-color: rgba(79, 70, 229, 0.1);
}

/* Advanced Dropdown Hover Effect */
.dropdown-group:before {
    content: '';
    position: absolute;
    bottom: -0.5rem;
    left: 50%;
    width: 0;
    height: 0;
    border-left: 6px solid transparent;
    border-right: 6px solid transparent;
    border-bottom: 6px solid white;
    transform: translateX(-50%) translateY(0px) scale(0);
    opacity: 0;
    transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1),
                opacity 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    z-index: 51;
}

.dropdown-group:hover:before {
    transform: translateX(-50%) translateY(0) scale(1);
    opacity: 1;
}

/* Dropdown hover effects */
.group ul {
    display: block;
    opacity: 0;
    visibility: hidden;
    transition: opacity 0.2s, visibility 0.2s;
}
    
.group:hover ul {
    opacity: 1;
    visibility: visible;
}

.group ul:hover {
    opacity: 1;
    visibility: visible;
}

/* Dropdown arrow indicator for desktop header dropdowns */
.dropdown-group:before {
    border-bottom-color: #4f46e5;
}

/* Advanced dropdown hover effect for the arrow indicator */
.dropdown-group:hover:before {
    border-bottom-color: #4f46e5;
}

/* Desktop Right Actions */
.desktop-right-actions {
    display: none;
    align-items: center;
    gap: 1.5rem;
    padding-right: 1rem;
}

.desktop-right-actions .active {
    color: #4f46e5;
    background-color: rgba(79, 70, 229, 0.1);
}

@media (min-width: 768px) {
    .desktop-right-actions {
        display: flex;
        padding-right: 1rem;
    }
}

/* Search Container Styles */
.header-search-container {
    position: relative;
}

/* Search Icon Button */
.icon-btn {
    width: 2.5rem;
    height: 2.5rem;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    transition: all 0.5s cubic-bezier(0.34, 1.56, 0.64, 1);
    position: relative;
    overflow: hidden;
    background-color: rgba(247, 250, 252, 0.8);
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
}

.icon-btn:before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: radial-gradient(circle, rgba(118, 45, 219, 0.4) 0%, rgba(79, 70, 229, 0.1) 70%);
    transform: scale(0);
    opacity: 0;
    transition: transform 0.6s cubic-bezier(0.17, 0.67, 0.83, 0.67), opacity 0.4s ease;
}

.icon-btn:hover:before {
    transform: scale(2.5);
    opacity: 1;
}

.icon-btn:focus {
    outline: none;
    box-shadow: 0 0 0 3px rgba(118, 45, 219, 0.35);
}

.icon-btn:hover {
    transform: translateY(-2px) scale(1.15);
    box-shadow: 0 3px 8px rgba(79, 70, 229, 0.3);
}

.icon-btn:active {
    transform: scale(0.9);
    box-shadow: 0 1px 3px rgba(79, 70, 229, 0.2);
}

.icon-btn i {
    font-size: 1.25rem;
    transition: color 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94),
                text-shadow 0.3s ease;
    position: relative;
    z-index: 1;
    background: linear-gradient(135deg, #4f46e5, #7c3aed, #9333ea);
    -webkit-background-clip: text;
    background-clip: text; 
    color: transparent;
    background-size: 200% auto;
}

.icon-btn:hover i {
    text-shadow: 0 0 10px rgba(147, 51, 234, 0.5);
    background-position: right center;
}

.header-search-dropdown {
    background-color: #f5f7ff;
    border-radius: 0.5rem;
    box-shadow: 0 10px 25px -5px rgba(79, 70, 229, 0.1), 0 10px 10px -5px rgba(79, 70, 229, 0.08);
    overflow: hidden;
    transform-origin: top right;
    opacity: 0;
    transform: scale(0.95) translateY(-10px);
    transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1), 
                opacity 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    border-top: 2px solid #4f46e5;
    padding: 0.75rem;
    width: 360px;
    position: absolute;
    right: 0;
    top: 100%;
    margin-top: 0.12rem;
    position: absolute;
    z-index: 50;
}

#desktop-search-dropdown.hidden {
    display: none;
}

#desktop-search-dropdown:not(.hidden) {
    display: block;
    opacity: 1;
    transform: scale(1) translateY(0);
}

.header-search-form {
    position: relative;
    margin: 0;
}

.header-search-input {
    width: 100%;
    border: 1px solid #d1d5db;
    border-radius: 0.5rem;
    padding-left: 1rem;
    padding-right: 3rem;
    padding-top: 0.625rem;
    padding-bottom: 0.625rem;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

.header-search-input:focus {
    outline: none;
    border-color: #4f46e5;
    box-shadow: 0 0 0 3px rgba(147, 51, 234, 0.2);
}

.header-search-button {
    position: absolute;
    right: 0;
    top: 0;
    height: 100%;
    padding-left: 1rem;
    padding-right: 1rem;
    color: #6b7280;
    transition: color 0.3s ease, transform 0.2s ease;
}

.header-search-button:hover {
    color: #4f46e5;
    transform: scale(1.1);
}

.header-search-button:active {
    transform: scale(0.95);
}

.header-search-button:focus {
    outline: none;
}

/* Notifications Section */
.notifications-container {
    position: relative;
}

.notification-toggle-btn {
    width: 2.5rem;
    height: 2.5rem;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    transition: all 0.5s cubic-bezier(0.34, 1.56, 0.64, 1);
    position: relative;
    overflow: hidden;
    background-color: rgba(247, 250, 252, 0.8);
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
}

.notification-toggle-btn:before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: radial-gradient(circle, rgba(118, 45, 219, 0.4) 0%, rgba(79, 70, 229, 0.1) 70%);
    transform: scale(0);
    opacity: 0;
    transition: transform 0.6s cubic-bezier(0.17, 0.67, 0.83, 0.67), opacity 0.4s ease;
}

.notification-toggle-btn:hover:before {
    transform: scale(2.5);
    opacity: 1;
}

.notification-toggle-btn:focus {
    outline: none;
    box-shadow: 0 0 0 3px rgba(118, 45, 219, 0.35);
}

.notification-toggle-btn:hover {
    transform: translateY(-2px) scale(1.15);
    box-shadow: 0 3px 8px rgba(79, 70, 229, 0.3);
}

.notification-toggle-btn:active {
    transform: scale(0.9);
    box-shadow: 0 1px 3px rgba(79, 70, 229, 0.2);
}

.notification-toggle-btn i {
    font-size: 1.25rem;
    transition: color 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94),
                text-shadow 0.3s ease;
    position: relative;
    z-index: 1;
    background: linear-gradient(135deg, #4f46e5, #7c3aed, #9333ea);
    -webkit-background-clip: text;
    background-clip: text; 
    color: transparent;
    background-size: 200% auto;
}

.notification-toggle-btn:hover i {
    text-shadow: 0 0 10px rgba(147, 51, 234, 0.5);
    background-position: right center;
}

.notification-badge {
    position: absolute;
    top: -0.25rem;
    right: -0.25rem;
    background: linear-gradient(135deg, #ef4444, #dc2626);
    color: white;
    font-size: 0.75rem;
    border-radius: 9999px;
    height: 1.25rem;
    width: 1.25rem;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 2px 4px rgba(220, 38, 38, 0.3);
    transform: scale(1);
    transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1), 
                box-shadow 0.3s ease;
    z-index: 2;
}

.notification-toggle-btn:hover .notification-badge {
    transform: scale(1.2);
    box-shadow: 0 0 10px rgba(220, 38, 38, 0.6);
    animation: pulse 1.5s infinite;
}

@keyframes pulse {
    0% {
        box-shadow: 0 0 0 0 rgba(220, 38, 38, 0.6);
    }
    70% {
        box-shadow: 0 0 0 6px rgba(220, 38, 38, 0);
    }
    100% {
        box-shadow: 0 0 0 0 rgba(220, 38, 38, 0);
    }
}

.notifications-dropdown {
    background-color: #f5f7ff;
    border-radius: 0.75rem;
    box-shadow: 0 10px 25px -5px rgba(79, 70, 229, 0.1), 0 10px 10px -5px rgba(79, 70, 229, 0.08);
    padding-top: 0.5rem;
    padding-bottom: 0.5rem;
    transform-origin: top right;
    opacity: 0;
    transform: scale(0.95) translateY(-10px);
    transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1), 
                opacity 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    position: absolute;
    right: 0;
    margin-top: 0.1rem;
    width: 20rem;
    z-index: 50;
}

#desktop-notifications-dropdown.hidden {
    display: none;
}

#desktop-notifications-dropdown:not(.hidden) {
    display: block;
    border-top: 2px solid #4f46e5;
    opacity: 1;
    transform: scale(1) translateY(0);
}

.notifications-header {
    padding-left: 1.25rem;
    padding-right: 1.25rem;
    padding-top: 0.75rem;
    padding-bottom: 0.75rem;
    border-bottom: 1px solid #e5e7eb;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: linear-gradient(to right, #f5f7ff, #f0f4ff);
}

.notifications-title {
    font-weight: 600;
    position: relative;
    display: inline-block;
}

.notifications-title:after {
    content: '';
    position: absolute;
    left: 0;
    bottom: -4px;
    height: 2px;
    width: 2rem;
    background: linear-gradient(to right, #4f46e5, #8b5cf6);
    transform: scaleX(0.7);
    transform-origin: left;
    transition: transform 0.3s ease;
}

.notifications-title:hover:after {
    transform: scaleX(1);
}

.mark-all-read {
    font-size: 0.875rem;
    color: #4f46e5;
    padding: 0.25rem 0.5rem;
    border-radius: 0.375rem;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.mark-all-read:before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(79, 70, 229, 0.1);
    transform: scaleX(0);
    transform-origin: right;
    transition: transform 0.3s ease;
    z-index: -1;
}

.mark-all-read:hover {
    color: #4338ca;
}

.mark-all-read:hover:before {
    transform: scaleX(1);
    transform-origin: left;
}

.notifications-content {
    max-height: 16rem;
    overflow-y: auto;
    scrollbar-width: thin;
    scrollbar-color: #9333ea #f3f4f6;
}

.notifications-content::-webkit-scrollbar {
    width: 6px;
}

.notifications-content::-webkit-scrollbar-track {
    background: #f3f4f6;
    border-radius: 3px;
}

.notifications-content::-webkit-scrollbar-thumb {
    background-color: #c7d2fe;
    border-radius: 3px;
}

.notifications-content::-webkit-scrollbar-thumb:hover {
    background-color: #4f46e5;
}

.notification-item {
    padding-left: 1.25rem;
    padding-right: 1.25rem;
    padding-top: 0.75rem;
    padding-bottom: 0.75rem;
    border-bottom: 1px solid #f3f4f6;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.notification-item:before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 3px;
    background: linear-gradient(to bottom, #4f46e5, #8b5cf6);
    opacity: 0;
    transform: scaleY(0.3);
    transition: transform 0.3s ease, opacity 0.3s ease;
}

.notification-item:hover {
    background-color: rgba(79, 70, 229, 0.05);
}

.notification-item:hover:before {
    opacity: 1;
    transform: scaleY(1);
}

.notification-text {
    font-size: 0.875rem;
    transition: transform 0.3s ease;
}

.notification-item:hover .notification-text {
    transform: translateX(5px);
}

.notification-time {
    font-size: 0.75rem;
    color: #6b7280;
    margin-top: 0.375rem;
    transition: color 0.3s ease;
}

.notification-item:hover .notification-time {
    color: #4f46e5;
}

.notification-empty {
    padding-left: 1.25rem;
    padding-right: 1.25rem;
    padding-top: 1rem;
    padding-bottom: 1rem;
    text-align: center;
    color: #6b7280;
}

.notifications-footer {
    padding-left: 1.25rem;
    padding-right: 1.25rem;
    padding-top: 0.75rem;
    padding-bottom: 0.75rem;
    border-top: 1px solid #e5e7eb;
    text-align: center;
    background: linear-gradient(to right, #f5f7ff, #f0f4ff);
}

.view-all {
    font-size: 0.875rem;
    color: #4f46e5;
    font-weight: 500;
    transition: all 0.3s ease;
    position: relative;
    display: inline-block;
}

.view-all:after {
    content: '';
    position: absolute;
    left: 0;
    bottom: -2px;
    width: 100%;
    height: 1px;
    background: linear-gradient(to right, #4f46e5, #8b5cf6);
    transform: scaleX(0.7);
    transform-origin: left;
    transition: transform 0.3s ease;
}

.view-all:hover {
    color: #4338ca;
}

.view-all:hover:after {
    transform: scaleX(1);
}

/* User Avatar Section */
.avatar-container {
    position: relative;
}

.user-avatar {
    width: 2.5rem;
    height: 2.5rem;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    transition: all 0.5s cubic-bezier(0.34, 1.56, 0.64, 1);
    position: relative;
    overflow: hidden;
    background-color: rgba(247, 250, 252, 0.8);
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
    cursor: pointer;
}

.user-avatar:before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: radial-gradient(circle, rgba(118, 45, 219, 0.4) 0%, rgba(79, 70, 229, 0.1) 70%);
    transform: scale(0);
    opacity: 0;
    transition: transform 0.6s cubic-bezier(0.17, 0.67, 0.83, 0.67), opacity 0.4s ease;
    z-index: 1;
}

.user-avatar:hover:before {
    transform: scale(2.5);
    opacity: 1;
}

.avatar-placeholder {
    width: 100%;
    height: 100%;
    border-radius: 9999px;
    background: linear-gradient(135deg, #e5e7eb, #d1d5db);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    border: 2px solid transparent;
    position: relative;
    z-index: 2;
}

.user-avatar:hover .avatar-placeholder {
    transform: scale(1.1);
    border-color: #4f46e5;
    background: linear-gradient(135deg, #e5e7eb, #c7d2fe);
}

.avatar-placeholder i {
    font-size: 1.25rem;
    transition: color 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94),
                text-shadow 0.3s ease;
    background: linear-gradient(135deg, #4f46e5, #7c3aed, #9333ea);
    -webkit-background-clip: text;
    background-clip: text; 
    color: transparent;
    background-size: 200% auto;
}

.user-avatar:hover .avatar-placeholder i {
    text-shadow: 0 0 10px rgba(147, 51, 234, 0.5);
    background-position: right center;
}

#desktop-user-dropdown {
    background-color: #f5f7ff;
    border-radius: 0.75rem;
    box-shadow: 0 10px 25px -5px rgba(79, 70, 229, 0.1), 0 10px 10px -5px rgba(79, 70, 229, 0.08);
    padding-left: 0.5rem;
    padding-top: 0.5rem;
    padding-bottom: 0.5rem;
    transform-origin: top right;
    opacity: 0;
    transform: scale(0.95) translateY(-10px);
    transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1), 
                opacity 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    position: absolute;
    right: 0;
    margin-top: 0.05rem;
    width: 13rem;
    z-index: 50;
}

#desktop-user-dropdown.hidden {
    display: none;
}

#desktop-user-dropdown:not(.hidden) {
    display: block;
    border-top: 2px solid #4f46e5;
    opacity: 1;
    transform: scale(1) translateY(0);
}

.user-dropdown-item {
    display: block;
    padding-left: 1.25rem;
    padding-right: 1.25rem;
    padding-top: 0.625rem;
    padding-bottom: 0.625rem;
    border-radius: 8px;
    transition: all 0.3s ease;
    position: relative;
    z-index: 1;
    overflow: hidden;
}

.user-dropdown-item:before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 0;
    background: linear-gradient(90deg, rgba(79, 70, 229, 0.1), rgba(79, 70, 229, 0));
    transition: width 0.3s ease;
    z-index: -1;
}

.user-dropdown-item:hover {
    color: #4f46e5;
    transform: translateX(5px);
}

.user-dropdown-item:hover:before {
    width: 100%;
}

.dropdown-icon {
    margin-right: 0.625rem;
    transition: transform 0.3s ease, color 0.3s ease;
}

.user-dropdown-item:hover .dropdown-icon {
    transform: translateX(2px);
    color: #4f46e5;
}

.login-button {
    background: linear-gradient(135deg, #4f46e5, #8b5cf6);
    color: white;
    padding: 0.47rem 1.5rem;
    border-radius: 0.5rem;
    transition: all 0.5s cubic-bezier(0.34, 1.56, 0.64, 1);
    position: relative;
    overflow: hidden;
    box-shadow: 0 4px 6px -1px rgba(79, 70, 229, 0.2), 0 2px 4px -1px rgba(79, 70, 229, 0.1);
    font-weight: 600;
    letter-spacing: 0.01em;
}

.login-button:before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, 
        rgba(255,255,255,0) 0%, 
        rgba(255,255,255,0.4) 50%, 
        rgba(255,255,255,0) 100%);
    transition: left 0.8s cubic-bezier(0.22, 1, 0.36, 1);
    z-index: 1;
}

.login-button:after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, #4338ca, #7c3aed);
    opacity: 0;
    transition: opacity 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    z-index: -1;
}

.login-button:hover {
    transform: translateY(-3px) scale(1.05);
    box-shadow: 0 8px 15px -3px rgba(79, 70, 229, 0.3), 0 6px 10px -3px rgba(79, 70, 229, 0.2);
}

.login-button:hover:before {
    left: 100%;
}

.login-button:hover:after {
    opacity: 1;
}

.login-button:active {
    transform: translateY(0) scale(0.98);
    box-shadow: 0 2px 4px rgba(147, 51, 234, 0.3);
}

.login-button span {
    position: relative;
    z-index: 2;
}


/* =================================== MOBILE LAYOUTS STYLE START FROM HERE =================================== */


/* Mobile Menu Button Styles */
.mobile-menu-container {
    display: flex;
    align-items: center;
    padding-right: 1rem;
}

.mobile-menu-btn {
    width: 2.5rem;
    height: 2.5rem;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 10%;
    transition: all 0.5s cubic-bezier(0.34, 1.56, 0.64, 1);
    position: relative;
    overflow: hidden;
    background-color: rgba(247, 250, 252, 0.8);
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
}

.mobile-menu-btn:before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: radial-gradient(circle, rgba(118, 45, 219, 0.4) 0%, rgba(79, 70, 229, 0.1) 70%);
    transform: scale(0);
    opacity: 0;
    transition: transform 0.6s cubic-bezier(0.17, 0.67, 0.83, 0.67), opacity 0.4s ease;
}

.mobile-menu-btn:hover:before {
    transform: scale(2.5);
    opacity: 1;
}

.mobile-menu-btn:focus {
    outline: none;
    box-shadow: 0 0 0 3px rgba(118, 45, 219, 0.35);
}

.mobile-menu-btn:hover {
    transform: scale(1.15);
    box-shadow: 0 3px 8px rgba(79, 70, 229, 0.3);
}

.mobile-menu-btn:active {
    transform: scale(0.9);
    box-shadow: 0 1px 3px rgba(79, 70, 229, 0.2);
}

.mobile-menu-icon {
    font-size: 1.5rem;
    transition: color 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94),
        transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
    position: relative;
    z-index: 1;
    background: linear-gradient(135deg, #4f46e5, #7c3aed, #9333ea);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
    background-size: 200% auto;
}

.mobile-menu-btn:hover .mobile-menu-icon {
    text-shadow: 0 0 10px rgba(147, 51, 234, 0.5);
    background-position: right center;
    transform: rotate(180deg);
}

@media (min-width: 768px) {
    .mobile-menu-container {
        display: none;
    }
}

/* Mobile Menu Header */
.mobile-header {
    padding: 0.8rem 1.3rem;
    border-bottom: 1px solid #e5e7eb;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #ffffff;
    transition: box-shadow 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    position: relative;
}

.mobile-header:after {
    content: '';
    position: absolute;
    bottom: -1px;
    left: 0;
    width: 100%;
    height: 1px;
    background: linear-gradient(90deg, transparent, #9333ea, transparent);
    transform: scaleX(0);
    transition: transform 0.6s cubic-bezier(0.22, 1, 0.36, 1);
}

#mobile-menu:not(.translate-x-full) .mobile-header:after {
    transform: scaleX(1);
}

.mobile-title {
    font-size: 1.5rem;
    font-weight: 700;
    transition: color 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    position: relative;
    display: inline-block;
    background: linear-gradient(90deg, #4f46e5, #8b5cf6);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
    background-size: 200% auto;
    animation: gradient-shift 8s ease infinite;
}

@keyframes gradient-shift {
    0% { background-position: 0% center; }
    50% { background-position: 100% center; }
    100% { background-position: 0% center; }
}

.mobile-login-btn {
    background: linear-gradient(135deg, #4f46e5, #8b5cf6);
    color: white;
    padding: 0.45rem 1rem;
    border-radius: 0.5rem;
    text-decoration: none;
    transition: all 0.4s cubic-bezier(0.22, 1, 0.36, 1);
    box-shadow: 0 4px 12px rgba(147, 51, 234, 0.2);
    position: relative;
    overflow: hidden;
}

.mobile-login-btn:before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.3) 50%, rgba(255,255,255,0) 100%);
    transition: left 0.6s cubic-bezier(0.22, 1, 0.36, 1);
}

.mobile-login-btn:hover:before {
    left: 100%;
}

.mobile-login-btn:hover {
    background: linear-gradient(135deg, #4338ca, #7c3aed);
    transform: translateY(-2px) scale(1.03);
    box-shadow: 0 8px 20px rgba(147, 51, 234, 0.4);
}

.mobile-login-btn:active {
    transform: translateY(0) scale(0.98);
    box-shadow: 0 2px 6px rgba(147, 51, 234, 0.3);
}

/* Mobile Close Button */
.mobile-close-btn {
    width: 2.5rem;
    height: 2.5rem;
    padding: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    transition: all 0.5s cubic-bezier(0.34, 1.56, 0.64, 1);
    position: relative;
    overflow: hidden;
    background-color: rgba(247, 250, 252, 0.8);
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
}

.mobile-close-btn:before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: radial-gradient(circle, rgba(118, 45, 219, 0.4) 0%, rgba(79, 70, 229, 0.1) 70%);
    transform: scale(0);
    opacity: 0;
    transition: transform 0.6s cubic-bezier(0.17, 0.67, 0.83, 0.67), opacity 0.4s ease;
}

.mobile-close-btn:hover:before {
    transform: scale(2.5);
    opacity: 1;
}

.mobile-close-btn:focus {
    outline: none;
    box-shadow: 0 0 0 3px rgba(118, 45, 219, 0.35);
}

.mobile-close-btn:hover {
    transform: rotate(180deg) scale(1.15);
    box-shadow: 0 3px 8px rgba(79, 70, 229, 0.3);
}

.mobile-close-btn:active {
    transform: rotate(180deg) scale(0.9);
    box-shadow: 0 1px 3px rgba(79, 70, 229, 0.2);
}

.mobile-close-icon {
    font-size: 1.5rem;
    transition: color 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94),
                text-shadow 0.3s ease;
    position: relative;
    z-index: 1;
    background: linear-gradient(135deg, #4f46e5, #7c3aed, #9333ea);
    -webkit-background-clip: text;
    background-clip: text; 
    color: transparent;
    background-size: 200% auto;
}

.mobile-close-btn:hover .mobile-close-icon {
    text-shadow: 0 0 10px rgba(147, 51, 234, 0.5);
    background-position: right center;
}

/* Mobile Content Area */
.mobile-content {
    flex: 1;
    overflow-y: auto;
    scrollbar-width: thin;
    scrollbar-color: #9333ea #f3f4f6;
}

.mobile-content::-webkit-scrollbar {
    width: 6px;
}

.mobile-content::-webkit-scrollbar-track {
    background: #f3f4f6;
    border-radius: 3px;
}

.mobile-content::-webkit-scrollbar-thumb {
    background: linear-gradient(to bottom, #9333ea, #4f46e5);
    border-radius: 3px;
    box-shadow: inset 0 0 6px rgba(0,0,0,0.1);
}

.mobile-content::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(to bottom, #7e22ce, #4338ca);
}

/* Mobile Search */
.mobile-search-wrapper {
    padding: 1.1rem;
    border-bottom: 1px solid #e5e7eb;
    transition: background-color 0.4s cubic-bezier(0.22, 1, 0.36, 1);
}

.mobile-search-wrapper:focus-within {
    background-color: #f9fafb;
    border-bottom-color: #9333ea;
}

.mobile-search-form {
    position: relative;
}

.mobile-search-input {
    width: 100%;
    border: 1px solid #d1d5db;
    border-radius: 0.5rem;
    padding: 0.625rem 3rem 0.625rem 1rem;
    transition: all 0.4s cubic-bezier(0.22, 1, 0.36, 1);
    background-color: rgba(255, 255, 255, 0.8);
}

.mobile-search-input:focus {
    outline: none;
    border-color: #9333ea;
    background-color: #ffffff;
    box-shadow: 0 4px 12px rgba(147, 51, 234, 0.15);
    transform: translateY(-2px);
}

.mobile-search-btn {
    position: absolute;
    right: 0;
    top: 0;
    height: 100%;
    padding: 0 1rem;
    color: #6b7280;
    transition: all 0.4s cubic-bezier(0.22, 1, 0.36, 1);
    z-index: 1;
}

.mobile-search-btn:hover {
    color: #9333ea;
    transform: rotate(-15deg) scale(1.1);
}

.mobile-search-btn:active {
    transform: rotate(0) scale(0.95);
}

.mobile-search-btn:focus {
    outline: none;
}

/* Mobile Navigation */
.mobile-nav {
    padding: 0.75rem 0;
}

.mobile-nav-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.mobile-nav-item {
    transition: background-color 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}

.mobile-nav-link {
    display: block;
    padding: 0.75rem 1.25rem;
    text-decoration: none;
    color: inherit;
    transition: color 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94), 
                padding-left 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
    position: relative;
}

.mobile-nav-link:before {
    content: '';
    position: absolute;
    bottom: 0;
    left: 1.25rem;
    width: calc(100% - 2.5rem);
    height: 2px;
    background: linear-gradient(90deg, #4f46e5, #8b5cf6);
    transform: scaleX(0);
    transform-origin: left;
    transition: transform 0.6s cubic-bezier(0.22, 1, 0.36, 1);
}

.mobile-nav-link:hover:before {
    transform: scaleX(1);
}

.mobile-nav-link:hover {
    background-color: rgba(79, 70, 229, 0.05);
    color: #4f46e5;
    padding-left: 1.75rem;
}

.mobile-nav-link:active {
    background-color: rgba(79, 70, 229, 0.1);
    color: #4f46e5;
    outline: none;
}

/* Mobile Accordion */
.mobile-accordion-header {
    display: flex;
    align-items: center;
    transition: background-color 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}

.mobile-accordion-link {
    flex: 1;
    padding: 0.75rem 1.25rem;
    text-decoration: none;
    color: inherit;
    transition: color 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94), 
                padding-left 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
    position: relative;
}

.mobile-accordion-link:before {
    content: '';
    position: absolute;
    bottom: 0;
    left: 1.25rem;
    width: calc(100% - 2.5rem);
    height: 2px;
    background: linear-gradient(90deg, #4f46e5, #8b5cf6);
    transform: scaleX(0);
    transform-origin: left;
    transition: transform 0.6s cubic-bezier(0.22, 1, 0.36, 1);
}

.mobile-accordion-link:hover:before {
    transform: scaleX(1);
}

.mobile-accordion-link:hover {
    background-color: rgba(79, 70, 229, 0.05);
    color: #4f46e5;
    padding-left: 1.75rem;
}

.mobile-menu-accordion-toggle {
    padding: 0.75rem 1.4rem;
    transition: background-color 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    position: relative;
    overflow: hidden;
}

.mobile-menu-accordion-toggle:before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: radial-gradient(circle, rgba(79, 70, 229, 0.2) 0%, rgba(79, 70, 229, 0) 70%);
    transform: scale(0);
    opacity: 0;
    transition: transform 0.5s cubic-bezier(0.17, 0.67, 0.83, 0.67), opacity 0.3s ease;
}

.mobile-menu-accordion-toggle:hover:before {
    background: radial-gradient(circle, rgba(79, 70, 229, 0.2) 0%, rgba(79, 70, 229, 0) 70%);
    transform: scale(1.5);
    opacity: 1;
}

.mobile-menu-accordion-toggle:hover {
    background-color: rgba(79, 70, 229, 0);
}

.mobile-menu-accordion-toggle:focus {
    outline: none;
}

.mobile-accordion-icon {
    font-size: 0.75rem;
    transition: transform 0.5s cubic-bezier(0.34, 1.56, 0.64, 1), 
                color 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    position: relative;
    z-index: 1;
}

.mobile-menu-accordion-toggle:hover .mobile-accordion-icon {
    color: #4f46e5;
}

.mobile-menu-accordion-content {
    background-color: #f5f7ff;
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.5s cubic-bezier(0.22, 1, 0.36, 1),
                opacity 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    opacity: 0;
    transform-origin: top;
}

.mobile-menu-accordion-content.hidden {
    max-height: 0;
    opacity: 0;
}

.mobile-menu-accordion-content:not(.hidden) {
    max-height: 250px;
    opacity: 1;
}

.mobile-submenu-link {
    display: block;
    padding: 0.6rem 2rem;
    text-decoration: none;
    color: inherit;
    transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    position: relative;
    overflow: hidden;
}

.mobile-submenu-link:before {
    content: '';
    position: absolute;
    bottom: 0;
    left: 2rem;
    width: calc(100% - 4rem);
    height: 1px;
    background: linear-gradient(90deg, #4f46e5, #8b5cf6);
    transform: scaleX(0);
    transform-origin: left;
    transition: transform 0.6s cubic-bezier(0.22, 1, 0.36, 1);
}

.mobile-submenu-link:after {
    content: '';
    position: absolute;
    left: 1.25rem;
    top: 50%;
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background-color: transparent;
    transform: translateY(-50%) scale(0);
    transition: transform 0.4s cubic-bezier(0.34, 1.56, 0.64, 1),
                background-color 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}

.mobile-submenu-link:hover:before {
    transform: scaleX(1);
}

.mobile-submenu-link:hover:after {
    background-color: #4f46e5;
    transform: translateY(-50%) scale(1);
}

.mobile-submenu-link:hover {
    background-color: rgba(79, 70, 229, 0.05);
    color: #4f46e5;
    padding-left: 2.5rem;
}

/* Mobile User Section */
.mobile-user-section {
    border-top: 1px solid #e5e7eb;
    padding-top: 0.3rem;
    padding-bottom: 0.75rem;
    padding-left: 1.25rem;
    padding-right: 1.25rem;
    background-color: #ffffff;
    box-shadow: 0 -4px 12px rgba(0, 0, 0, 0.05);
    transition: box-shadow 0.4s cubic-bezier(0.22, 1, 0.36, 1);
}

.mobile-user-avatar {
    display: flex;
    align-items: center;
    cursor: pointer;
    padding: 0.3rem 0.5rem;
    border-radius: 0.5rem;
    transition: background-color 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    position: relative;
    overflow: hidden;
}

.mobile-user-avatar:before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: radial-gradient(circle, rgba(147, 51, 234, 0.1) 0%, rgba(147, 51, 234, 0) 70%);
    transform: scale(0);
    opacity: 0;
    transition: transform 0.5s cubic-bezier(0.17, 0.67, 0.83, 0.67), opacity 0.3s ease;
}

.mobile-user-avatar:hover:before {
    transform: scale(2);
    opacity: 1;
    background: radial-gradient(circle, rgba(79, 70, 229, 0.1) 0%, rgba(79, 70, 229, 0) 70%);
}

.mobile-avatar-container {
    width: 2.25rem;
    height: 2.25rem;
    margin-right: 0.75rem;
    transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
    position: relative;
    overflow: hidden;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: rgba(247, 250, 252, 0.8);
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
}

.mobile-user-avatar:hover .mobile-avatar-container {
    transform: scale(1.08);
    box-shadow: 0 3px 8px rgba(79, 70, 229, 0.3);
}

.mobile-avatar-placeholder {
    width: 100%;
    height: 100%;
    border-radius: 9999px;
    background: linear-gradient(135deg, #e5e7eb, #d1d5db);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    border: 2px solid #a5b4fc;
    position: relative;
    z-index: 2;
}

.mobile-user-avatar:hover .mobile-avatar-placeholder {
    border-color: #4f46e5;
    background: linear-gradient(135deg, #e5e7eb, #c7d2fe);
}

.mobile-avatar-icon {
    font-size: 1rem;
    transition: color 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94),
                text-shadow 0.3s ease;
    background: linear-gradient(135deg, #4f46e5, #7c3aed, #9333ea);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
    background-size: 200% auto;
}

.mobile-user-avatar:hover .mobile-avatar-icon {
    text-shadow: 0 0 10px rgba(147, 51, 234, 0.5);
    background-position: right center;
}

.mobile-username {
    font-weight: 500;
    transition: color 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    position: relative;
}

.mobile-username:after {
    content: '';
    position: absolute;
    bottom: -2px;
    left: 0;
    width: 100%;
    height: 1px;
    background: linear-gradient(90deg, #4f46e5, #8b5cf6);
    transform: scaleX(0);
    transform-origin: left;
    transition: transform 0.6s cubic-bezier(0.22, 1, 0.36, 1);
}

.mobile-user-avatar:hover .mobile-username {
    color: #4f46e5;
}

.mobile-user-avatar:hover .mobile-username:after {
    transform: scaleX(1);
}

.mobile-dropdown-icon {
    margin-left: auto;
    transition: transform 0.5s cubic-bezier(0.34, 1.56, 0.64, 1),
                color 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    font-size: 0.875rem;
    background: linear-gradient(135deg, #4f46e5, #7c3aed, #9333ea);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
    background-size: 200% auto;
}

.mobile-user-avatar:hover .mobile-dropdown-icon {
    transform: rotate(180deg);
    background-position: right center;
}

.mobile-user-dropdown {
    margin-top: 0.5rem;
    background-color: #ffffff;
    border-radius: 0.5rem;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    padding: 0.5rem 0;
    opacity: 0;
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.5s cubic-bezier(0.22, 1, 0.36, 1),
                opacity 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94),
                margin 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}

.mobile-user-dropdown.hidden {
    margin-top: 0;
    max-height: 0;
    opacity: 0;
}

.mobile-user-dropdown:not(.hidden) {
    max-height: 200px;
    opacity: 1;
    margin-top: 0.5rem;
}

.mobile-dropdown-item {
    display: flex;
    align-items: center;
    padding: 0.625rem 1rem;
    text-decoration: none;
    color: inherit;
    transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    position: relative;
    overflow: hidden;
}

.mobile-dropdown-item:before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: radial-gradient(circle, rgba(79, 70, 229, 0.1) 0%, rgba(79, 70, 229, 0) 70%);
    transform: scale(0);
    opacity: 0;
    transition: transform 0.5s cubic-bezier(0.17, 0.67, 0.83, 0.67), opacity 0.3s ease;
}

.mobile-dropdown-item:hover:before {
    transform: scale(2.5);
    opacity: 1;
}

.mobile-dropdown-item:after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 1rem;
    width: calc(100% - 2rem);
    height: 1px;
    background: linear-gradient(90deg, #4f46e5, #8b5cf6);
    transform: scaleX(0);
    transform-origin: left;
    transition: transform 0.6s cubic-bezier(0.22, 1, 0.36, 1);
}

.mobile-dropdown-item:hover:after {
    transform: scaleX(1);
}

.mobile-dropdown-item:hover {
    color: #4f46e5;
    transform: translateX(5px);
}

.mobile-dropdown-icon-left {
    margin-right: 0.75rem;
    transition: transform 0.4s cubic-bezier(0.34, 1.56, 0.64, 1),
                color 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    font-size: 1rem;
    background: linear-gradient(135deg, #4f46e5, #7c3aed, #9333ea);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
    background-size: 200% auto;
}

.mobile-dropdown-item:hover .mobile-dropdown-icon-left {
    transform: scale(1.2) rotate(15deg);
    background-position: right center;
}

/* Mobile Menu Animation */
#mobile-menu {
    box-shadow: -8px 0 25px rgba(0, 0, 0, 0.15);
    transform: translateX(100%);
    transition: transform 0.5s cubic-bezier(0.16, 1, 0.3, 1);
}

#mobile-menu:not(.translate-x-full) {
    transform: translateX(0);
}


/* =================================== LOGOUT CUSTOM MODAL STYLES =================================== */
.custom-modal {
  display: none;
  position: fixed;
  z-index: 9999;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  backdrop-filter: blur(3px);
  align-items: center;
  justify-content: center;
  overflow: auto;
}
.custom-modal.show {
  display: flex;
}
.custom-modal-content {
  background-color: #ffffff;
  border-radius: 12px;
  box-shadow: 0 8px 28px rgba(60, 64, 67, 0.15);
  width: 90%;
  max-width: 420px;
  position: relative;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  animation: modalFade 0.3s ease-in-out;
  overflow: hidden;
}
@keyframes modalFade {
  from {
    opacity: 0;
    transform: translate(-50%, -60%);
  }
  to {
    opacity: 1;
    transform: translate(-50%, -50%);
  }
}
.custom-modal-header {
  padding: 24px 32px 16px;
  position: relative;
  text-align: center;
}
.custom-modal-header h4 {
  margin: 0;
  font-size: 22px;
  font-weight: 600;
  color: #202124;
}
.custom-modal-icon {
  margin-bottom: 16px;
  display: flex;
  justify-content: center;
}
.custom-modal-icon svg {
  width: 48px;
  height: 48px;
  color: #4285f4;
}
.custom-modal-body {
  padding: 0 32px 24px;
  text-align: center;
}
.custom-modal-body p {
  margin: 0;
  font-size: 16px;
  line-height: 1.5;
  color: #5f6368;
}
.custom-modal-footer {
  padding: 16px 32px 24px;
  display: flex;
  justify-content: center;
  gap: 16px;
}

/* Enhanced Button Styles with Animations */
.btn-cancel, .btn-confirm {
  padding: 12px 24px;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 500;
  font-size: 15px;
  min-width: 120px;
  text-transform: uppercase;
  letter-spacing: 0.3px;
  position: relative;
  overflow: hidden;
  transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
}

/* Button Ripple Effect */
.btn-cancel:after, .btn-confirm:after {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  width: 5px;
  height: 5px;
  background: rgba(255, 255, 255, 0.5);
  opacity: 0;
  border-radius: 100%;
  transform: scale(1, 1) translate(-50%);
  transform-origin: 50% 50%;
}

.btn-cancel:focus:not(:active)::after, .btn-confirm:focus:not(:active)::after {
  animation: ripple 1s ease-out;
}

@keyframes ripple {
  0% {
    transform: scale(0, 0);
    opacity: 0.5;
  }
  20% {
    transform: scale(25, 25);
    opacity: 0.3;
  }
  100% {
    opacity: 0;
    transform: scale(40, 40);
  }
}

/* Cancel Button */
.btn-cancel {
  background-color: transparent;
  color: #4285f4;
  border: 1px solid #dadce0;
  transition: all 0.3s ease;
}

.btn-cancel:hover {
  background-color: #f5f5f5;
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.btn-cancel:active {
  transform: translateY(1px);
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

/* Confirm Button */
.btn-confirm {
  background-color: #ea4335;
  color: white;
  transition: all 0.3s ease;
}

.btn-confirm:hover {
  background-color: #d93025;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(234, 67, 53, 0.4);
}

.btn-confirm:active {
  transform: translateY(1px);
  box-shadow: 0 2px 6px rgba(234, 67, 53, 0.4);
}

/* Button Icon Animation */
.btn-confirm svg, .btn-cancel svg {
  margin-right: 8px;
  transition: transform 0.3s ease;
}

.btn-confirm:hover svg, .btn-cancel:hover svg {
  transform: translateX(3px);
}

/* Responsive adjustments */
@media (max-width: 576px) {
  .custom-modal-content {
    width: 95%;
    max-width: 360px;
  }
  
  .custom-modal-header {
    padding: 20px 24px 12px;
  }
  
  .custom-modal-body {
    padding: 0 24px 20px;
  }
  
  .custom-modal-footer {
    padding: 16px 24px 20px;
    flex-direction: column;
  }
  
  .btn-cancel, .btn-confirm {
    width: 100%;
  }
  
  /* Animation for stacked buttons on mobile */
  .btn-cancel {
    animation: slideInLeft 0.5s ease-out;
  }
  
  .btn-confirm {
    animation: slideInRight 0.5s ease-out;
  }
  
  @keyframes slideInLeft {
    from {
      opacity: 0;
      transform: translateX(-20px);
    }
    to {
      opacity: 1;
      transform: translateX(0);
    }
  }
  
  @keyframes slideInRight {
    from {
      opacity: 0;
      transform: translateX(20px);
    }
    to {
      opacity: 1;
      transform: translateX(0);
    }
  }
}

</style>

</head>
<body class="bg-gray-50">
    <header class="ai-main-site-header">
    <nav class="desktop-navbar">
        <!-- Logo Area -->
<div class="logo-container">
    <a href="/" aria-label="Home">
        <img src="/assets/images/logo.svg" alt="AI Tools Logo" class="logo-image">
    </a>
</div>

        <!-- Desktop Navigation - centered -->
        <div class="desktop-nav-container">
            <ul class="desktop-nav-menu" role="menu">
                <li role="menuitem" class="nav-item">
            <a href="/" class="nav-link">Home</a>
        </li>
        <li role="menuitem" class="nav-item dropdown-group">
            <a href="/tools" class="nav-link nav-link-with-icon">
                Tools
                <i class="fas fa-chevron-down nav-icon"></i>
            </a>
            <ul class="dropdown-menu" role="menu">
                <li role="menuitem">
                    <a href="/tools/text-generator" class="dropdown-item">Text Generator</a>
                </li>
                <li role="menuitem">
                    <a href="/tools/image-creator" class="dropdown-item">Image Creator</a>
                </li>
                <li role="menuitem">
                    <a href="/tools/code-assistant" class="dropdown-item">Code Assistant</a>
                </li>
                <li role="menuitem">
                    <a href="/tools" class="dropdown-item">All Tools</a>
                </li>
            </ul>
        </li>
        <li role="menuitem" class="nav-item dropdown-group">
            <a href="#" class="nav-link nav-link-with-icon">
                Resources
                <i class="fas fa-chevron-down nav-icon"></i>
            </a>
            <ul class="dropdown-menu" role="menu">
                <li role="menuitem">
                    <a href="/resources/tutorials" class="dropdown-item">Tutorials</a>
                </li>
                <li role="menuitem">
                    <a href="/resources/documentation" class="dropdown-item">Documentation</a>
                </li>
                <li role="menuitem">
                    <a href="/resources/blog" class="dropdown-item">Blog</a>
                </li>
            </ul>
        </li>
        <li role="menuitem" class="nav-item">
            <a href="/page/about" class="nav-link">About</a>
        </li>
        <li role="menuitem" class="nav-item">
            <a href="/page/contact" class="nav-link">Contact</a>
        </li>
    </ul>
</div>

        <!-- Desktop Right Actions - aligned to right edge -->
    <div class="desktop-right-actions">
                        <!-- Desktop Search Toggle -->
<div class="header-search-container">
    <button id="desktop-search-toggle" class="icon-btn" aria-label="Toggle Search">
        <i class="fas fa-search text-lg"></i>
    </button>
    <!-- Desktop Search Dropdown -->
    <div id="desktop-search-dropdown" class="header-search-dropdown hidden">
        <form action="/search" method="GET" class="header-search-form">
            <input type="text" name="q" id="desktop-search-input" class="header-search-input" placeholder="Search for tools, resources, or topics...">
            <button type="submit" class="header-search-button" aria-label="Search">
                <i class="fas fa-search text-lg"></i>
            </button>
        </form>
    </div>
</div>

            <?php if ($isLoggedIn): ?>
                <!-- Notifications (desktop) -->
                <div class="notifications-container">
    <button id="desktop-notifications-toggle" class="notification-toggle-btn" aria-label="Notifications">
        <i class="fas fa-bell text-lg"></i>
        <?php if ($notificationCount > 0): ?>
            <span class="notification-badge">
                <?php echo $notificationCount > 9 ? '9+' : $notificationCount; ?>
            </span>
        <?php endif; ?>
    </button>
                    <div id="desktop-notifications-dropdown" class="notifications-dropdown hidden">
        <div class="notifications-header">
            <h3 class="notifications-title">Notifications</h3>
            <?php if ($notificationCount > 0): ?>
                <a href="/notifications/mark-all-read" class="mark-all-read">Mark all read</a>
            <?php endif; ?>
        </div>
        <div class="notifications-content">
            <?php if ($notificationCount > 0): ?>
                <!-- Dynamic notifications would be loaded here -->
                <div class="notification-item">
                    <p class="notification-text">Your report is ready to download.</p>
                    <p class="notification-time">Just now</p>
                </div>
                <div class="notification-item">
                    <p class="notification-text">New feature announcement: Try our AI Chat!</p>
                    <p class="notification-time">Yesterday</p>
                </div>
            <?php else: ?>
                <div class="notification-empty">
                    <p>No new notifications</p>
                </div>
            <?php endif; ?>
        </div>
        <div class="notifications-footer">
            <a href="/notifications" class="view-all">View all notifications</a>
                        </div>
                    </div>
                </div>

            <!-- User Avatar (desktop) -->
<div class="avatar-container">
    <div id="desktop-user-avatar" class="user-avatar cursor-pointer" aria-label="User Menu" role="button" tabindex="0">
        <div class="avatar-placeholder">
            <i class="fas fa-user"></i>
        </div>
    </div>
    <div id="desktop-user-dropdown" class="hidden" role="menu">
        <a href="/profile" class="user-dropdown-item" role="menuitem">
            <i class="fas fa-user dropdown-icon"></i> Profile
        </a>
        <a href="/settings" class="user-dropdown-item" role="menuitem">
            <i class="fas fa-cog dropdown-icon"></i> Settings
        </a>
        <a href="#" onclick="confirmLogout(); return false;" class="user-dropdown-item" role="menuitem">
            <i class="fas fa-sign-out-alt dropdown-icon"></i> Logout
        </a>
    </div>
</div>
<?php else: ?>
      <a href="/login" class="login-button">Log in</a>
<?php endif; ?>
</div>

        <!-- Mobile Menu Button -->
<div class="mobile-menu-container">
    <button id="mobile-menu-toggle" class="mobile-menu-btn" aria-label="Open Menu">
        <i class="fas fa-bars mobile-menu-icon"></i>
    </button>
</div>
</nav>

    <!-- Mobile Slide-out Menu -->
    <div id="mobile-menu" class="fixed inset-y-0 right-0 max-w-xs w-64 bg-white shadow-lg transform translate-x-full transition-transform duration-300 ease-in-out z-50 flex flex-col">
        
        <!-- Mobile Menu Header (Fixed) -->
<div class="mobile-header">
    <?php if ($isLoggedIn): ?>
        <h2 class="mobile-title">Menu</h2>
    <?php else: ?>
        <a href="/login" class="mobile-login-btn">Log in</a>
    <?php endif; ?>
    <button id="mobile-menu-close" class="mobile-close-btn" aria-label="Close Menu">
        <i class="fas fa-times mobile-close-icon"></i>
    </button>
</div>
        
        <!-- Mobile Content (Scrollable) -->
        <div class="flex-1 overflow-y-auto">
            <!-- Mobile Search Form -->
                <div class="mobile-search-wrapper">
        <form action="/search" method="GET" class="mobile-search-form">
            <input type="text" name="q" id="mobile-search-input" class="mobile-search-input" placeholder="Search...">
            <button type="submit" class="mobile-search-btn" aria-label="Search">
                <i class="fas fa-search"></i>
            </button>
        </form>
    </div>
            
               <!-- Mobile Navigation Menu -->
    <nav class="mobile-nav" role="navigation">
        <ul class="mobile-nav-list">
            <li class="mobile-nav-item">
                <a href="/" class="mobile-nav-link">Home</a>
            </li>
            <li class="mobile-nav-item">
                <div class="mobile-menu-accordion">
                    <div class="mobile-accordion-header">
                        <a href="/tools" class="mobile-accordion-link">Tools</a>
                        <button class="mobile-menu-accordion-toggle" aria-expanded="false">
                            <i class="fas fa-chevron-down mobile-accordion-icon"></i>
                        </button>
                    </div>
                    <div class="mobile-menu-accordion-content hidden">
                        <a href="/tools/text-generator" class="mobile-submenu-link">Text Generator</a>
                        <a href="/tools/image-creator" class="mobile-submenu-link">Image Creator</a>
                        <a href="/tools/code-assistant" class="mobile-submenu-link">Code Assistant</a>
                        <a href="/tools" class="mobile-submenu-link">All Tools</a>
                    </div>
                </div>
            </li>
            <li class="mobile-nav-item">
                <div class="mobile-menu-accordion">
                    <div class="mobile-accordion-header">
                        <a href="/resources" class="mobile-accordion-link">Resources</a>
                        <button class="mobile-menu-accordion-toggle" aria-expanded="false">
                            <i class="fas fa-chevron-down mobile-accordion-icon"></i>
                        </button>
                    </div>
                    <div class="mobile-menu-accordion-content hidden">
                        <a href="/resources/tutorials" class="mobile-submenu-link">Tutorials</a>
                        <a href="/resources/documentation" class="mobile-submenu-link">Documentation</a>
                        <a href="/resources/blog" class="mobile-submenu-link">Blog</a>
                    </div>
                </div>
            </li>
            <li class="mobile-nav-item">
                <a href="/page/about" class="mobile-nav-link">About</a>
            </li>
            <li class="mobile-nav-item">
                <a href="/page/contact" class="mobile-nav-link">Contact</a>
            </li>
        </ul>
    </nav>
</div>
        
        <!-- Mobile User Section - Sticky at bottom -->
<div class="mobile-user-section">
    <?php if ($isLoggedIn): ?>
        <div class="mobile-user-menu">
            <div id="mobile-user-avatar" class="mobile-user-avatar">
                <div class="user-avatar mobile-avatar-container">
                    <!-- Default user icon placeholder -->
                    <div class="mobile-avatar-placeholder">
                        <i class="fas fa-user mobile-avatar-icon"></i>
                    </div>
                </div>
                <span class="mobile-username">
                    <?php echo !empty($userName) ? htmlspecialchars($userName) : 'My Account'; ?>
                </span>
                <i class="fas fa-chevron-down mobile-dropdown-icon"></i>
            </div>
            
            <div id="mobile-user-dropdown" class="mobile-user-dropdown hidden">
                <a href="/profile" class="mobile-dropdown-item">
                    <i class="fas fa-user mobile-dropdown-icon-left"></i> Profile
                </a>
                <a href="/settings" class="mobile-dropdown-item">
                    <i class="fas fa-cog mobile-dropdown-icon-left"></i> Settings
                </a>
                <a href="#" onclick="confirmLogout(); return false;" class="mobile-dropdown-item">
                    <i class="fas fa-sign-out-alt mobile-dropdown-icon-left"></i> Logout
                </a>
            </div>
        </div>
    <?php endif; ?>
</div>
    </div>

    <!-- Overlay for Mobile Menu -->
    <div id="mobile-menu-overlay" class="fixed inset-0 bg-black opacity-0 invisible transition-all duration-300 z-40"></div>
</header>

<!-- Add padding to body to prevent content from being hidden behind sticky header -->
<div class="pt-14">
    <?php
    // Include messages system
    if (file_exists($_SERVER['DOCUMENT_ROOT'] . '/private/messages.php')) {
        require_once($_SERVER['DOCUMENT_ROOT'] . '/private/messages.php');
        if (function_exists('get_messages_html')) {
            echo get_messages_html();
        }
    }
    ?>
    <!-- Page content will be inserted here -->
</div>

<!-- Custom Logout Confirmation Modal -->
<div id="logoutConfirmModal" class="custom-modal">
  <div class="custom-modal-content">
    <div class="custom-modal-header">
      <div class="custom-modal-icon">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
          <polyline points="16 17 21 12 16 7"></polyline>
          <line x1="21" y1="12" x2="9" y2="12"></line>
        </svg>
      </div>
      <h4>Log Out</h4>
    </div>
    
    <div class="custom-modal-body">
      <p>Are you sure you want to log out of your account? You'll need to login again to access your personalized settings.</p>
    </div>
    
    <div class="custom-modal-footer">
      <button id="cancelLogoutBtn" class="btn-cancel">Cancel</button>
      <button id="confirmLogoutBtn" class="btn-confirm">Log Out</button>
    </div>
  </div>
</div>
    <script>
/**
 * Modern Header JavaScript
 * Handles responsive navigation, dropdowns, search toggle and more
 */
document.addEventListener('DOMContentLoaded', function() {
    'use strict';
    
    // --- UTILITY FUNCTIONS ---
    
    // Helper for easy event listening
    function addEvent(element, event, handler) {
        if (element) {
            element.addEventListener(event, handler);
        }
    }
    
    // Toggle element visibility
    function toggleElement(element, show) {
        if (!element) return;
        
        if (show === undefined) {
            // Toggle current state
            if (element.classList.contains('hidden')) {
                element.classList.remove('hidden');
            } else {
                element.classList.add('hidden');
            }
        } else if (show) {
            // Show explicitly
            element.classList.remove('hidden');
        } else {
            // Hide explicitly
            element.classList.add('hidden');
        }
    }
    
    // --- DESKTOP DROPDOWN HOVER FUNCTIONALITY ---
    
    // Function to handle desktop navigation dropdowns
    function setupDesktopNavHovers() {
        // Get all dropdown parent items
        const dropdownItems = document.querySelectorAll('.md\\:flex li.group');
        
        dropdownItems.forEach(function(item) {
            const dropdown = item.querySelector('ul');
            if (!dropdown) return;
            
            // Make sure dropdown isn't hidden by JS
            if (dropdown.classList.contains('hidden')) {
                dropdown.classList.remove('hidden');
            }
            
            // Ensure visibility classes are properly set
            if (!dropdown.classList.contains('invisible')) {
                dropdown.classList.add('invisible');
            }
        });
    }
    
    // Initialize desktop hover dropdowns
    setupDesktopNavHovers();
    
    // --- ELEMENTS ---
    
    // Mobile menu elements
    const mobileMenuToggle = document.getElementById('mobile-menu-toggle');
    const mobileMenuClose = document.getElementById('mobile-menu-close');
    const mobileMenu = document.getElementById('mobile-menu');
    const mobileMenuOverlay = document.getElementById('mobile-menu-overlay');
    const mobileAccordionToggles = document.querySelectorAll('.mobile-menu-accordion-toggle');
    const navDropdownGroups = document.querySelectorAll('.dropdown-group');
    
    // Search elements
    const desktopSearchToggle = document.getElementById('desktop-search-toggle');
    const desktopSearchDropdown = document.getElementById('desktop-search-dropdown');
    const desktopSearchInput = document.getElementById('desktop-search-input');
    const mobileSearchToggle = document.getElementById('mobile-search-toggle');
    const mobileSearchInput = document.getElementById('mobile-search-input');
    
    // User dropdown elements
    const desktopUserAvatar = document.getElementById('desktop-user-avatar');
    const desktopUserDropdown = document.getElementById('desktop-user-dropdown');
    const mobileUserAvatar = document.getElementById('mobile-user-avatar');
    const mobileUserDropdown = document.getElementById('mobile-user-dropdown');
    
    // Notifications dropdown
    const desktopNotificationsToggle = document.getElementById('desktop-notifications-toggle');
    const desktopNotificationsDropdown = document.getElementById('desktop-notifications-dropdown');


// --- NAVIGATION DROPDOWNS ---

// Add event listeners to close right-side elements when nav dropdowns are interacted with
navDropdownGroups.forEach(function(dropdownGroup) {
    // Add event listener for mouse enter
    dropdownGroup.addEventListener('mouseenter', function() {
        // Close desktop user dropdown if open
        if (desktopUserDropdown && !desktopUserDropdown.classList.contains('hidden')) {
            toggleElement(desktopUserDropdown, false);
        }
        
        // Close notifications dropdown if open
        if (desktopNotificationsDropdown && !desktopNotificationsDropdown.classList.contains('hidden')) {
            toggleElement(desktopNotificationsDropdown, false);
        }
        
        // Close search dropdown if open
        if (desktopSearchDropdown && !desktopSearchDropdown.classList.contains('hidden')) {
            toggleElement(desktopSearchDropdown, false);
        }
    });
});

    // --- MOBILE MENU FUNCTIONALITY ---
    
    // Open mobile menu
    if (mobileMenuToggle) {
        addEvent(mobileMenuToggle, 'click', function() {
            mobileMenu.classList.remove('translate-x-full');
            mobileMenuOverlay.classList.remove('invisible');
            mobileMenuOverlay.style.opacity = '0.5';
            document.body.classList.add('overflow-hidden'); // Prevent body scrolling
        });
    }
    
    // Close mobile menu
function closeMobileMenu() {
    if (mobileMenu) {
        mobileMenu.classList.add('translate-x-full');
        mobileMenuOverlay.classList.add('invisible');
        mobileMenuOverlay.style.opacity = '0';
        document.body.classList.remove('overflow-hidden'); // Re-enable body scrolling
        
        // NEW CODE: Close all accordion dropdowns
        document.querySelectorAll('.mobile-menu-accordion-content').forEach(function(content) {
            content.classList.add('hidden');
        });
        
        // Reset all accordion icons to default state
        document.querySelectorAll('.mobile-menu-accordion-toggle .mobile-accordion-icon').forEach(function(icon) {
            icon.style.transform = 'rotate(0)';
        });
        
        // Update all aria-expanded attributes
        document.querySelectorAll('.mobile-menu-accordion-toggle').forEach(function(toggle) {
            toggle.setAttribute('aria-expanded', 'false');
        });
        
        // Close mobile user dropdown if open
        if (mobileUserDropdown && !mobileUserDropdown.classList.contains('hidden')) {
            mobileUserDropdown.classList.add('hidden');
            
            // Reset user dropdown icon
            const userDropdownIcon = document.querySelector('.mobile-user-avatar .mobile-dropdown-icon');
            if (userDropdownIcon) {
                userDropdownIcon.style.transform = 'rotate(0)';
            }
        }
    }
}
    
    if (mobileMenuClose) {
        addEvent(mobileMenuClose, 'click', closeMobileMenu);
    }
    
    if (mobileMenuOverlay) {
        addEvent(mobileMenuOverlay, 'click', closeMobileMenu);
    }
    
    // Handle accordion toggles in mobile menu
document.querySelectorAll('.mobile-menu-accordion-toggle').forEach(function(toggle) {
    addEvent(toggle, 'click', function(e) {
        e.stopPropagation(); // Prevent event bubbling
        
        // Find the closest parent accordion container
        const accordionContainer = toggle.closest('.mobile-menu-accordion');
        
        // Get the content div that follows
        const content = accordionContainer.querySelector('.mobile-menu-accordion-content');
        const icon = toggle.querySelector('.fa-chevron-down');
        
        // Toggle the content visibility
        toggleElement(content);
        
        // Update aria-expanded attribute
        const expanded = toggle.getAttribute('aria-expanded') === 'true';
        toggle.setAttribute('aria-expanded', !expanded);
        
        // Rotate the chevron icon
        if (icon) {
            if (content.classList.contains('hidden')) {
                icon.style.transform = 'rotate(0)';
            } else {
                icon.style.transform = 'rotate(180deg)';
            }
        }
    });
});
    
    // --- SEARCH FUNCTIONALITY ---
    
    // Toggle desktop search
if (desktopSearchToggle) {
    addEvent(desktopSearchToggle, 'click', function(e) {
        e.stopPropagation();
        
        // Get search dropdown
        const desktopSearchDropdown = document.getElementById('desktop-search-dropdown');
        
        // Toggle search dropdown visibility
        toggleElement(desktopSearchDropdown);
        
        // Close notifications dropdown if open
        if (desktopNotificationsDropdown && !desktopNotificationsDropdown.classList.contains('hidden')) {
            toggleElement(desktopNotificationsDropdown, false);
        }
        
        // Close user dropdown if open
        if (desktopUserDropdown && !desktopUserDropdown.classList.contains('hidden')) {
            toggleElement(desktopUserDropdown, false);
        }
        
        // Focus the search input when opened
        if (desktopSearchDropdown && !desktopSearchDropdown.classList.contains('hidden')) {
            document.getElementById('desktop-search-input').focus();
        }
    });
}
    
    // Prevent search from closing when clicking inside it
    if (desktopSearchDropdown) {
    addEvent(desktopSearchDropdown, 'click', function(e) {
        e.stopPropagation();
    });
}
    
    // Toggle mobile search
    if (mobileSearchToggle) {
        addEvent(mobileSearchToggle, 'click', function() {
            // Open mobile menu if not already open
            if (mobileMenu.classList.contains('translate-x-full')) {
                mobileMenuToggle.click();
            }
            
            // Focus the mobile search input
            if (mobileSearchInput) {
                setTimeout(() => mobileSearchInput.focus(), 400);
            }
        });
    }
    
    // --- USER DROPDOWNS ---
    
    // Toggle desktop user dropdown
    if (desktopUserAvatar && desktopUserDropdown) {
    addEvent(desktopUserAvatar, 'click', function(e) {
        e.stopPropagation();
        toggleElement(desktopUserDropdown);
        
        // Close notifications if open
        if (desktopNotificationsDropdown && !desktopNotificationsDropdown.classList.contains('hidden')) {
            toggleElement(desktopNotificationsDropdown, false);
        }
        
        // Close search if open
        if (desktopSearchDropdown && !desktopSearchDropdown.classList.contains('hidden')) {
            toggleElement(desktopSearchDropdown, false);
        }
    });
    
    // Support keyboard navigation
    addEvent(desktopUserAvatar, 'keydown', function(e) {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            desktopUserAvatar.click();
        }
    });
}
    
    // Toggle mobile user dropdown
    if (mobileUserAvatar && mobileUserDropdown) {
        addEvent(mobileUserAvatar, 'click', function(e) {
            e.stopPropagation();
            toggleElement(mobileUserDropdown);
            
            // Toggle chevron icon
            const icon = mobileUserAvatar.querySelector('.mobile-dropdown-icon');
            if (icon) {
                if (mobileUserDropdown.classList.contains('hidden')) {
                    icon.style.transform = 'rotate(0)';
                } else {
                    icon.style.transform = 'rotate(180deg)';
                }
            }
        });
    }
    
    // --- NOTIFICATIONS DROPDOWN ---
    
    // Toggle notifications dropdown
    if (desktopNotificationsToggle && desktopNotificationsDropdown) {
    addEvent(desktopNotificationsToggle, 'click', function(e) {
        e.stopPropagation();
        toggleElement(desktopNotificationsDropdown);
        
        // Close user dropdown if open
        if (desktopUserDropdown && !desktopUserDropdown.classList.contains('hidden')) {
            toggleElement(desktopUserDropdown, false);
        }
        
        // Close search if open
        if (desktopSearchDropdown && !desktopSearchDropdown.classList.contains('hidden')) {
            toggleElement(desktopSearchDropdown, false);
        }
    });
}

    // --- DOCUMENT-WIDE EVENT HANDLERS ---
    
    // Close dropdowns when clicking outside
    document.addEventListener('click', function() {
        // Close desktop user dropdown
        if (desktopUserDropdown && !desktopUserDropdown.classList.contains('hidden')) {
            toggleElement(desktopUserDropdown, false);
        }
        
        // Close notifications dropdown
        if (desktopNotificationsDropdown && !desktopNotificationsDropdown.classList.contains('hidden')) {
            toggleElement(desktopNotificationsDropdown, false);
        }
        
        // Close desktop search dropdown
     if (desktopSearchDropdown && !desktopSearchDropdown.classList.contains('hidden')) {
        toggleElement(desktopSearchDropdown, false);
    }
});
    
    // Prevent closing when clicking inside dropdowns
    if (desktopUserDropdown) {
        addEvent(desktopUserDropdown, 'click', function(e) {
            e.stopPropagation();
        });
    }
    
    if (desktopNotificationsDropdown) {
        addEvent(desktopNotificationsDropdown, 'click', function(e) {
            e.stopPropagation();
        });
    }

    if (desktopSearchDropdown) {
    addEvent(desktopSearchDropdown, 'click', function(e) {
        e.stopPropagation();
    });
}
    
    // Handle keyboard events for accessibility
    document.addEventListener('keydown', function(e) {
        // Close everything when pressing Escape
        if (e.key === 'Escape') {
            // Close mobile menu
            closeMobileMenu();
            
            // Close desktop search
            if (desktopSearchDropdown && !desktopSearchDropdown.classList.contains('hidden')) {
    toggleElement(desktopSearchDropdown, false);
}
            
            // Close user dropdown
            if (desktopUserDropdown && !desktopUserDropdown.classList.contains('hidden')) {
                toggleElement(desktopUserDropdown, false);
            }
            
            // Close notifications dropdown
            if (desktopNotificationsDropdown && !desktopNotificationsDropdown.classList.contains('hidden')) {
                toggleElement(desktopNotificationsDropdown, false);
            }
            
            // Close logout modal
            hideLogoutModal();
        }
    });
    
    // --- FOCUS MANAGEMENT ---
    
    // For dropdown menus, implement a focus trap
    function setupFocusTrap(container, firstElement, lastElement) {
        if (!container || !firstElement || !lastElement) return;
        
        addEvent(lastElement, 'keydown', function(e) {
            if (e.key === 'Tab' && !e.shiftKey) {
                e.preventDefault();
                firstElement.focus();
            }
        });
        
        addEvent(firstElement, 'keydown', function(e) {
            if (e.key === 'Tab' && e.shiftKey) {
                e.preventDefault();
                lastElement.focus();
            }
        });
    }
    
    // Set up focus traps for dropdowns when they become visible
    function setupAccessibility() {
        // User dropdown focus trap
        if (desktopUserDropdown && !desktopUserDropdown.classList.contains('hidden')) {
            const menuItems = desktopUserDropdown.querySelectorAll('a[role="menuitem"]');
            if (menuItems.length > 0) {
                const firstItem = menuItems[0];
                const lastItem = menuItems[menuItems.length - 1];
                
                // Focus on first item when dropdown opens
                firstItem.focus();
                
                // Setup the focus trap
                setupFocusTrap(desktopUserDropdown, firstItem, lastItem);
            }
        }
        
        // Notifications dropdown focus trap
        if (desktopNotificationsDropdown && !desktopNotificationsDropdown.classList.contains('hidden')) {
            const firstFocusable = desktopNotificationsDropdown.querySelector('a, button');
            const focusables = desktopNotificationsDropdown.querySelectorAll('a, button');
            const lastFocusable = focusables[focusables.length - 1];
            
            if (firstFocusable && lastFocusable) {
                // Focus on first item when dropdown opens
                firstFocusable.focus();
                
                // Setup the focus trap
                setupFocusTrap(desktopNotificationsDropdown, firstFocusable, lastFocusable);
            }
        }
        
        // Logout modal focus trap
        if (logoutConfirmationModal && !logoutConfirmationModal.classList.contains('hidden')) {
            const focusables = logoutConfirmationModal.querySelectorAll('button, [tabindex]:not([tabindex="-1"])');
            if (focusables.length > 0) {
                const firstFocusable = focusables[0];
                const lastFocusable = focusables[focusables.length - 1];
                
                // Focus on first item when modal opens
                firstFocusable.focus();
                
                // Setup the focus trap
                setupFocusTrap(logoutConfirmationModal, firstFocusable, lastFocusable);
            }
        }
    }
    
    // Watch for visibility changes to set up accessibility
    // This is a simple mutation observer pattern
    const observeVisibility = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                setupAccessibility();
            }
        });
    });
    
    // Observe elements that can change visibility
    [desktopUserDropdown, desktopNotificationsDropdown, logoutConfirmationModal].forEach(function(element) {
        if (element) {
            observeVisibility.observe(element, { attributes: true });
        }
    });
    
    // --- WINDOW RESIZE HANDLING ---
    
    // Handle window resize events
    let resizeTimer;
    window.addEventListener('resize', function() {
        // Debounce resize events
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(function() {
            // Close mobile menu on large screens
            const windowWidth = window.innerWidth;
            if (windowWidth >= 768 && mobileMenu && !mobileMenu.classList.contains('translate-x-full')) {
                closeMobileMenu();
            }
            
            // Close desktop search on small screens
            if (windowWidth < 768 && desktopSearchContainer && !desktopSearchContainer.classList.contains('hidden')) {
                toggleElement(desktopSearchContainer, false);
            }
        }, 250);
    });
    
    // Initialize any components that need setup on page load
    setupAccessibility();
});

// Function to show the custom logout confirmation modal
function confirmLogout() {
    document.getElementById('logoutConfirmModal').style.display = 'block';
    document.body.classList.add('overflow-hidden'); // Prevent body scrolling
}

// Add event listeners for the logout modal
document.addEventListener('DOMContentLoaded', function() {
    // Confirm button event
    const confirmLogoutBtn = document.getElementById('confirmLogoutBtn');
    if (confirmLogoutBtn) {
        confirmLogoutBtn.addEventListener('click', function() {
            window.location.href = '/logout.php?confirm=1';
        });
    }
    
    // Cancel button event
    const cancelLogoutBtn = document.getElementById('cancelLogoutBtn');
    if (cancelLogoutBtn) {
        cancelLogoutBtn.addEventListener('click', function() {
            document.getElementById('logoutConfirmModal').style.display = 'none';
            document.body.classList.remove('overflow-hidden'); // Re-enable body scrolling
        });
    }
    
    // Close modal if user clicks outside of it
    window.addEventListener('click', function(event) {
        const modal = document.getElementById('logoutConfirmModal');
        if (event.target == modal) {
            modal.style.display = 'none';
            document.body.classList.remove('overflow-hidden'); // Re-enable body scrolling
        }
    });
});
</script>
</body>
</html>
<?php
// Log access to this file for security monitoring
if (function_exists('error_log')) {
    error_log('Header file accessed at ' . date('Y-m-d H:i:s') . ' from IP: ' . $_SERVER['REMOTE_ADDR']);
}
?>