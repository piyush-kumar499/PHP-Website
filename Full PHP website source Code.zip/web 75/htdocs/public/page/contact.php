<?php
/**
 * Contact Form Page
 */
require_once __DIR__ . '/../../private/config.php';
require_once __DIR__ . '/../../private/db.php';
require_once __DIR__ . '/../../private/contact_handler.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in and get user email
$userLoggedIn = false;
$userEmail = '';

// Check if user is logged in using session data
if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];
    
    // Fetch user details from database
    $user = dbSelectOne("SELECT email FROM users WHERE id = ? AND status = 'active'", [$userId]);
    
    if ($user && isset($user['email'])) {
        $userLoggedIn = true;
        $userEmail = $user['email'];
    }
}

// Initialize variables
$errors = [];
$success = false;
$formData = [
    'name' => '',
    'email' => $userLoggedIn ? $userEmail : '', // Pre-fill email if user is logged in
    'subject' => '',
    'message' => ''
];

// Check for success flag in URL (for redirected success messages)
if (isset($_GET['success']) && $_GET['success'] == 1) {
    $success = true;
    // Reset form data when showing success message
    $formData = [
        'name' => '',
        'email' => '',
        'subject' => '',
        'message' => ''
    ];
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate form data
    $formData = [
        'name' => trim($_POST['name'] ?? ''),
        'email' => trim($_POST['email'] ?? ''),
        'subject' => trim($_POST['subject'] ?? ''),
        'message' => trim($_POST['message'] ?? '')
    ];
    
    // Perform validation
    if (empty($formData['name'])) {
        $errors['name'] = 'Name is required';
    }
    
    if (empty($formData['email'])) {
        $errors['email'] = 'Email is required';
    } elseif (!filter_var($formData['email'], FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Please enter a valid email address';
    }
    
    if (empty($formData['subject'])) {
        $errors['subject'] = 'Subject is required';
    }
    
    if (empty($formData['message'])) {
        $errors['message'] = 'Message is required';
    }
    
    // If no errors, process the form
    if (empty($errors)) {
        // Store contact submission in database
        $submissionId = storeContactSubmission(
            $formData['name'],
            $formData['email'],
            $formData['subject'],
            $formData['message']
        );
        
        if ($submissionId) {
            // Send emails
            $adminEmailSent = sendContactEmailToAdmin($formData);
            $userEmailSent = sendThankYouEmail($formData);
            
            if ($adminEmailSent && $userEmailSent) {
                // Redirect to the same page with a success parameter to prevent form resubmission
                header('Location: ' . $_SERVER['PHP_SELF'] . '?success=1');
                exit;
            } else {
                $errors['general'] = 'There was a problem sending your message. Please try again later.';
            }
        } else {
            $errors['general'] = 'There was a problem submitting your message. Please try again later.';
        }
    }
}

include '../header.php'
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include_once ('../../private/favicon.php'); ?>
    <title>Contact Us | AI Tools Platform</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/assets/css/contact.css">
    <style>
        /* CSS for fading messages */
    .fade-out {
        animation: fadeOut 1s forwards;
    }
    
    @keyframes fadeOut {
        0% { opacity: 1; max-height: 200px; margin-bottom: 15px; padding: 15px; }
        70% { opacity: 0; max-height: 200px; margin-bottom: 15px; padding: 15px; }
        100% { opacity: 0; max-height: 0; margin-bottom: 0; padding: 0; visibility: hidden; }
    }
    </style>
</head>
<body>
<!-- Main Container for the entire page -->
<main id="contact-page" class="contact-pg-page-wrapper">
    <div class="contact-pg-container">
        <div class="contact-pg-row">
            <div class="contact-pg-col-main">
                
    <!-- Contact Form Main Title -->
    <section class="contact-pg-main-title">
    <div class="contact-pg-header-title">
    <div class="contact-pg-card-header">
    <h1 class="contact-pg-heading">Contact Us</h1>
</div>
<p class="contact-pg-intro-text">Have questions or feedback? We'd love to hear from you! Fill out the form below and our team will get back to you as soon as possible.</p>
</div>
</section>

                <!-- Contact Form Section -->
                <section class="contact-pg-contact-form-section">
                    <div class="contact-pg-card">
                        <div class="contact-pg-card-body">
                            <!-- Display success message above the form instead of replacing it -->
                            <?php if ($success): ?>
                                <div id="success-message" class="contact-pg-alert contact-pg-success">
                                    <h4>Thank you for contacting us!</h4>
                                    <p>Your message has been sent successfully. We will get back to you as soon as possible.</p>
                                    <p>A confirmation email has been sent to your email address.</p>
                                </div>
                            <?php endif; ?>
                            
                            <?php if (isset($errors['general'])): ?>
                                <div id="error-message" class="contact-pg-alert contact-pg-error"><?php echo $errors['general']; ?></div>
                            <?php endif; ?>
                            
                            <form action="" method="POST" novalidate>
                                <div class="contact-pg-form-group">
                                    <label for="name" class="contact-pg-form-label">Your Name *</label>
                                    <input type="text" class="contact-pg-form-input <?php echo isset($errors['name']) ? 'contact-pg-input-error' : ''; ?>" 
                                           id="name" name="name" value="<?php echo htmlspecialchars($formData['name']); ?>" required>
                                    <?php if (isset($errors['name'])): ?>
                                        <div class="contact-pg-error-message field-error"><?php echo $errors['name']; ?></div>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="contact-pg-form-group">
    <label for="email" class="contact-pg-form-label">Email Address *</label>
    <?php if ($userLoggedIn): ?>
        <!-- For logged-in users: Show disabled field + hidden input -->
        <input type="email" class="contact-pg-form-input" 
               id="email" value="<?php echo htmlspecialchars($userEmail); ?>" 
               disabled readonly>
        <!-- Hidden input to ensure the email is submitted with the form -->
        <input type="hidden" name="email" value="<?php echo htmlspecialchars($userEmail); ?>">
    <?php else: ?>
        <!-- For non-logged-in users: Show normal editable field -->
        <input type="email" class="contact-pg-form-input <?php echo isset($errors['email']) ? 'contact-pg-input-error' : ''; ?>" 
               id="email" name="email" value="<?php echo htmlspecialchars($formData['email']); ?>" required>
    <?php endif; ?>
    
    <?php if (isset($errors['email'])): ?>
        <div class="contact-pg-error-message field-error"><?php echo $errors['email']; ?></div>
    <?php endif; ?>
</div>
                                
                                <div class="contact-pg-form-group">
                                    <label for="subject" class="contact-pg-form-label">Subject *</label>
                                    <input type="text" class="contact-pg-form-input <?php echo isset($errors['subject']) ? 'contact-pg-input-error' : ''; ?>" 
                                           id="subject" name="subject" value="<?php echo htmlspecialchars($formData['subject']); ?>" required>
                                    <?php if (isset($errors['subject'])): ?>
                                        <div class="contact-pg-error-message field-error"><?php echo $errors['subject']; ?></div>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="contact-pg-form-group">
                                    <label for="message" class="contact-pg-form-label">Message *</label>
                                    <textarea class="contact-pg-form-textarea <?php echo isset($errors['message']) ? 'contact-pg-input-error' : ''; ?>" 
                                              id="message" name="message" rows="5" required><?php echo htmlspecialchars($formData['message']); ?></textarea>
                                    <?php if (isset($errors['message'])): ?>
                                        <div class="contact-pg-error-message field-error"><?php echo $errors['message']; ?></div>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="contact-pg-form-submit">
                                    <button type="submit" class="contact-pg-btn contact-pg-btn-submit">Send Message</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </section>
                
                <!-- Contact Information Section -->
                <section class="contact-pg-contact-info-section">
                    <div class="contact-pg-card contact-pg-contact-info">
                        <div class="contact-pg-card-body">
                            <h2 class="contact-pg-heading-secondary">Other Ways to Reach Us</h2>
                            
                            <div class="contact-pg-contact-methods">
                                <div class="contact-pg-contact-method">
                                    <div class="contact-pg-method-content">
                                        <i class="fas fa-envelope contact-pg-icon"></i>
                                        <div class="contact-pg-method-details">
                                            <h3 class="contact-pg-method-title">Email</h3>
                                            <p><?php echo htmlspecialchars($CONFIG['support_email']); ?></p>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="contact-pg-contact-method">
                                    <div class="contact-pg-method-content">
                                        <i class="fas fa-map-marker-alt contact-pg-icon"></i>
                                        <div class="contact-pg-method-details">
                                            <h3 class="contact-pg-method-title">Address</h3>
                                            <p><?php echo htmlspecialchars($CONFIG['company_address']); ?></p>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="contact-pg-contact-method">
                                    <div class="contact-pg-method-content">
                                        <i class="fas fa-clock contact-pg-icon"></i>
                                        <div class="contact-pg-method-details">
                                            <h3 class="contact-pg-method-title">Support Hours</h3>
                                            <p>Monday-Friday: 9am-5pm</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                
                <!-- Map Section -->
                <section class="contact-pg-map-section">
                    <div class="contact-pg-card contact-pg-map-container">
                        <div class="contact-pg-card-body contact-pg-map-body">
                            <div class="contact-pg-map-frame">
                                <!-- Replace with your Google Maps API key and location -->
                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153.1080095918773!2d-122.40259682367793!3d37.78891291202252!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8085807ded297e89%3A0xcfd1b2f6bcbdbdff!2sSan%20Francisco%2C%20CA%2094105!5e0!3m2!1sen!2sus!4v1710947546049!5m2!1sen!2sus" allowfullscreen="" loading="lazy"></iframe>
                            </div>
                        </div>
                    </div>
                </section>
                
                <!-- Features Section -->
                <section class="contact-pg-features-section">
                    <div class="contact-pg-card contact-pg-features-section">
                        <div class="contact-pg-card-header">
                            <h2 class="contact-pg-heading-secondary">Why Choose Our AI Tools</h2>
                        </div>
                        <div class="contact-pg-card-body">
                            <p class="contact-pg-features-intro">Our AI-powered platform is designed to streamline your workflow and boost productivity with cutting-edge technology and intuitive features.</p>
                            
                            <div class="contact-pg-features-grid">
                                <div class="contact-pg-feature-item">
                                    <div class="contact-pg-feature-card">
                                        <div class="contact-pg-feature-body">
                                            <div class="contact-pg-feature-icon">
                                                <i class="fas fa-robot contact-pg-icon-large"></i>
                                            </div>
                                            <h3 class="contact-pg-feature-title">Advanced AI Models</h3>
                                            <p class="contact-pg-feature-text">Access state-of-the-art AI models trained on diverse datasets for superior performance.</p>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="contact-pg-feature-item">
                                    <div class="contact-pg-feature-card">
                                        <div class="contact-pg-feature-body">
                                            <div class="contact-pg-feature-icon">
                                                <i class="fas fa-bolt contact-pg-icon-large"></i>
                                            </div>
                                            <h3 class="contact-pg-feature-title">Real-time Processing</h3>
                                            <p class="contact-pg-feature-text">Experience lightning-fast processing speeds for immediate results and feedback.</p>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="contact-pg-feature-item">
                                    <div class="contact-pg-feature-card">
                                        <div class="contact-pg-feature-body">
                                            <div class="contact-pg-feature-icon">
                                                <i class="fas fa-lock contact-pg-icon-large"></i>
                                            </div>
                                            <h3 class="contact-pg-feature-title">Enterprise Security</h3>
                                            <p class="contact-pg-feature-text">Your data is protected with end-to-end encryption and strict privacy controls.</p>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="contact-pg-feature-item">
                                    <div class="contact-pg-feature-card">
                                        <div class="contact-pg-feature-body">
                                            <div class="contact-pg-feature-icon">
                                                <i class="fas fa-headset contact-pg-icon-large"></i>
                                            </div>
                                            <h3 class="contact-pg-feature-title">24/7 Support</h3>
                                            <p class="contact-pg-feature-text">Our expert team is always available to help with any questions or issues.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
</main>

<!-- JavaScript for auto-dismissing messages -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Function to handle message fade out
        function fadeOutMessages() {
            // For success messages
            const successMessage = document.getElementById('success-message');
            if (successMessage) {
                // Fade out after 5 seconds (5000ms)
                setTimeout(function() {
                    successMessage.classList.add('fade-out');
                }, 5000);
            }
            
            // For general error messages
            const errorMessage = document.getElementById('error-message');
            if (errorMessage) {
                setTimeout(function() {
                    errorMessage.classList.add('fade-out');
                }, 5000);
            }
            
            // For field-specific error messages
            const fieldErrors = document.querySelectorAll('.field-error');
            if (fieldErrors.length > 0) {
                setTimeout(function() {
                    fieldErrors.forEach(function(error) {
                        error.classList.add('fade-out');
                    });
                }, 5000);
            }
        }
        
        // Make messages disappear on page reload
        if (window.performance && window.performance.navigation.type === window.performance.navigation.TYPE_RELOAD) {
            // Hide all messages immediately on page reload
            const allMessages = document.querySelectorAll('.contact-pg-alert, .contact-pg-error-message');
            allMessages.forEach(function(message) {
                message.style.display = 'none';
                message.style.maxHeight = '0';
                message.style.margin = '0';
                message.style.padding = '0';
                message.style.overflow = 'hidden';
            });
        } else {
            // For normal page load/navigation, fade out after delay
            fadeOutMessages();
        }
    });
</script>
</body>
</html>