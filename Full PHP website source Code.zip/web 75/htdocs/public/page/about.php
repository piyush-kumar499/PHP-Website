<?php
// Set page variables
$pageTitle = "About Us | AI Tools Platform";
$currentYear = date('Y');
$companyFoundedYear = 2020;
$yearsInBusiness = $currentYear - $companyFoundedYear;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include_once ('../../private/favicon.php'); ?>
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4F46E5;
            --secondary-color: #7C3AED;
            --dark-color: #1E293B;
            --light-color: #F8FAFC;
            --accent-color: #06B6D4;
            --success-color: #10B981;
            --warning-color: #F59E0B;
            --border-radius: 8px;
            --box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        }
        
        body {
            background-color: var(--light-color);
            color: var(--dark-color);
            line-height: 1.6;
        }
        
        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        header {
            margin-bottom: 3rem;
            text-align: center;
        }
        
        h1 {
            font-size: 3rem;
            margin-bottom: 0.5rem;
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-fill-color: transparent;
        }
        
        .subtitle {
            font-size: 1.2rem;
            color: #64748B;
            margin-bottom: 1.5rem;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }
        
        .about-hero {
            position: relative;
            background-color: #fff;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            overflow: hidden;
            margin-bottom: 4rem;
        }
        
        .hero-image {
            width: 100%;
            min-height: 400px;
            height: auto;
            object-fit: cover;
            background: linear-gradient(135deg, #6366F1, #A855F7);
            position: relative;
        }
        
        .hero-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(30, 41, 59, 0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            text-align: center;
            padding: 2rem;
        }
        
        .hero-title {
            color: white;
            font-size: 2.5rem;
            margin-bottom: 1rem;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }
        
        .hero-subtitle {
            color: rgba(255, 255, 255, 0.9);
            font-size: 1.25rem;
            max-width: 800px;
        }
        
        .section {
            margin-bottom: 4rem;
        }
        
        .section-title {
            font-size: 2rem;
            margin-bottom: 1.5rem;
            color: var(--dark-color);
            position: relative;
            padding-bottom: 0.5rem;
            display: inline-block;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 60%;
            height: 3px;
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            border-radius: 3px;
        }
        
        .section-content {
            background-color: #fff;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 2rem;
        }
        
        .two-column {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
        }
        
        @media (max-width: 768px) {
            .two-column {
                grid-template-columns: 1fr;
            }
            
            .container {
                padding: 1rem;
            }
            
            h1 {
                font-size: 2.2rem;
            }
            
            .hero-title {
                font-size: 2rem;
            }
            
            .section-title {
                font-size: 1.8rem;
            }
            
            .hero-image {
                height: 300px;
            }
        }
        
        .about-image {
            width: 100%;
            height: 100%;
            min-height: 300px;
            background: linear-gradient(135deg, #818CF8, #C084FC);
            border-radius: var(--border-radius);
            position: relative;
            overflow: hidden;
        }
        
        .about-text p {
            margin-bottom: 1rem;
            color: #4B5563;
        }
        
        .about-text p:last-child {
            margin-bottom: 0;
        }
        
        .highlight {
            color: var(--primary-color);
            font-weight: 600;
        }
        
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-top: 2rem;
        }
        
        .stat-card {
            background-color: #fff;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 1.5rem;
            text-align: center;
            transition: transform 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-number {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-fill-color: transparent;
        }
        
        .stat-label {
            color: #4B5563;
            font-size: 1rem;
        }
        
        .timeline {
            position: relative;
            max-width: 850px;
            margin: 2rem auto 0;
        }
        
        .timeline::after {
            content: '';
            position: absolute;
            width: 4px;
            background: linear-gradient(to bottom, var(--primary-color), var(--secondary-color));
            top: 0;
            bottom: 0;
            left: 50%;
            margin-left: -2px;
            border-radius: 4px;
        }
        
        .timeline-item {
            position: relative;
            width: 45%;
            margin-bottom: 3rem;
        }
        
        .timeline-item:nth-child(odd) {
            left: 0;
        }
        
        .timeline-item:nth-child(even) {
            left: 55%;
        }
        
        .timeline-item::after {
            content: '';
            position: absolute;
            top: 18px;
            width: 20px;
            height: 20px;
            background-color: white;
            border: 4px solid var(--primary-color);
            border-radius: 50%;
            z-index: 1;
        }
        
        .timeline-item:nth-child(odd)::after {
            right: -12px;
        }
        
        .timeline-item:nth-child(even)::after {
            left: -12px;
        }
        
        .timeline-content {
            padding: 1.5rem;
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
        }
        
        .timeline-date {
            color: white;
            font-weight: bold;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            padding: 0.5rem 1rem;
            border-radius: 20px;
            display: inline-block;
            margin-bottom: 0.75rem;
        }
        
        .timeline-title {
            margin-bottom: 0.5rem;
            font-size: 1.2rem;
            color: var(--dark-color);
        }
        
        .timeline-text {
            color: #4B5563;
        }
        
        @media screen and (max-width: 768px) {
            .timeline::after {
                left: 31px;
            }
            
            .timeline-item {
                width: 100%;
                padding-left: 70px;
                left: 0 !important;
            }
            
            .timeline-item::after {
                left: 21px !important;
            }
        }
        
        .team-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 2rem;
            margin-top: 2rem;
        }
        
        .team-member {
            background-color: #fff;
            border-radius: var(--border-radius);
            overflow: hidden;
            box-shadow: var(--box-shadow);
            transition: transform 0.3s ease;
        }
        
        .team-member:hover {
            transform: translateY(-5px);
        }
        
        .member-image {
            width: 100%;
            height: 250px;
            background: linear-gradient(135deg, #9333EA, #4F46E5);
            position: relative;
        }
        
        .member-info {
            padding: 1.5rem;
            text-align: center;
        }
        
        .member-name {
            font-size: 1.2rem;
            margin-bottom: 0.25rem;
            color: var(--dark-color);
        }
        
        .member-role {
            color: var(--primary-color);
            font-weight: 500;
            margin-bottom: 1rem;
        }
        
        .member-bio {
            color: #4B5563;
            font-size: 0.95rem;
            margin-bottom: 1.25rem;
        }
        
        .social-links {
            display: flex;
            justify-content: center;
        }
        
        .social-link {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 35px;
            height: 35px;
            background: #E2E8F0;
            border-radius: 50%;
            margin: 0 0.25rem;
            color: var(--dark-color);
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .social-link:hover {
            background: var(--primary-color);
            color: white;
        }
        
        .values-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 2rem;
            margin-top: 2rem;
        }
        
        .value-card {
            background-color: #fff;
            border-radius: var(--border-radius);
            padding: 2rem;
            box-shadow: var(--box-shadow);
            text-align: center;
            transition: transform 0.3s ease;
        }
        
        .value-card:hover {
            transform: translateY(-5px);
        }
        
        .value-icon {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-fill-color: transparent;
        }
        
        .value-title {
            font-size: 1.2rem;
            margin-bottom: 1rem;
            color: var(--dark-color);
        }
        
        .value-text {
            color: #4B5563;
        }
        
        .cta-section {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            padding: 3rem 2rem;
            border-radius: var(--border-radius);
            text-align: center;
            margin-top: 2rem;
            color: white;
        }
        
        .cta-title {
            font-size: 2rem;
            margin-bottom: 1rem;
        }
        
        .cta-text {
            margin-bottom: 1.5rem;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
        }
        
        .cta-button {
            display: inline-block;
            background-color: white;
            color: var(--primary-color);
            padding: 0.75rem 2rem;
            border-radius: 30px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        .cta-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
        }
        
        .tech-stack {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 1.5rem;
            margin-top: 2rem;
        }
        
        .tech-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            width: 120px;
        }
        
        .tech-icon {
            font-size: 2.5rem;
            margin-bottom: 0.75rem;
            color: var(--primary-color);
        }
        
        .tech-name {
            font-size: 0.95rem;
            color: var(--dark-color);
            font-weight: 500;
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>About Our AI Platform</h1>
            <p class="subtitle">Discover the story behind our innovative AI tools platform, our mission, and the team making it all possible.</p>
        </header>
        
        <div class="about-hero">
            <div class="hero-image"></div>
            <div class="hero-overlay">
                <h2 class="hero-title">Transforming Industries Through AI</h2>
                <p class="hero-subtitle">For over <?php echo $yearsInBusiness; ?> years, we've been at the forefront of AI innovation, helping businesses unlock new possibilities.</p>
            </div>
        </div>
        
        <section class="section">
            <h2 class="section-title">Our Story</h2>
            <div class="section-content two-column">
                <div class="about-image"></div>
                <div class="about-text">
                    <p>Founded in <?php echo $companyFoundedYear; ?>, our journey began with a simple yet powerful vision: to make advanced AI technology accessible to everyone. What started as a small team of passionate AI engineers and data scientists has grown into a leading platform serving thousands of users worldwide.</p>
                    
                    <p>Our founder, <span class="highlight">Mr. Piyush Chaurasiya</span>, recognized that while artificial intelligence was revolutionizing industries, many organizations lacked the resources and expertise to implement AI solutions effectively. This insight led to the creation of our platform – a suite of <span class="highlight">intuitive AI tools</span> designed to solve real-world problems without requiring deep technical knowledge.</p>
                    
                    <p>Today, we're proud to have helped over <span class="highlight">5,000+ businesses</span> across 40+ countries harness the power of AI to automate processes, gain insights from data, and create innovative solutions. Our commitment to innovation, accessibility, and ethical AI development continues to drive everything we do.</p>
                </div>
            </div>
            
            <div class="stats-container">
                <div class="stat-card">
                    <div class="stat-number">5,000+</div>
                    <div class="stat-label">Businesses Served</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">40+</div>
                    <div class="stat-label">Countries</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">12+</div>
                    <div class="stat-label">AI Tools</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $yearsInBusiness; ?></div>
                    <div class="stat-label">Years of Innovation</div>
                </div>
            </div>
        </section>
        
        <section class="section">
            <h2 class="section-title">Our Journey</h2>
            <div class="section-content">
                <div class="timeline">
                    <div class="timeline-item">
                        <div class="timeline-content">
                            <div class="timeline-date">2020</div>
                            <h3 class="timeline-title">The Beginning</h3>
                            <p class="timeline-text">Founded with the mission to democratize AI technology and make it accessible to businesses of all sizes.</p>
                        </div>
                    </div>
                    
                    <div class="timeline-item">
                        <div class="timeline-content">
                            <div class="timeline-date">2021</div>
                            <h3 class="timeline-title">First AI Suite Launch</h3>
                            <p class="timeline-text">Released our first suite of AI tools focused on natural language processing and predictive analytics.</p>
                        </div>
                    </div>
                    
                    <div class="timeline-item">
                        <div class="timeline-content">
                            <div class="timeline-date">2022</div>
                            <h3 class="timeline-title">Global Expansion</h3>
                            <p class="timeline-text">Expanded our services to international markets and reached our first 1,000 customers milestone.</p>
                        </div>
                    </div>
                    
                    <div class="timeline-item">
                        <div class="timeline-content">
                            <div class="timeline-date">2023</div>
                            <h3 class="timeline-title">AI Innovation Award</h3>
                            <p class="timeline-text">Recognized with the prestigious Tech Innovator Award for our contributions to accessible AI solutions.</p>
                        </div>
                    </div>
                    
                    <div class="timeline-item">
                        <div class="timeline-content">
                            <div class="timeline-date">2024</div>
                            <h3 class="timeline-title">Advanced AI Platform</h3>
                            <p class="timeline-text">Launched our next-generation platform with enhanced capabilities in computer vision, generative AI, and automated machine learning.</p>
                        </div>
                    </div>
                    
                    <div class="timeline-item">
                        <div class="timeline-content">
                            <div class="timeline-date">2025</div>
                            <h3 class="timeline-title">The Future</h3>
                            <p class="timeline-text">Continuing to push the boundaries of what's possible with AI, with new tools and features in development.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <section class="section">
            <h2 class="section-title">Our Team</h2>
            <div class="section-content">
                <p style="margin-bottom: 2rem; text-align: center; color: #4B5563; max-width: 800px; margin-left: auto; margin-right: auto;">
                    Our diverse team of AI experts, engineers, and industry specialists work together to create tools that are powerful, intuitive, and transformative.
                </p>
                
                <div class="team-grid">
                    <div class="team-member">
                        <div class="member-image"></div>
                        <div class="member-info">
                            <h3 class="member-name">Dr. Alexandra Chen</h3>
                            <p class="member-role">Founder & CEO</p>
                            <p class="member-bio">Former AI research scientist with a passion for making advanced technology accessible to everyone.</p>
                            <div class="social-links">
                                <a href="#" class="social-link"><i class="fab fa-linkedin-in"></i></a>
                                <a href="#" class="social-link"><i class="fab fa-twitter"></i></a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="team-member">
                        <div class="member-image"></div>
                        <div class="member-info">
                            <h3 class="member-name">Michael Torres</h3>
                            <p class="member-role">CTO</p>
                            <p class="member-bio">AI engineer with extensive experience in building scalable machine learning systems.</p>
                            <div class="social-links">
                                <a href="#" class="social-link"><i class="fab fa-linkedin-in"></i></a>
                                <a href="#" class="social-link"><i class="fab fa-github"></i></a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="team-member">
                        <div class="member-image"></div>
                        <div class="member-info">
                            <h3 class="member-name">Sarah Johnson</h3>
                            <p class="member-role">Head of Product</p>
                            <p class="member-bio">Product strategy expert focused on creating intuitive user experiences for complex technologies.</p>
                            <div class="social-links">
                                <a href="#" class="social-link"><i class="fab fa-linkedin-in"></i></a>
                                <a href="#" class="social-link"><i class="fab fa-twitter"></i></a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="team-member">
                        <div class="member-image"></div>
                        <div class="member-info">
                            <h3 class="member-name">David Kim</h3>
                            <p class="member-role">Lead Data Scientist</p>
                            <p class="member-bio">Expert in predictive modeling with a background in statistical analysis and deep learning.</p>
                            <div class="social-links">
                                <a href="#" class="social-link"><i class="fab fa-linkedin-in"></i></a>
                                <a href="#" class="social-link"><i class="fab fa-github"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <section class="section">
            <h2 class="section-title">Our Mission & Values</h2>
            <div class="section-content">
                <p style="text-align: center; margin-bottom: 2rem; max-width: 800px; margin-left: auto; margin-right: auto; color: #4B5563;">
                    Our mission is to democratize artificial intelligence by providing powerful, user-friendly tools that enable organizations of all sizes to harness the potential of AI without requiring specialized expertise.
                </p>
                
                <div class="values-grid">
                    <div class="value-card">
                        <div class="value-icon">
                            <i class="fas fa-lightbulb"></i>
                        </div>
                        <h3 class="value-title">Innovation</h3>
                        <p class="value-text">We continuously push the boundaries of what's possible with AI, exploring new approaches and technologies to create better solutions.</p>
                    </div>
                    
                    <div class="value-card">
                        <div class="value-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <h3 class="value-title">Accessibility</h3>
                        <p class="value-text">We believe in making advanced AI capabilities available to everyone, regardless of technical background or resources.</p>
                    </div>
                    
                    <div class="value-card">
                        <div class="value-icon">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <h3 class="value-title">Ethics</h3>
                        <p class="value-text">We develop AI responsibly, prioritizing fairness, transparency, privacy, and the positive impact of our technology.</p>
                    </div>
                    
                    <div class="value-card">
                        <div class="value-icon">
                            <i class="fas fa-handshake"></i>
                        </div>
                        <h3 class="value-title">Collaboration</h3>
                        <p class="value-text">We work closely with our users and partners, valuing their insights and feedback to continuously improve our platform.</p>
                    </div>
                    
                    <div class="value-card">
                        <div class="value-icon">
                            <i class="fas fa-graduation-cap"></i>
                        </div>
                        <h3 class="value-title">Education</h3>
                        <p class="value-text">We're committed to helping our users understand AI concepts and applications through resources and support.</p>
                    </div>
                    
                    <div class="value-card">
                        <div class="value-icon">
                            <i class="fas fa-rocket"></i>
                        </div>
                        <h3 class="value-title">Excellence</h3>
                        <p class="value-text">We strive for the highest quality in everything we do, from our code to our customer service.</p>
                    </div>
                </div>
            </div>
        </section>
        
        <section class="section">
            <h2 class="section-title">Our Technology</h2>
            <div class="section-content">
                <p style="text-align: center; margin-bottom: 2rem; max-width: 800px; margin-left: auto; margin-right: auto; color: #4B5563;">
                    We leverage cutting-edge technologies and frameworks to build AI tools that are powerful, scalable, and secure.
                </p>
                
                <div class="tech-stack">
                    <div class="tech-item">
                        <div class="tech-icon">
                            <i class="fab fa-python"></i>
                        </div>
                        <span class="tech-name">Python</span>
                    </div>
                    
                    <div class="tech-item">
                        <div class="tech-icon">
                            <i class="fas fa-brain"></i>
                        </div>
                        <span class="tech-name">TensorFlow</span>
                    </div>
                    
                    <div class="tech-item">
                        <div class="tech-icon">
                            <i class="fas fa-fire"></i>
                        </div>
                        <span class="tech-name">PyTorch</span>
                    </div>
                    
                    <div class="tech-item">
                        <div class="tech-icon">
                            <i class="fas fa-database"></i>
                        </div>
                        <span class="tech-name">Big Data</span>
                    </div>
                    
                    <div class="tech-item">
                        <div class="tech-icon">
                            <i class="fas fa-cloud"></i>
                        </div>
                        <span class="tech-name">Cloud Computing</span>
                    </div>
                    
                    <div class="tech-item">
                        <div class="tech-icon">
                            <i class="fas fa-microchip"></i>
                        </div>
                        <span class="tech-name">GPU Computing</span>
                    </div>
                    
                    <div class="tech-item">
                        <div class="tech-icon">
                            <i class="fas fa-code-branch"></i>
                        </div>
                        <span class="tech-name">NLP</span>
                    </div>
                    
                    <div class="tech-item">
                        <div class="tech-icon">
                            <i class="fas fa-eye"></i>
                        </div>
                        <span class="tech-name">Computer Vision</span>
                    </div>
                </div>
            </div>
        </section>
        
        <div class="cta-section">
            <h2 class="cta-title">Ready to Transform Your Business with AI?</h2>
            <p class="cta-text">Join thousands of organizations already using our AI tools to automate processes, gain insights, and drive innovation.</p>
            <a href="contact" class="cta-button">Contact Us Today</a>
        </div>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Animation for timeline items
            const timelineItems = document.querySelectorAll('.timeline-item');
            
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.opacity = 1;
                        entry.target.style.transform = 'translateY(0)';
                    }
                });
            }, { threshold: 0.2 });
            
            timelineItems.forEach(item => {
                item.style.opacity = 0;
                item.style.transform = 'translateY(20px)';
                item.style.opacity = 0;
                item.style.transform = 'translateY(20px)';
                item.style.transition = 'all 0.5s ease-in-out';
                observer.observe(item);
            });
            
            // Animation for value cards
            const valueCards = document.querySelectorAll('.value-card');
            
            const valueObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.opacity = 1;
                        entry.target.style.transform = 'translateY(0)';
                    }
                });
            }, { threshold: 0.2 });
            
            valueCards.forEach((card, index) => {
                card.style.opacity = 0;
                card.style.transform = 'translateY(20px)';
                card.style.transition = `all 0.5s ease-in-out ${index * 0.1}s`;
                valueObserver.observe(card);
            });
            
            // Animation for team members
            const teamMembers = document.querySelectorAll('.team-member');
            
            const teamObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.opacity = 1;
                        entry.target.style.transform = 'translateY(0)';
                    }
                });
            }, { threshold: 0.2 });
            
            teamMembers.forEach((member, index) => {
                member.style.opacity = 0;
                member.style.transform = 'translateY(20px)';
                member.style.transition = `all 0.5s ease-in-out ${index * 0.1}s`;
                teamObserver.observe(member);
            });
            
            // Animation for stat cards
            const statCards = document.querySelectorAll('.stat-card');
            
            const statObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.opacity = 1;
                        entry.target.style.transform = 'scale(1)';
                    }
                });
            }, { threshold: 0.2 });
            
            statCards.forEach((card, index) => {
                card.style.opacity = 0;
                card.style.transform = 'scale(0.8)';
                card.style.transition = `all 0.5s ease-in-out ${index * 0.1}s`;
                statObserver.observe(card);
            });
            
            // Animation for tech items
            const techItems = document.querySelectorAll('.tech-item');
            
            const techObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.opacity = 1;
                        entry.target.style.transform = 'translateY(0)';
                    }
                });
            }, { threshold: 0.2 });
            
            techItems.forEach((item, index) => {
                item.style.opacity = 0;
                item.style.transform = 'translateY(20px)';
                item.style.transition = `all 0.5s ease-in-out ${index * 0.05}s`;
                techObserver.observe(item);
            });
            
            // Add hover effect for team member images
            const memberImages = document.querySelectorAll('.member-image');
            
            memberImages.forEach(image => {
                image.addEventListener('mouseenter', function() {
                    this.style.transform = 'scale(1.05)';
                    this.style.transition = 'transform 0.3s ease';
                });
                
                image.addEventListener('mouseleave', function() {
                    this.style.transform = 'scale(1)';
                });
            });
        });
    </script>
</body>
</html>