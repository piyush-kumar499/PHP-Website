
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php include_once ('../../private/favicon.php'); ?>
  <title><?php echo $pageTitle; ?></title>
  <link rel="stylesheet" href="../assets/css/footer.css">
  <style>
    :root {
      --primary: #3b82f6;
      --primary-dark: #2563eb;
      --secondary: #10b981;
      --dark: #1f2937;
      --light: #f9fafb;
      --gray: #6b7280;
      --light-gray: #e5e7eb;
    }
    
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
    }
    
    body {
      background-color: var(--light);
      color: var(--dark);
      line-height: 1.6;
    }
    
    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 2rem;
    }
    
    header {
      background-color: white;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
      padding: 1.5rem 0;
    }
    
    .job-header {
      padding: 4rem 0;
      background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
      color: white;
    }
    
    .job-header h1 {
      font-size: 2.5rem;
      margin-bottom: 0.5rem;
    }
    
    .job-meta {
      display: flex;
      flex-wrap: wrap;
      gap: 1.5rem;
      margin-top: 1rem;
    }
    
    .job-meta-item {
      display: flex;
      align-items: center;
      font-size: 1rem;
    }
    
    .job-meta-item svg {
      margin-right: 0.5rem;
    }
    
    .job-type {
      display: inline-block;
      padding: 0.25rem 0.75rem;
      border-radius: 999px;
      font-size: 0.75rem;
      font-weight: 500;
      text-transform: uppercase;
      margin-left: 1rem;
    }
    
    .job-type.fulltime {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .job-type.remote {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .job-type.contract {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .job-content {
      padding: 4rem 0;
    }
    
    .job-details {
      display: grid;
      grid-template-columns: 2fr 1fr;
      gap: 3rem;
    }
    
    .job-main h2 {
      font-size: 1.75rem;
      margin: 2rem 0 1rem;
      color: var(--dark);
    }
    
    .job-main p {
      margin-bottom: 1rem;
      color: var(--gray);
    }
    
    .job-main ul {
      margin-bottom: 1.5rem;
      padding-left: 1.5rem;
      color: var(--gray);
    }
    
    .job-main li {
      margin-bottom: 0.5rem;
    }
    
    .job-sidebar {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
      padding: 1.5rem;
      align-self: start;
      position: sticky;
      top: 2rem;
    }
    
    .job-sidebar h3 {
      font-size: 1.25rem;
      margin-bottom: 1.5rem;
      padding-bottom: 1rem;
      border-bottom: 1px solid var(--light-gray);
    }
    
    .sidebar-meta {
      margin-bottom: 2rem;
    }
    
    .sidebar-meta-item {
      display: flex;
      margin-bottom: 1rem;
    }
    
    .sidebar-meta-item svg {
      flex-shrink: 0;
      width: 20px;
      height: 20px;
      margin-right: 0.75rem;
      color: var(--primary);
    }
    
    .sidebar-meta-item div {
      display: flex;
      flex-direction: column;
    }
    
    .sidebar-meta-item span:first-child {
      font-weight: 500;
      color: var(--dark);
    }
    
    .sidebar-meta-item span:last-child {
      font-size: 0.9rem;
      color: var(--gray);
    }
    
    .btn {
      display: inline-block;
      padding: 0.75rem 1.5rem;
      font-weight: 500;
      border-radius: 0.375rem;
      text-align: center;
      cursor: pointer;
      transition: all 0.3s;
      text-decoration: none;
      width: 100%;
    }
    
    .btn-primary {
      background-color: var(--primary);
      color: white;
    }
    
    .btn-primary:hover {
      background-color: var(--primary-dark);
    }
    
    .btn-outline {
      border: 1px solid var(--primary);
      color: var(--primary);
      background-color: transparent;
      margin-top: 1rem;
    }
    
    .btn-outline:hover {
      background-color: var(--primary);
      color: white;
    }
    
    .breadcrumbs {
      display: flex;
      align-items: center;
      margin-bottom: 1.5rem;
      font-size: 0.9rem;
    }
    
    .breadcrumbs a {
      color: rgba(255, 255, 255, 0.8);
      text-decoration: none;
    }
    
    .breadcrumbs a:hover {
      color: white;
    }
    
    .breadcrumbs span {
      margin: 0 0.5rem;
      color: rgba(255, 255, 255, 0.6);
    }
    
    @media (max-width: 768px) {
      .job-details {
        grid-template-columns: 1fr;
      }
      
      .job-sidebar {
        position: static;
        margin-top: 2rem;
      }
      
      .job-header h1 {
        font-size: 2rem;
      }
    }
  </style>
</head>
<body>
  <?php
  // In a real application, you would fetch job data from a database based on the ID
  $jobId = isset($_GET['id']) ? intval($_GET['id']) : 0;
  
  // Mock job data array - in a real app, this would come from a database
  $jobs = [
      1 => [
          'id' => 1,
          'title' => 'AI Solutions Architect',
          'location' => 'San Francisco, CA',
          'type' => 'fulltime',
          'type_label' => 'Full-time',
          'description' => 'Design and implement AI solutions for enterprise clients. Collaborate with cross-functional teams to deliver cutting-edge AI products.',
          'posted' => 'March 25, 2025',
          'salary' => '$120K - $160K',
          'department' => 'Engineering',
          'reports_to' => 'VP of Engineering',
          'full_description' => "We're looking for an AI Solutions Architect to join our team and help design innovative AI solutions for our enterprise clients. The ideal candidate will have a strong background in artificial intelligence, machine learning, and software architecture.",
          'responsibilities' => [
              'Design and architect AI solutions based on client requirements',
              'Work with cross-functional teams to implement and deploy AI systems',
              'Develop proof-of-concepts and prototypes to demonstrate solution capabilities',
              'Create technical documentation and solution architecture diagrams',
              'Provide technical leadership and mentorship to other team members',
              'Stay current with the latest AI technologies and industry trends',
              'Collaborate with the sales team to support client presentations and demos'
          ],
          'requirements' => [
              '5+ years of experience in software architecture with a focus on AI solutions',
              'Strong understanding of machine learning frameworks and technologies',
              'Experience with cloud platforms (AWS, Azure, or GCP)',
              'Excellent problem-solving and communication skills',
              'Bachelor\'s or Master\'s degree in Computer Science, AI, or related field',
              'Experience with AI deployment in enterprise environments',
              'Knowledge of data privacy and security best practices'
          ],
          'benefits' => [
              'Competitive salary and equity package',
              'Comprehensive health, dental, and vision insurance',
              'Flexible work arrangements and unlimited PTO',
              'Annual learning and development stipend',
              '401(k) with company match',
              'Regular team events and company retreats',
              'Opportunity to work on cutting-edge AI technologies'
          ]
      ],
      2 => [
          'id' => 2,
          'title' => 'Machine Learning Engineer',
          'location' => 'Remote',
          'type' => 'remote',
          'type_label' => 'Remote',
          'description' => 'Develop and optimize machine learning models for our AI platform. Work on cutting-edge algorithms and contribute to our research initiatives.',
          'posted' => 'March 22, 2025',
          'salary' => '$110K - $150K',
          'department' => 'AI Research',
          'reports_to' => 'Director of AI Research',
          'full_description' => "We are seeking a skilled Machine Learning Engineer to join our team and help develop advanced ML models for our AI platform. You'll work on state-of-the-art algorithms and contribute to our research initiatives.",
          'responsibilities' => [
              'Design, develop, and implement machine learning models and algorithms',
              'Work with large datasets to train and fine-tune ML models',
              'Optimize model performance and ensure scalability',
              'Collaborate with data scientists and software engineers',
              'Contribute to research papers and open-source projects',
              'Stay current with the latest ML research and technologies',
              'Develop tools to monitor and analyze model performance'
          ],
          'requirements' => [
              '3+ years of experience in machine learning engineering',
              'Strong programming skills in Python and experience with ML frameworks (TensorFlow, PyTorch)',
              'Experience with NLP, computer vision, or reinforcement learning',
              'Familiarity with distributed computing and big data technologies',
              'Master\'s or Ph.D. in Computer Science, Machine Learning, or related field',
              'Strong mathematical background in statistics and linear algebra',
              'Experience with deploying ML models to production environments'
          ],
          'benefits' => [
              'Competitive salary and equity package',
              'Comprehensive health, dental, and vision insurance',
              'Flexible work arrangements and unlimited PTO',
              'Annual learning and development stipend',
              '401(k) with company match',
              'Regular team events and company retreats',
              'Opportunity to work on cutting-edge AI technologies'
          ]
      ],
      // Additional job details would be defined similarly for IDs 3-6
  ];
  
  // If job ID doesn't exist, redirect to careers page
  if (!isset($jobs[$jobId])) {
      header('Location: careers');
      exit;
  }
  
  $job = $jobs[$jobId];
  ?>
  
  <section class="job-header">
    <div class="container">
      <div class="breadcrumbs">
        <a href="/">Home</a>
        <span>/</span>
        <a href="careers">Careers</a>
        <span>/</span>
        <?php echo htmlspecialchars($job['title']); ?>
      </div>
      <h1><?php echo htmlspecialchars($job['title']); ?></h1>
      <div class="job-meta">
        <div class="job-meta-item">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
            <path d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6z"/>
          </svg>
          <?php echo htmlspecialchars($job['location']); ?>
        </div>
        <div class="job-meta-item">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
            <path d="M14 0H2a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zM1 3.857C1 3.384 1.448 3 2 3h12c.552 0 1 .384 1 .857v10.286c0 .473-.448.857-1 .857H2c-.552 0-1-.384-1-.857V3.857z"/>
            <path d="M6.5 7a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm-9 3a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm-9 3a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/>
          </svg>
          Posted: <?php echo htmlspecialchars($job['posted']); ?>
        </div>
        <div class="job-meta-item">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
            <path d="M4 10.781c.148 1.667 1.513 2.85 3.591 3.003V15h1.043v-1.216c2.27-.179 3.678-1.438 3.678-3.3 0-1.59-.947-2.51-2.956-3.028l-.722-.187V3.467c1.122.11 1.879.714 2.07 1.616h1.47c-.166-1.6-1.54-2.748-3.54-2.875V1H7.591v1.233c-1.939.23-3.27 1.472-3.27 3.156 0 1.454.966 2.483 2.661 2.917l.61.162v4.031c-1.149-.17-1.94-.8-2.131-1.718H4zm3.391-3.836c-1.043-.263-1.6-.825-1.6-1.616 0-.944.704-1.641 1.8-1.828v3.495l-.2-.05zm1.591 1.872c1.287.323 1.852.859 1.852 1.769 0 1.097-.826 1.828-2.2 1.939V8.73l.348.086z"/>
          </svg>
          <?php echo htmlspecialchars($job['salary']); ?>
        </div>
        <span class="job-type <?php echo $job['type']; ?>"><?php echo $job['type_label']; ?></span>
      </div>
    </div>
  </section>
  
  <section class="job-content">
    <div class="container">
      <div class="job-details">
        <div class="job-main">
          <p><?php echo htmlspecialchars($job['full_description']); ?></p>
          
          <h2>Responsibilities</h2>
          <ul>
            <?php foreach ($job['responsibilities'] as $responsibility): ?>
              <li><?php echo htmlspecialchars($responsibility); ?></li>
            <?php endforeach; ?>
          </ul>
          
          <h2>Requirements</h2>
          <ul>
            <?php foreach ($job['requirements'] as $requirement): ?>
              <li><?php echo htmlspecialchars($requirement); ?></li>
            <?php endforeach; ?>
          </ul>
          
          <h2>Benefits</h2>
          <ul>
            <?php foreach ($job['benefits'] as $benefit): ?>
              <li><?php echo htmlspecialchars($benefit); ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
        
        <div class="job-sidebar">
          <h3>Job Details</h3>
          <div class="sidebar-meta">
            <div class="sidebar-meta-item">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
              <div>
                <span>Department</span>
                <span><?php echo htmlspecialchars($job['department']); ?></span>
              </div>
            </div>
            
            <div class="sidebar-meta-item">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
              <div>
                <span>Reports To</span>
                <span><?php echo htmlspecialchars($job['reports_to']); ?></span>
              </div>
            </div>
            
            <div class="sidebar-meta-item">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
              <div>
                <span>Location</span>
                <span><?php echo htmlspecialchars($job['location']); ?></span>
              </div>
            </div>
            
            <div class="sidebar-meta-item">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <div>
                <span>Employment Type</span>
                <span><?php echo htmlspecialchars($job['type_label']); ?></span>
              </div>
            </div>
          </div>
          
          <a href="apply?id=<?php echo $job['id']; ?>" class="btn btn-primary">Apply Now</a>
          <a href="javascript:window.print();" class="btn btn-outline">Print Job Description</a>
        </div>
      </div>
    </div>
  </section>

</body>
</html>