<?php
// Set page variables
$pageTitle = "Disclaimer | AI Tools Platform";
$currentYear = date('Y');
$lastUpdated = "March 20, 2025";

// Check if user is logged in (you'll need to adapt this to your authentication system)
$isLoggedIn = isset($_SESSION['user_id']); // This assumes you use sessions to track login status

// Set the redirect URL based on login status
$redirectUrl = $isLoggedIn ? "/" : "/register";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include_once ('../../private/favicon.php'); ?>
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4F46E5;
            --secondary-color: #7C3AED;
            --dark-color: #1E293B;
            --light-color: #F8FAFC;
            --accent-color: #06B6D4;
            --success-color: #10B981;
            --warning-color: #F59E0B;
            --border-radius: 8px;
            --box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        }
        
        body {
            background-color: var(--light-color);
            color: var(--dark-color);
            line-height: 1.6;
        }
        
        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        header {
            margin-bottom: 3rem;
            text-align: center;
        }
        
        h1 {
            font-size: 3rem;
            margin-bottom: 0.5rem;
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-fill-color: transparent;
        }
        
        .subtitle {
            font-size: 1.2rem;
            color: #64748B;
            margin-bottom: 1.5rem;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }
        
        .disclaimer-hero {
            position: relative;
            background-color: #fff;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            overflow: hidden;
            margin-bottom: 4rem;
        }
        
        .hero-image {
            width: 100%;
            height: 300px;
            object-fit: cover;
            background: linear-gradient(135deg, #F59E0B, #EC4899);
            position: relative;
        }
        
        .hero-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(30, 41, 59, 0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            text-align: center;
            padding: 2rem;
        }
        
        .hero-title {
            color: white;
            font-size: 2.5rem;
            margin-bottom: 1rem;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }
        
        .hero-subtitle {
            color: rgba(255, 255, 255, 0.9);
            font-size: 1.25rem;
            max-width: 800px;
        }
        
        .section {
            margin-bottom: 4rem;
        }
        
        .section-title {
            font-size: 2rem;
            margin-bottom: 1.5rem;
            color: var(--dark-color);
            position: relative;
            padding-bottom: 0.5rem;
            display: inline-block;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 60%;
            height: 3px;
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            border-radius: 3px;
        }
        
        .section-content {
            background-color: #fff;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 2rem;
        }
        
        .disclaimer-content {
            color: #4B5563;
        }
        
        .disclaimer-content h3 {
            color: var(--dark-color);
            margin-top: 1.5rem;
            margin-bottom: 0.75rem;
            font-size: 1.5rem;
        }
        
        .disclaimer-content p {
            margin-bottom: 1rem;
        }
        
        .disclaimer-content ul, .disclaimer-content ol {
            margin-bottom: 1rem;
            margin-left: 1.5rem;
        }
        
        .disclaimer-content li {
            margin-bottom: 0.5rem;
        }
        
        .highlight {
            color: var(--primary-color);
            font-weight: 600;
        }
        
        .info-box {
            background-color: rgba(79, 70, 229, 0.1);
            border-left: 4px solid var(--primary-color);
            padding: 1.5rem;
            margin: 1.5rem 0;
            border-radius: var(--border-radius);
        }
        
        .warning-box {
            background-color: rgba(245, 158, 11, 0.1);
            border-left: 4px solid var(--warning-color);
            padding: 1.5rem;
            margin: 1.5rem 0;
            border-radius: var(--border-radius);
        }
        
        .info-box-title, .warning-box-title {
            display: flex;
            align-items: center;
            margin-bottom: 0.75rem;
            font-weight: 600;
            color: var(--dark-color);
        }
        
        .info-box-title i {
            margin-right: 0.75rem;
            color: var(--primary-color);
        }
        
        .warning-box-title i {
            margin-right: 0.75rem;
            color: var(--warning-color);
        }
        
        .info-box-content, .warning-box-content {
            color: #4B5563;
        }
        
        .contact-info {
            background-color: #fff;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 2rem;
            text-align: center;
            margin-top: 2rem;
        }
        
        .contact-title {
            font-size: 1.5rem;
            margin-bottom: 1rem;
            color: var(--dark-color);
        }
        
        .contact-item {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 0.75rem;
        }
        
        .contact-item i {
            color: var(--primary-color);
            margin-right: 0.75rem;
            font-size: 1.2rem;
        }
        
        .cta-section {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            padding: 3rem 2rem;
            border-radius: var(--border-radius);
            text-align: center;
            margin-top: 3rem;
            color: white;
        }
        
        .cta-title {
            font-size: 2rem;
            margin-bottom: 1rem;
        }
        
        .cta-text {
            margin-bottom: 1.5rem;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
        }
        
        .cta-button {
            display: inline-block;
            background-color: white;
            color: var(--primary-color);
            padding: 0.75rem 2rem;
            border-radius: 30px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        .cta-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
        }
        
        .last-updated {
            text-align: center;
            color: #64748B;
            margin-top: 2rem;
            font-style: italic;
        }
        
        .disclaimer-navigation {
            background-color: #fff;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .nav-title {
            font-size: 1.2rem;
            margin-bottom: 1rem;
            color: var(--dark-color);
            font-weight: 600;
        }
        
        .nav-list {
            list-style: none;
        }
        
        .nav-item {
            margin-bottom: 0.5rem;
        }
        
        .nav-link {
            text-decoration: none;
            color: var(--primary-color);
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
        }
        
        .nav-link i {
            margin-right: 0.5rem;
            font-size: 0.8rem;
        }
        
        .nav-link:hover {
            color: var(--secondary-color);
            transform: translateX(5px);
        }
        
        .back-to-top {
            position: fixed;
            bottom: 2rem;
            right: 2rem;
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            box-shadow: var(--box-shadow);
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }
        
        .back-to-top.visible {
            opacity: 1;
            visibility: visible;
        }
        
        .back-to-top i {
            font-size: 1.2rem;
        }
        
        @media (max-width: 768px) {
            .container {
                padding: 1rem;
            }
            
            h1 {
                font-size: 2.2rem;
            }
            
            .hero-title {
                font-size: 2rem;
            }
            
            .section-title {
                font-size: 1.8rem;
            }
            
            .hero-image {
                height: 250px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Disclaimer</h1>
            <p class="subtitle">Please read this disclaimer carefully before using our AI Tools Platform. This disclaimer outlines important information regarding the use of our services and content.</p>
        </header>
        
        <div class="disclaimer-hero">
            <div class="hero-image"></div>
            <div class="hero-overlay">
                <h2 class="hero-title">Important Notice</h2>
                <p class="hero-subtitle">Our AI tools are provided "as is" with no guarantees. Please review our terms and limitations before use.</p>
            </div>
        </div>
        
        <div class="disclaimer-navigation">
            <h3 class="nav-title">Quick Navigation</h3>
            <ul class="nav-list">
                <li class="nav-item"><a href="#general" class="nav-link"><i class="fas fa-angle-right"></i> General Disclaimer</a></li>
                <li class="nav-item"><a href="#accuracy" class="nav-link"><i class="fas fa-angle-right"></i> Accuracy and Reliability</a></li>
                <li class="nav-item"><a href="#intellectual" class="nav-link"><i class="fas fa-angle-right"></i> Intellectual Property</a></li>
                <li class="nav-item"><a href="#third-party" class="nav-link"><i class="fas fa-angle-right"></i> Third-Party Links</a></li>
                <li class="nav-item"><a href="#liability" class="nav-link"><i class="fas fa-angle-right"></i> Limitation of Liability</a></li>
                <li class="nav-item"><a href="#indemnification" class="nav-link"><i class="fas fa-angle-right"></i> Indemnification</a></li>
                <li class="nav-item"><a href="#professional" class="nav-link"><i class="fas fa-angle-right"></i> Professional Advice Disclaimer</a></li>
                <li class="nav-item"><a href="#changes" class="nav-link"><i class="fas fa-angle-right"></i> Changes to This Disclaimer</a></li>
                <li class="nav-item"><a href="#contact" class="nav-link"><i class="fas fa-angle-right"></i> Contact Us</a></li>
            </ul>
        </div>
        
        <section id="general" class="section">
            <h2 class="section-title">General Disclaimer</h2>
            <div class="section-content">
                <div class="disclaimer-content">
                    <p>The information provided on the AI Tools Platform ("Platform") is for general informational purposes only. All information on the Platform is provided in good faith; however, we make no representation or warranty of any kind, express or implied, regarding the accuracy, adequacy, validity, reliability, availability, or completeness of any information on the Platform.</p>
                    
                    <p>By using our Platform, you acknowledge and agree that:</p>
                    <ul>
                        <li>Your use of our Platform and services is at your sole risk</li>
                        <li>You are solely responsible for any content you generate, modify, or distribute using our AI tools</li>
                        <li>We reserve the right to modify or discontinue any part of our services without notice</li>
                        <li>We are not liable for any harm resulting from your use of the Platform</li>
                    </ul>
                    
                    <div class="warning-box">
                        <div class="warning-box-title">
                            <i class="fas fa-exclamation-triangle"></i>
                            <span>Important Notice</span>
                        </div>
                        <div class="warning-box-content">
                            <p>The AI tools provided on our Platform are computational systems designed to generate content based on the inputs they receive. They do not possess human judgment or reasoning capabilities. Users should exercise critical thinking and maintain responsible oversight when using AI-generated content.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <section id="accuracy" class="section">
            <h2 class="section-title">Accuracy and Reliability</h2>
            <div class="section-content">
                <div class="disclaimer-content">
                    <p>While we strive to use commercially acceptable means to ensure the accuracy and reliability of our AI tools and the content they generate, we do not guarantee that:</p>
                    
                    <ul>
                        <li>The Platform will be available at all times, uninterrupted, or error-free</li>
                        <li>The results obtained from using our AI tools will be accurate, complete, or meet your specific requirements</li>
                        <li>Any errors or defects in the Platform will be corrected</li>
                        <li>The Platform is free from viruses or other harmful components</li>
                    </ul>
                    
                    <h3>AI-Generated Content Limitations</h3>
                    <p>AI-generated content, including text, images, code, and other outputs produced by our tools, may:</p>
                    <ul>
                        <li>Contain factual errors, inconsistencies, or misleading information</li>
                        <li>Reflect biases present in training data despite our mitigation efforts</li>
                        <li>Generate incomplete, nonsensical, or contextually inappropriate content</li>
                        <li>Inadvertently create content that resembles existing works</li>
                    </ul>
                    
                    <p>Users are responsible for critically evaluating, verifying, and editing any AI-generated content before use or distribution, especially for professional, commercial, educational, or safety-critical applications.</p>
                    
                    <div class="info-box">
                        <div class="info-box-title">
                            <i class="fas fa-info-circle"></i>
                            <span>Best Practices</span>
                        </div>
                        <div class="info-box-content">
                            <p>Always review AI-generated content carefully before use. Fact-check important information, verify technical accuracy, and ensure the content meets your ethical standards and compliance requirements.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <section id="intellectual" class="section">
            <h2 class="section-title">Intellectual Property</h2>
            <div class="section-content">
                <div class="disclaimer-content">
                    <p>The legal status of AI-generated content is complex and evolving. Our position regarding intellectual property is as follows:</p>
                    
                    <h3>Ownership of AI-Generated Content</h3>
                    <p>Subject to our Terms of Service:</p>
                    <ul>
                        <li>You retain rights to the original content you create using our AI tools to the extent permitted by law</li>
                        <li>We do not claim ownership of content generated by our AI tools based on your inputs</li>
                        <li>We retain all rights, title, and interest in our Platform, AI models, algorithms, and underlying technology</li>
                    </ul>
                    
                    <h3>Third-Party Rights</h3>
                    <p>We cannot guarantee that content generated by our AI tools does not infringe on third-party intellectual property rights. Users are responsible for:</p>
                    <ul>
                        <li>Ensuring AI-generated content does not violate copyrights, trademarks, or other intellectual property rights</li>
                        <li>Obtaining necessary permissions or licenses for commercial use or distribution</li>
                        <li>Complying with all applicable intellectual property laws</li>
                    </ul>
                    
                    <div class="warning-box">
                        <div class="warning-box-title">
                            <i class="fas fa-copyright"></i>
                            <span>Copyright Notice</span>
                        </div>
                        <div class="warning-box-content">
                            <p>AI systems are trained on existing content and may generate outputs that resemble copyrighted works. Users should be vigilant about potential copyright infringement when using AI-generated content, particularly for commercial purposes.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <section id="third-party" class="section">
            <h2 class="section-title">Third-Party Links</h2>
            <div class="section-content">
                <div class="disclaimer-content">
                    <p>Our Platform may contain links to third-party websites or services that are not owned or controlled by us. We have no control over, and assume no responsibility for, the content, privacy policies, or practices of any third-party websites or services.</p>
                    
                    <p>You acknowledge and agree that we shall not be responsible or liable, directly or indirectly, for any damage or loss caused or alleged to be caused by or in connection with the use of or reliance on any such content, goods, or services available on or through any such websites or services.</p>
                    
                    <p>We strongly advise you to read the terms and conditions and privacy policies of any third-party websites or services that you visit or interact with.</p>
                </div>
            </div>
        </section>
        
        <section id="liability" class="section">
            <h2 class="section-title">Limitation of Liability</h2>
            <div class="section-content">
                <div class="disclaimer-content">
                    <p>To the maximum extent permitted by applicable law, in no event shall the AI Tools Platform, its affiliates, directors, employees, agents, or licensors be liable for any indirect, punitive, incidental, special, consequential, or exemplary damages, including without limitation:</p>
                    
                    <ul>
                        <li>Damages for loss of profits, goodwill, use, data, or other intangible losses</li>
                        <li>Damages arising from the use or inability to use the Platform or AI tools</li>
                        <li>Damages resulting from any content generated, modified, or distributed using our AI tools</li>
                        <li>Damages resulting from unauthorized access to or use of our servers or any personal information stored therein</li>
                        <li>Damages resulting from interruption or cessation of transmission to or from the Platform</li>
                        <li>Damages resulting from any bugs, viruses, trojan horses, or the like that may be transmitted to or through the Platform</li>
                    </ul>
                    
                    <p>In jurisdictions where the exclusion or limitation of liability for consequential or incidental damages is not permitted, our liability shall be limited to the maximum extent permitted by law.</p>
                </div>
            </div>
        </section>
        
        <section id="indemnification" class="section">
            <h2 class="section-title">Indemnification</h2>
            <div class="section-content">
                <div class="disclaimer-content">
                    <p>You agree to defend, indemnify, and hold harmless the AI Tools Platform, its affiliates, licensors, and service providers, and its and their respective officers, directors, employees, contractors, agents, licensors, suppliers, successors, and assigns from and against any claims, liabilities, damages, judgments, awards, losses, costs, expenses, or fees (including reasonable attorneys' fees) arising out of or relating to:</p>
                    
                    <ul>
                        <li>Your violation of these terms, including the Disclaimer</li>
                        <li>Your violation of any rights of another person or entity</li>
                        <li>Your use of the Platform, including any content you generate, modify, or distribute using our AI tools</li>
                        <li>Any activity related to your account (including negligent or wrongful conduct) by you or any other person accessing the Platform using your account</li>
                    </ul>
                </div>
            </div>
        </section>
        
        <section id="professional" class="section">
            <h2 class="section-title">Professional Advice Disclaimer</h2>
            <div class="section-content">
                <div class="disclaimer-content">
                    <p>The AI tools and content provided on our Platform are not intended to constitute professional advice. The information and outputs generated are for general informational purposes only and should not be relied upon as a substitute for professional advice from qualified experts.</p>
                    
                    <h3>Specific Disclaimers</h3>
                    <ul>
                        <li><span class="highlight">Medical or Health Information:</span> Our Platform does not provide medical advice. Content related to health, medicine, or wellness should not replace professional medical advice, diagnosis, or treatment. Always seek the advice of qualified healthcare providers for any medical conditions.</li>
                        <li><span class="highlight">Legal Information:</span> Our Platform does not provide legal advice. Content related to legal matters should not replace professional legal advice from licensed attorneys in your jurisdiction.</li>
                        <li><span class="highlight">Financial Information:</span> Our Platform does not provide financial, investment, or tax advice. Content related to financial matters should not replace professional financial advice from licensed financial advisors.</li>
                        <li><span class="highlight">Technical or Engineering Information:</span> Our Platform does not guarantee the technical accuracy or safety of engineering, programming, or other technical content. Such content should be verified by qualified professionals before implementation.</li>
                    </ul>
                    
                    <div class="warning-box">
                        <div class="warning-box-title">
                            <i class="fas fa-user-md"></i>
                            <span>Consult Professionals</span>
                        </div>
                        <div class="warning-box-content">
                            <p>For medical, legal, financial, technical, or other specialized advice, always consult with appropriate licensed professionals who can evaluate your specific situation and needs.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <section id="changes" class="section">
            <h2 class="section-title">Changes to This Disclaimer</h2>
            <div class="section-content">
                <div class="disclaimer-content">
                    <p>We may update this Disclaimer from time to time to reflect changes in our practices, technology, legal requirements, or other factors. When we update our Disclaimer, we will take appropriate measures to inform you, consistent with the significance of the changes we make.</p>
                    
                    <p>If we make material changes to this Disclaimer, we will notify you by:</p>
                    <ul>
                        <li>Displaying a prominent notice on our website</li>
                        <li>Sending an email to the address associated with your account</li>
                        <li>Showing a notification when you log in to our platform</li>
                    </ul>
                    
                    <p>Your continued use of our services after the effective date of the revised Disclaimer constitutes your acceptance of the changes.</p>
                    
                    <p class="last-updated">This Disclaimer was last updated on <?php echo $lastUpdated; ?>.</p>
                </div>
            </div>
        </section>
        
        <section id="contact" class="section">
            <h2 class="section-title">Contact Us</h2>
            <div class="section-content">
                <div class="disclaimer-content">
                    <p>If you have any questions, concerns, or requests regarding this Disclaimer or our data practices, please contact us:</p>
                    
                    <div class="contact-info">
                        <h3 class="contact-title">AI Tools Platform Legal Team</h3>
                        <div class="contact-item">
                            <i class="fas fa-envelope"></i>
                            <span>legal@aitools-platform.com</span>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>123 AI Boulevard, Tech City, CA 94107, USA</span>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-phone"></i>
                            <span>+1 (555) 123-4567</span>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <div class="cta-section">
            <h3 class="cta-title">Ready to Experience Our AI Tools?</h3>
            <p class="cta-text">Start creating amazing content, analyzing data, and automating workflows with our cutting-edge AI platform.</p>
            <a href="<?php echo $redirectUrl; ?>" class="cta-button">Get Started Today</a>
        </div>
        
        <p class="last-updated">© <?php echo $currentYear; ?> AI Tools Platform. All rights reserved.</p>
    </div>
    
    <a href="#" class="back-to-top" id="backToTop">
        <i class="fas fa-arrow-up"></i>
    </a>
    
    <script>
        // Back to top button functionality
        const backToTopButton = document.getElementById('backToTop');
        
        window.addEventListener('scroll', () => {
            if (window.pageYOffset > 300) {
                backToTopButton.classList.add('visible');
            } else {
                backToTopButton.classList.remove('visible');
            }
        });
        
        backToTopButton.addEventListener('click', (e) => {
            e.preventDefault();
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
        
        // Smooth scrolling for navigation links
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                const href = link.getAttribute('href');
                
                if (href.startsWith('#')) {
                    e.preventDefault();
                    const targetElement = document.querySelector(href);
                    
                    if (targetElement) {
                        window.scrollTo({
                            top: targetElement.offsetTop - 20,
                            behavior: 'smooth'
                        });
                    }
                }
            });
        });
    </script>
</body>
</html>