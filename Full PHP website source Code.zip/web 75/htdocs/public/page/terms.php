<?php
// Set page variables
$pageTitle = "Terms and Conditions | AI Tools Platform";
$currentYear = date('Y');
$lastUpdated = "March 15, 2025";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include_once ('../../private/favicon.php'); ?>
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4F46E5;
            --secondary-color: #7C3AED;
            --dark-color: #1E293B;
            --light-color: #F8FAFC;
            --accent-color: #06B6D4;
            --success-color: #10B981;
            --warning-color: #F59E0B;
            --border-radius: 8px;
            --box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        }
        
        body {
            background-color: var(--light-color);
            color: var(--dark-color);
            line-height: 1.6;
        }
        
        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        header {
            margin-bottom: 3rem;
            text-align: center;
        }
        
        h1 {
            font-size: 3rem;
            margin-bottom: 0.5rem;
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-fill-color: transparent;
        }
        
        .subtitle {
            font-size: 1.2rem;
            color: #64748B;
            margin-bottom: 1.5rem;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }
        
        .terms-hero {
            position: relative;
            background-color: #fff;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            overflow: hidden;
            margin-bottom: 4rem;
        }
        
        .hero-image {
            width: 100%;
            height: 250px;
            object-fit: cover;
            background: linear-gradient(135deg, #6366F1, #A855F7);
            position: relative;
        }
        
        .hero-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(30, 41, 59, 0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            text-align: center;
            padding: 2rem;
        }
        
        .hero-title {
            color: white;
            font-size: 2.5rem;
            margin-bottom: 1rem;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }
        
        .hero-subtitle {
            color: rgba(255, 255, 255, 0.9);
            font-size: 1.25rem;
            max-width: 800px;
        }
        
        .section {
            margin-bottom: 4rem;
        }
        
        .section-title {
            font-size: 2rem;
            margin-bottom: 1.5rem;
            color: var(--dark-color);
            position: relative;
            padding-bottom: 0.5rem;
            display: inline-block;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 60%;
            height: 3px;
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            border-radius: 3px;
        }
        
        .section-content {
            background-color: #fff;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 2rem;
        }
        
        .terms-section {
            margin-bottom: 2.5rem;
        }
        
        .terms-section:last-child {
            margin-bottom: 0;
        }
        
        .terms-title {
            font-size: 1.5rem;
            color: var(--dark-color);
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid #E2E8F0;
        }
        
        .terms-content p {
            margin-bottom: 1rem;
            color: #4B5563;
        }
        
        .terms-content p:last-child {
            margin-bottom: 0;
        }
        
        .terms-content ul, .terms-content ol {
            margin-bottom: 1rem;
            padding-left: 1.5rem;
            color: #4B5563;
        }
        
        .terms-content li {
            margin-bottom: 0.5rem;
        }
        
        .terms-content li:last-child {
            margin-bottom: 0;
        }
        
        .highlight {
            color: var(--primary-color);
            font-weight: 600;
        }
        
        .update-info {
            display: inline-block;
            padding: 0.5rem 1rem;
            background-color: #EEF2FF;
            border-radius: 30px;
            color: var(--primary-color);
            font-weight: 500;
            margin-bottom: 2rem;
            font-size: 0.95rem;
        }
        
        .update-info i {
            margin-right: 0.5rem;
        }
        
        .back-to-top {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            box-shadow: var(--box-shadow);
            cursor: pointer;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }
        
        .back-to-top.visible {
            opacity: 1;
            visibility: visible;
        }
        
        .table-of-contents {
            background-color: #EEF2FF;
            border-radius: var(--border-radius);
            padding: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .toc-title {
            font-size: 1.2rem;
            color: var(--dark-color);
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
        }
        
        .toc-title i {
            margin-right: 0.5rem;
            color: var(--primary-color);
        }
        
        .toc-list {
            list-style: none;
            padding-left: 0;
        }
        
        .toc-item {
            margin-bottom: 0.5rem;
        }
        
        .toc-link {
            display: inline-block;
            padding: 0.25rem 0;
            color: #4B5563;
            text-decoration: none;
            transition: all 0.2s ease;
        }
        
        .toc-link:hover {
            color: var(--primary-color);
            transform: translateX(5px);
        }
        
        .cta-section {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            padding: 3rem 2rem;
            border-radius: var(--border-radius);
            text-align: center;
            margin-top: 3rem;
            color: white;
        }
        
        .cta-title {
            font-size: 2rem;
            margin-bottom: 1rem;
        }
        
        .cta-text {
            margin-bottom: 1.5rem;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
        }
        
        .cta-button {
            display: inline-block;
            background-color: white;
            color: var(--primary-color);
            padding: 0.75rem 2rem;
            border-radius: 30px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        .cta-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
        }
        
        @media (max-width: 768px) {
            .container {
                padding: 1rem;
            }
            
            h1 {
                font-size: 2.2rem;
            }
            
            .hero-title {
                font-size: 2rem;
            }
            
            .section-title {
                font-size: 1.8rem;
            }
            
            .hero-image {
                height: 200px;
            }
            
            .terms-title {
                font-size: 1.3rem;
            }
            
            .back-to-top {
                width: 40px;
                height: 40px;
                bottom: 20px;
                right: 20px;
                font-size: 1.2rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Terms and Conditions</h1>
            <p class="subtitle">Please read these terms and conditions carefully before using our AI tools platform.</p>
        </header>
        
        <div class="terms-hero">
            <div class="hero-image"></div>
            <div class="hero-overlay">
                <h2 class="hero-title">Our Terms of Service</h2>
                <p class="hero-subtitle">These terms establish the rules and regulations for the use of our AI Tools Platform.</p>
            </div>
        </div>
        
        <div class="update-info">
            <i class="fas fa-clock"></i> Last Updated: <?php echo $lastUpdated; ?>
        </div>
        
        <div class="section">
            <div class="section-content">
                <div class="table-of-contents">
                    <h3 class="toc-title"><i class="fas fa-list"></i> Quick Navigation</h3>
                    <ul class="toc-list">
                        <li class="toc-item"><a href="#acceptance" class="toc-link">1. Acceptance of Terms</a></li>
                        <li class="toc-item"><a href="#changes" class="toc-link">2. Changes to Terms</a></li>
                        <li class="toc-item"><a href="#access" class="toc-link">3. Access and Use of Services</a></li>
                        <li class="toc-item"><a href="#accounts" class="toc-link">4. User Accounts</a></li>
                        <li class="toc-item"><a href="#intellectual" class="toc-link">5. Intellectual Property</a></li>
                        <li class="toc-item"><a href="#user-content" class="toc-link">6. User Content</a></li>
                        <li class="toc-item"><a href="#payment" class="toc-link">7. Payment Terms</a></li>
                        <li class="toc-item"><a href="#privacy" class="toc-link">8. Privacy Policy</a></li>
                        <li class="toc-item"><a href="#warranties" class="toc-link">9. Disclaimers and Warranties</a></li>
                        <li class="toc-item"><a href="#limitation" class="toc-link">10. Limitation of Liability</a></li>
                        <li class="toc-item"><a href="#indemnification" class="toc-link">11. Indemnification</a></li>
                        <li class="toc-item"><a href="#termination" class="toc-link">12. Termination</a></li>
                        <li class="toc-item"><a href="#governing-law" class="toc-link">13. Governing Law</a></li>
                        <li class="toc-item"><a href="#contact" class="toc-link">14. Contact Information</a></li>
                    </ul>
                </div>
                
                <div class="terms-section" id="acceptance">
                    <h3 class="terms-title">1. Acceptance of Terms</h3>
                    <div class="terms-content">
                        <p>By accessing or using our AI Tools Platform ("the Service"), you agree to be bound by these Terms and Conditions ("Terms"), our Privacy Policy, and any additional terms and conditions that may apply to specific sections of the Service. If you do not agree with any part of these terms, you may not access the Service.</p>
                        
                        <p>These Terms apply to all users of the Service, including without limitation users who are browsers, customers, merchants, and/or contributors of content.</p>
                    </div>
                </div>
                
                <div class="terms-section" id="changes">
                    <h3 class="terms-title">2. Changes to Terms</h3>
                    <div class="terms-content">
                        <p>We reserve the right to update, change, or replace any part of these Terms by posting updates or changes to our website. It is your responsibility to check our website periodically for changes. Your continued use of or access to the Service following the posting of any changes constitutes acceptance of those changes.</p>
                        
                        <p>We will provide notice of any significant changes to these Terms through a prominent notice on our website or by direct communication to users where appropriate.</p>
                    </div>
                </div>
                
                <div class="terms-section" id="access">
                    <h3 class="terms-title">3. Access and Use of Services</h3>
                    <div class="terms-content">
                        <p>Subject to these Terms, we grant you a limited, non-exclusive, non-transferable, and revocable license to access and use our Service for your personal or internal business purposes.</p>
                        
                        <p><span class="highlight">Prohibited Activities:</span> You agree not to engage in any of the following activities:</p>
                        
                        <ul>
                            <li>Using the Service in any way that violates any applicable federal, state, local, or international law or regulation</li>
                            <li>Attempting to interfere with, compromise the system integrity or security, or decipher any transmissions to or from the servers running the Service</li>
                            <li>Using the Service to upload, transmit, or distribute any viruses, malware, or other malicious code</li>
                            <li>Impersonating or attempting to impersonate our company, an employee, another user, or any other person or entity</li>
                            <li>Engaging in any conduct that restricts or inhibits anyone's use or enjoyment of the Service</li>
                            <li>Using the Service for any purpose that is unlawful or prohibited by these Terms</li>
                            <li>Using automated means, including spiders, robots, crawlers, or data mining tools to download data from the Service</li>
                            <li>Attempting to reverse engineer, decompile, or otherwise attempt to extract the source code of the Service</li>
                        </ul>
                        
                        <p>We reserve the right to terminate or restrict your access to the Service, without notice, for any violation of these Terms or for any other reason at our sole discretion.</p>
                    </div>
                </div>
                
                <div class="terms-section" id="accounts">
                    <h3 class="terms-title">4. User Accounts</h3>
                    <div class="terms-content">
                        <p>When you create an account with us, you must provide accurate, complete, and current information at all times. Failure to do so constitutes a breach of the Terms, which may result in immediate termination of your account.</p>
                        
                        <p>You are responsible for:</p>
                        <ul>
                            <li>Maintaining the confidentiality of your account and password</li>
                            <li>Restricting access to your computer or device</li>
                            <li>All activities that occur under your account or password</li>
                        </ul>
                        
                        <p>You must notify us immediately upon becoming aware of any breach of security or unauthorized use of your account. We will not be liable for any loss or damage arising from your failure to comply with this section.</p>
                        
                        <p>We reserve the right to refuse service, terminate accounts, remove or edit content, or cancel orders at our sole discretion.</p>
                    </div>
                </div>
                
                <div class="terms-section" id="intellectual">
                    <h3 class="terms-title">5. Intellectual Property</h3>
                    <div class="terms-content">
                        <p>The Service and its entire contents, features, and functionality (including but not limited to all information, software, text, displays, images, video, and audio, and the design, selection, and arrangement thereof) are owned by us, our licensors, or other providers of such material and are protected by copyright, trademark, patent, trade secret, and other intellectual property or proprietary rights laws.</p>
                        
                        <p><span class="highlight">Our Trademarks and Trade Dress:</span> Our name, logo, product and service names, designs, and slogans are trademarks of our company or its affiliates. You must not use such marks without our prior written permission. All other names, logos, product and service names, designs, and slogans on the Service are the trademarks of their respective owners.</p>
                        
                        <p><span class="highlight">License to Use:</span> Subject to your compliance with these Terms, we grant you a limited, non-exclusive, non-transferable, and revocable license to access and use the Service, and to download or print a reasonable number of copies of portions of the Service to which you have properly gained access, for your personal or internal business use.</p>
                        
                        <p><span class="highlight">Restrictions:</span> You must not reproduce, distribute, modify, create derivative works of, publicly display, publicly perform, republish, download, store, or transmit any of the material on our Service, except as generally and ordinarily permitted through the Service according to these Terms.</p>
                    </div>
                </div>
                
                <div class="terms-section" id="user-content">
                    <h3 class="terms-title">6. User Content</h3>
                    <div class="terms-content">
                        <p>The Service may allow you to post, submit, publish, display, or transmit content ("User Content"). By providing User Content to the Service, you grant us and our affiliates and service providers a worldwide, non-exclusive, royalty-free, perpetual, irrevocable, and fully sublicensable right to use, reproduce, modify, adapt, publish, translate, create derivative works from, distribute, and display such User Content in connection with providing and promoting the Service.</p>
                        
                        <p>You represent and warrant that:</p>
                        <ul>
                            <li>You own or control all rights in and to the User Content you provide</li>
                            <li>All User Content is accurate and not misleading</li>
                            <li>Use of the User Content does not violate these Terms or any applicable laws</li>
                            <li>The User Content will not cause injury to any person or entity</li>
                        </ul>
                        
                        <p>We are not responsible or liable to any third party for the content or accuracy of any User Content posted by you or any other user of the Service.</p>
                        
                        <p>We have the right to:</p>
                        <ul>
                            <li>Remove or refuse to post any User Content for any reason</li>
                            <li>Take any action with respect to User Content that we deem necessary or appropriate</li>
                            <li>Disclose your identity or other information about you to any third party who claims that material posted by you violates their rights</li>
                            <li>Terminate your access to all or part of the Service for any violation of these Terms</li>
                        </ul>
                    </div>
                </div>
                
                <div class="terms-section" id="payment">
                    <h3 class="terms-title">7. Payment Terms</h3>
                    <div class="terms-content">
                        <p>Some aspects of the Service may be provided for a fee. You will be required to select a payment plan and provide accurate information regarding your credit card or other payment method.</p>
                        
                        <p>You agree to pay all fees and charges incurred in connection with your use of the Service at the rates in effect when the charges were incurred. Unless otherwise stated, all fees are quoted in U.S. Dollars.</p>
                        
                        <p><span class="highlight">Subscription Terms:</span> For subscription-based services:</p>
                        <ul>
                            <li>Subscription fees are billed in advance on a monthly, annual, or as otherwise specified basis</li>
                            <li>Your subscription will automatically renew at the end of each subscription period unless you cancel at least 24 hours before the end of the current period</li>
                            <li>You can cancel your subscription at any time through your account settings or by contacting our customer support team</li>
                            <li>No refunds or credits will be provided for partial subscription periods or unused portions of subscription periods</li>
                        </ul>
                        
                        <p><span class="highlight">Price Changes:</span> We reserve the right to adjust pricing for our Service or any components thereof in any manner and at any time as we may determine in our sole and absolute discretion. We will provide notice of any price changes by posting the new prices on the Service and/or by sending you an email notification.</p>
                        
                        <p><span class="highlight">Taxes:</span> You are responsible for all taxes (excluding taxes on our net income) related to your use of the Service. If we are obligated to collect or pay taxes in connection with your use of the Service, the taxes will be charged to you.</p>
                    </div>
                </div>
                
                <div class="terms-section" id="privacy">
                    <h3 class="terms-title">8. Privacy Policy</h3>
                    <div class="terms-content">
                        <p>Your use of the Service is also governed by our Privacy Policy, which is incorporated into these Terms by reference. Our Privacy Policy describes how we collect, use, and share information about you when you use our Service.</p>
                        
                        <p>By using the Service, you consent to our collection, use, and sharing of information as described in our Privacy Policy. If you do not agree with our Privacy Policy, please do not use the Service.</p>
                        
                        <p>We take the protection of your personal information seriously and implement appropriate technical and organizational measures to protect your personal information against unauthorized or unlawful processing and against accidental loss, destruction, or damage.</p>
                    </div>
                </div>
                
                <div class="terms-section" id="warranties">
                    <h3 class="terms-title">9. Disclaimers and Warranties</h3>
                    <div class="terms-content">
                        <p>THE SERVICE IS PROVIDED ON AN "AS IS" AND "AS AVAILABLE" BASIS, WITHOUT ANY WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED. NEITHER OUR COMPANY NOR ANY PERSON ASSOCIATED WITH OUR COMPANY MAKES ANY WARRANTY OR REPRESENTATION WITH RESPECT TO THE COMPLETENESS, SECURITY, RELIABILITY, QUALITY, ACCURACY, OR AVAILABILITY OF THE SERVICE.</p>
                        
                        <p>WITHOUT LIMITING THE FOREGOING, NEITHER OUR COMPANY NOR ANYONE ASSOCIATED WITH OUR COMPANY REPRESENTS OR WARRANTS THAT THE SERVICE WILL BE ACCURATE, RELIABLE, ERROR-FREE, OR UNINTERRUPTED, THAT DEFECTS WILL BE CORRECTED, THAT THE SERVICE OR THE SERVER THAT MAKES IT AVAILABLE ARE FREE OF VIRUSES OR OTHER HARMFUL COMPONENTS, OR THAT THE SERVICE WILL OTHERWISE MEET YOUR NEEDS OR EXPECTATIONS.</p>
                        
                        <p>TO THE FULLEST EXTENT PROVIDED BY LAW, WE HEREBY DISCLAIM ALL WARRANTIES OF ANY KIND, WHETHER EXPRESS OR IMPLIED, STATUTORY OR OTHERWISE, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OF MERCHANTABILITY, NON-INFRINGEMENT, AND FITNESS FOR PARTICULAR PURPOSE.</p>
                        
                        <p>THE FOREGOING DOES NOT AFFECT ANY WARRANTIES WHICH CANNOT BE EXCLUDED OR LIMITED UNDER APPLICABLE LAW.</p>
                    </div>
                </div>
                
                <div class="terms-section" id="limitation">
                    <h3 class="terms-title">10. Limitation of Liability</h3>
                    <div class="terms-content">
                        <p>TO THE FULLEST EXTENT PROVIDED BY LAW, IN NO EVENT WILL OUR COMPANY, ITS AFFILIATES, OR THEIR LICENSORS, SERVICE PROVIDERS, EMPLOYEES, AGENTS, OFFICERS, OR DIRECTORS BE LIABLE FOR DAMAGES OF ANY KIND, UNDER ANY LEGAL THEORY, ARISING OUT OF OR IN CONNECTION WITH YOUR USE, OR INABILITY TO USE, THE SERVICE, INCLUDING ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES, INCLUDING BUT NOT LIMITED TO, PERSONAL INJURY, PAIN AND SUFFERING, EMOTIONAL DISTRESS, LOSS OF REVENUE, LOSS OF PROFITS, LOSS OF BUSINESS OR ANTICIPATED SAVINGS, LOSS OF USE, LOSS OF GOODWILL, LOSS OF DATA, AND WHETHER CAUSED BY TORT (INCLUDING NEGLIGENCE), BREACH OF CONTRACT, OR OTHERWISE, EVEN IF FORESEEABLE.</p>
                        
                        <p>THE FOREGOING DOES NOT AFFECT ANY LIABILITY WHICH CANNOT BE EXCLUDED OR LIMITED UNDER APPLICABLE LAW.</p>
                        
                        <p>IN ANY EVENT, OUR MAXIMUM LIABILITY TO YOU SHALL NOT EXCEED THE AMOUNT YOU HAVE PAID TO US FOR THE SERVICE IN THE TWELVE (12) MONTHS PRECEDING THE EVENT GIVING RISE TO THE LIABILITY.</p>
                    </div>
                </div>
                
                <div class="terms-section" id="indemnification">
                    <h3 class="terms-title">11. Indemnification</h3>
                    <div class="terms-content">
                        <p>You agree to defend, indemnify, and hold harmless our company, its affiliates, licensors, and service providers, and its and their respective officers, directors, employees, contractors, agents, licensors, suppliers, successors, and assigns from and against any claims, liabilities, damages, judgments, awards, losses, costs, expenses, or fees (including reasonable attorneys' fees) arising out of or relating to:</p>
                        
                        <ul>
                            <li>Your violation of these Terms</li>
                            <li>Your use of the Service, including, but not limited to, your User Content</li>
                            <li>Any use of the Service's content, services, or products other than as expressly authorized in these Terms</li>
                            <li>Your violation of any third-party right, including without limitation any intellectual property right, publicity, confidentiality, property, or privacy right</li>
                        </ul>
                    </div>
                </div>
                
                <div class="terms-section" id="termination">
                    <h3 class="terms-title">12. Termination</h3>
                    <div class="terms-content">
                        <p>We may terminate or suspend your account and bar access to the Service immediately, without prior notice or liability, under our sole discretion, for any reason whatsoever and without limitation, including but not limited to a breach of the Terms.</p>
                        
                        <p>If you wish to terminate your account, you may simply discontinue using the Service or contact us to request account deletion.</p>
                        
                        <p>All provisions of the Terms which by their nature should survive termination shall survive termination, including, without limitation, ownership provisions, warranty disclaimers, indemnity, and limitations of liability.</p>
                    </div>
                </div>
                
                <div class="terms-section" id="governing-law">
                    <h3 class="terms-title">13. Governing Law</h3>
                    <div class="terms-content">
                        <p>These Terms shall be governed and construed in accordance with the laws of [Your Country/State], without regard to its conflict of law provisions.</p>
                        
                        <p>Our failure to enforce any right or provision of these Terms will not be considered a waiver of those rights. If any provision of these Terms is held to be invalid or unenforceable by a court, the remaining provisions of these Terms will remain in effect.</p>
                        
                        <p><span class="highlight">Dispute Resolution:</span> Any dispute arising out of or relating to these Terms, or the breach thereof, shall be settled by arbitration administered by [Arbitration Organization] in accordance with its applicable rules. The number of arbitrators shall be one. The place of arbitration shall be [City, State/Country]. The language of the arbitration shall be English.</p>
                    </div>
                </div>
                
                <div class="terms-section" id="contact">
                    <h3 class="terms-title">14. Contact Information</h3>
                    <div class="terms-content">
                        <p>If you have any questions about these Terms, please contact us at:</p>
                        
                        <p>
                            <strong>Email:</strong> support@aitools-platform.com<br>
                            <strong>Address:</strong> 123 AI Avenue, Tech City, TC 12345<br>
                            <strong>Phone:</strong> (123) 456-7890
                        </p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="cta-section">
            <h2 class="cta-title">Have Questions About Our Terms?</h2>
            <p class="cta-text">Our team is here to help you understand our terms and conditions and answer any questions you may have.</p>
            <a href="/page/contact" class="cta-button">Contact Our Team</a>
        </div>
    </div>
    
    <div class="back-to-top" id="backToTop">
        <i class="fas fa-arrow-up"></i>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Back to top button functionality
            const backToTopButton = document.getElementById('backToTop');
            
            window.addEventListener('scroll', function() {
                if (window.pageYOffset > 300) {
                    backToTopButton.classList.add('visible');
                } else {
                    backToTopButton.classList.remove('visible');
                }
            });
            
            backToTopButton.addEventListener('click', function() {
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            });
            
            // Smooth scrolling for table of contents links
            const tocLinks = document.querySelectorAll('.toc-link');
            
            tocLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    const targetId = this.getAttribute('href');
                    const targetElement = document.querySelector(targetId);
                    
                    window.scrollTo({
                        top: targetElement.offsetTop - 100,
                        behavior: 'smooth'
                    });
                });
            });
        });
    </script>
</body>
</html>