
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php include_once ('../../private/favicon.php'); ?>
  <title><?php echo $pageTitle; ?></title>
  <link rel="stylesheet" href="../assets/css/footer.css">
  <style>
    :root {
      --primary: #3b82f6;
      --primary-dark: #2563eb;
      --secondary: #10b981;
      --dark: #1f2937;
      --light: #f9fafb;
      --gray: #6b7280;
      --light-gray: #e5e7eb;
      --error: #ef4444;
    }
    
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
    }
    
    body {
      background-color: var(--light);
      color: var(--dark);
      line-height: 1.6;
    }
    
    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 2rem;
    }
    
    header {
      background-color: white;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
      padding: 1.5rem 0;
    }
    
    .apply-header {
      padding: 4rem 0;
      background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
      color: white;
    }
    
    .apply-header h1 {
      font-size: 2.5rem;
      margin-bottom: 0.5rem;
    }
    
    .breadcrumbs {
      display: flex;
      align-items: center;
      margin-bottom: 1.5rem;
      font-size: 0.9rem;
    }
    
    .breadcrumbs a {
      color: rgba(255, 255, 255, 0.8);
      text-decoration: none;
    }
    
    .breadcrumbs a:hover {
      color: white;
    }
    
    .breadcrumbs span {
      margin: 0 0.5rem;
      color: rgba(255, 255, 255, 0.6);
    }
    
    .apply-content {
      padding: 4rem 0;
    }
    
    .form-container {
      max-width: 800px;
      margin: 0 auto;
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
      padding: 2rem;
    }
    
    .form-section {
      margin-bottom: 2rem;
      padding-bottom: 2rem;
      border-bottom: 1px solid var(--light-gray);
    }
    
    .form-section:last-child {
      border-bottom: none;
      margin-bottom: 0;
      padding-bottom: 0;
    }
    
    .form-section-title {
      font-size: 1.25rem;
      font-weight: 600;
      margin-bottom: 1.5rem;
      color: var(--dark);
    }
    
    .form-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1.5rem;
      margin-bottom: 1.5rem;
    }
    
    .form-group {
      margin-bottom: 1.5rem;
    }
    
    .form-group label {
      display: block;
      margin-bottom: 0.5rem;
      font-weight: 500;
      color: var(--dark);
    }
    
    .form-control {
      width: 100%;
      padding: 0.75rem;
      border: 1px solid var(--light-gray);
      border-radius: 0.375rem;
      font-size: 1rem;
      color: var(--dark);
      transition: border-color 0.3s;
    }
    
    .form-control:focus {
      outline: none;
      border-color: var(--primary);
      box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
    }
    
    textarea.form-control {
      min-height: 150px;
      resize: vertical;
    }
    
    .file-upload {
      position: relative;
      overflow: hidden;
      margin-top: 0.5rem;
    }
    
    .file-upload .btn {
      display: inline-block;
      padding: 0.75rem 1.5rem;
      font-weight: 500;
      border-radius: 0.375rem;
      text-align: center;
      cursor: pointer;
      transition: all 0.3s;
      background-color: #f9f9f9;
      border: 1px solid var(--light-gray);
      color: var(--dark);
    }
    
    .file-upload input[type=file] {
      position: absolute;
      left: 0;
      top: 0;
      opacity: 0;
      width: 100%;
      height: 100%;
      cursor: pointer;
    }
    
    .file-name {
      margin-left: 1rem;
      font-size: 0.9rem;
      color: var(--gray);
    }
    
    .required::after {
      content: '*';
      color: var(--error);
      margin-left: 0.25rem;
    }
    
    .form-help {
      font-size: 0.85rem;
      color: var(--gray);
      margin-top: 0.5rem;
    }
    
    .checkbox-group {
      margin-top: 1rem;
    }
    
    .checkbox-label {
      display: flex;
      align-items: center;
      margin-bottom: 0.75rem;
      cursor: pointer;
    }
    
    .checkbox-label input {
      margin-right: 0.75rem;
    }
    
    .btn {
      display: inline-block;
      padding: 0.75rem 1.5rem;
      font-weight: 500;
      border-radius: 0.375rem;
      text-align: center;
      cursor: pointer;
      transition: all 0.3s;
      border: none;
      font-size: 1rem;
    }
    
    .btn-primary {
      background-color: var(--primary);
      color: white;
    }
    
    .btn-primary:hover {
      background-color: var(--primary-dark);
    }
    
    .btn-outline {
      border: 1px solid var(--primary);
      color: var(--primary);
      background-color: transparent;
      margin-right: 1rem;
    }
    
    .btn-outline:hover {
      background-color: var(--primary);
      color: white;
    }
    
    .form-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 2rem;
    }
    
    .text-required {
      font-size: 0.85rem;
      color: var(--gray);
    }
    
    .text-required span {
      color: var(--error);
    }
    
    .alert {
      padding: 1rem;
      border-radius: 0.375rem;
      margin-bottom: 1.5rem;
    }
    
    .alert-success {
      background-color: #d1fae5;
      color: #065f46;
      border: 1px solid #a7f3d0;
    }
    
    .alert-error {
      background-color: #fee2e2;
      color: #b91c1c;
      border: 1px solid #fecaca;
    }
    
    @media (max-width: 768px) {
      .form-row {
        grid-template-columns: 1fr;
        gap: 0;
      }
      
      .form-footer {
        flex-direction: column;
        align-items: flex-start;
      }
      
      .text-required {
        margin-bottom: 1rem;
      }
      
      .apply-header h1 {
        font-size: 2rem;
      }
    }
  </style>
</head>
<body>
  <?php
  // In a real application, you would fetch job data from a database based on the ID
  $jobId = isset($_GET['id']) ? intval($_GET['id']) : 0;
  
  // Mock job data array - in a real app, this would come from a database
  $jobs = [
      1 => [
          'id' => 1,
          'title' => 'AI Solutions Architect',
          'location' => 'San Francisco, CA',
          'type' => 'fulltime',
          'type_label' => 'Full-time'
      ],
      2 => [
          'id' => 2,
          'title' => 'Machine Learning Engineer',
          'location' => 'Remote',
          'type' => 'remote',
          'type_label' => 'Remote'
      ],
      // Add placeholders for jobs 3-6
      3 => [
          'id' => 3,
          'title' => 'AI Product Manager',
          'location' => 'New York, NY',
          'type' => 'fulltime',
          'type_label' => 'Full-time'
      ],
      4 => [
          'id' => 4,
          'title' => 'NLP Specialist',
          'location' => 'Austin, TX',
          'type' => 'fulltime',
          'type_label' => 'Full-time'
      ],
      5 => [
          'id' => 5,
          'title' => 'AI Integration Specialist',
          'location' => 'Remote',
          'type' => 'remote',
          'type_label' => 'Remote'
      ],
      6 => [
          'id' => 6,
          'title' => 'Frontend Developer (AI Tools)',
          'location' => 'Boston, MA',
          'type' => 'contract',
          'type_label' => 'Contract'
      ]
  ];
  
  // If job ID doesn't exist, redirect to careers page
  if (!isset($jobs[$jobId])) {
      header('Location: careers');
      exit;
  }
  
  $job = $jobs[$jobId];
  
  // Initialize variables for form processing
  $formSubmitted = false;
  $formError = false;
  $errorMessage = '';
  
  // Process form submission
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
      // In a real application, you would validate inputs here
      $requiredFields = ['firstName', 'lastName', 'email', 'phone'];
      $missingFields = [];
      
      foreach ($requiredFields as $field) {
          if (empty($_POST[$field])) {
              $missingFields[] = $field;
          }
      }
      
      if (!empty($missingFields)) {
          $formError = true;
          $errorMessage = 'Please fill in all required fields.';
      } elseif (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
          $formError = true;
          $errorMessage = 'Please enter a valid email address.';
      } else {
          // In a real application, you would process form data here
          // For example, save to database, send emails, etc.
          $formSubmitted = true;
      }
  }
  ?>
  
  <section class="apply-header">
    <div class="container">
      <div class="breadcrumbs">
        <a href="/">Home</a>
        <span>/</span>
        <a href="careers">Careers</a>
        <span>/</span>
        <a href="job-detail?id=<?php echo $job['id']; ?>"><?php echo htmlspecialchars($job['title']); ?></a>
        <span>/</span>
        Apply
      </div>
      <h1>Apply for <?php echo htmlspecialchars($job['title']); ?></h1>
      <p>Submit your application for this position at our company</p>
    </div>
  </section>
  
  <section class="apply-content">
    <div class="container">
      <?php if ($formSubmitted): ?>
        <div class="form-container">
          <div class="alert alert-success">
            <h3>Application Submitted!</h3>
            <p>Thank you for your interest in the <?php echo htmlspecialchars($job['title']); ?> position. We have received your application and will review it shortly. If your qualifications match our requirements, we will contact you for the next steps in the hiring process.</p>
            <p style="margin-top: 1rem;"><a href="careers" class="btn btn-primary">Return to Careers</a></p>
          </div>
        </div>
      <?php else: ?>
        <div class="form-container">
          <?php if ($formError): ?>
            <div class="alert alert-error">
              <?php echo htmlspecialchars($errorMessage); ?>
            </div>
          <?php endif; ?>
          
          <form action="apply?id=<?php echo $job['id']; ?>" method="POST" enctype="multipart/form-data">
            <div class="form-section">
              <h3 class="form-section-title">Personal Information</h3>
              <div class="form-row">
                <div class="form-group">
                  <label for="firstName" class="required">First Name</label>
                  <input type="text" class="form-control" id="firstName" name="firstName" required>
                </div>
                <div class="form-group">
                  <label for="lastName" class="required">Last Name</label>
                  <input type="text" class="form-control" id="lastName" name="lastName" required>
                </div>
              </div>
              <div class="form-row">
                <div class="form-group">
                  <label for="email" class="required">Email Address</label>
                  <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <div class="form-group">
                  <label for="phone" class="required">Phone Number</label>
                  <input type="tel" class="form-control" id="phone" name="phone" required>
                </div>
              </div>
              <div class="form-group">
                <label for="location">Current Location</label>
                <input type="text" class="form-control" id="location" name="location" placeholder="City, State/Province, Country">
              </div>
            </div>
            
            <div class="form-section">
              <h3 class="form-section-title">Professional Information</h3>
              <div class="form-group">
                <label for="resume" class="required">Resume/CV</label>
                <div class="file-upload">
                  <span class="btn">Choose File</span>
                  <input type="file" id="resume" name="resume" accept=".pdf,.doc,.docx" required>
                  <span class="file-name" id="resumeFileName">No file chosen</span>
                </div>
                <div class="form-help">Accepted formats: PDF, DOC, DOCX. Maximum file size: 5MB.</div>
              </div>
              
              <div class="form-group">
                <label for="portfolio">Portfolio URL</label>
                <input type="url" class="form-control" id="portfolio" name="portfolio" placeholder="https://yourportfolio.com">
                <div class="form-help">If applicable, please provide a link to your portfolio, GitHub, LinkedIn, or other professional profiles.</div>
              </div>
              
              <div class="form-group">
                <label for="experience" class="required">Years of Experience</label>
                <select class="form-control" id="experience" name="experience" required>
                  <option value="">Select years of experience</option>
                  <option value="0-1">Less than 1 year</option>
                  <option value="1-3">1-3 years</option>
                  <option value="3-5">3-5 years</option>
                  <option value="5-10">5-10 years</option>
                  <option value="10+">10+ years</option>
                </select>
              </div>
            </div>
            
            <div class="form-section">
              <h3 class="form-section-title">Additional Information</h3>
              <div class="form-group">
                <label for="coverLetter">Cover Letter / Introduction</label>
                <textarea class="form-control" id="coverLetter" name="coverLetter" placeholder="Tell us why you're interested in this position and why you would be a good fit..."></textarea>
              </div>
              
              <div class="form-group">
                <label for="salary">Expected Salary (Optional)</label>
                <input type="text" class="form-control" id="salary" name="salary" placeholder="e.g. $80,000 - $100,000">
              </div>
              
              <div class="form-group">
                <label for="startDate">Earliest Start Date</label>
                <input type="date" class="form-control" id="startDate" name="startDate">
              </div>
              
              <div class="form-group">
                <label>How did you hear about us?</label>
                <select class="form-control" id="source" name="source">
                  <option value="">Select an option</option>
                  <option value="job-board">Job Board</option>
                  <option value="company-website">Company Website</option>
                  <option value="linkedin">LinkedIn</option>
                  <option value="referral">Employee Referral</option>
                  <option value="social-media">Social Media</option>
                  <option value="other">Other</option>
                </select>
              </div>
            </div>
            
            <div class="form-section">
              <h3 class="form-section-title">Legal Information</h3>
              <div class="checkbox-group">
                <label class="checkbox-label">
                  <input type="checkbox" name="terms" required>
                  I certify that the information provided in this application is true and complete to the best of my knowledge.
                </label>
                <label class="checkbox-label">
                  <input type="checkbox" name="privacy" required>
                  I understand and agree to the company's privacy policy regarding the collection and use of my personal information.
                </label>
                <label class="checkbox-label">
                  <input type="checkbox" name="updates">
                  I would like to receive updates about other job opportunities and company news.
                </label>
              </div>
            </div>
            
            <div class="form-footer">
              <p class="text-required"><span>*</span> Required fields</p>
              <div>
                <a href="job-detail?id=<?php echo $job['id']; ?>" class="btn btn-outline">Cancel</a>
                <button type="submit" class="btn btn-primary">Submit Application</button>
              </div>
            </div>
          </form>
        </div>
      <?php endif; ?>
    </div>
  </section>

  <script>
    // Script to display selected file name
    document.getElementById('resume').addEventListener('change', function(e) {
      var fileName = e.target.files[0] ? e.target.files[0].name : 'No file chosen';
      document.getElementById('resumeFileName').textContent = fileName;
    });
  </script>

</body>
</html>