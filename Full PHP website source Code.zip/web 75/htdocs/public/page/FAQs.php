<?php
// Set page variables
$pageTitle = "Frequently Asked Questions | AI Tools Platform";
$currentYear = date('Y');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include_once ('../../private/favicon.php'); ?>
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4F46E5;
            --secondary-color: #7C3AED;
            --dark-color: #1E293B;
            --light-color: #F8FAFC;
            --accent-color: #06B6D4;
            --success-color: #10B981;
            --warning-color: #F59E0B;
            --border-radius: 8px;
            --box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        }
        
        body {
            background-color: var(--light-color);
            color: var(--dark-color);
            line-height: 1.6;
        }
        
        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        header {
            margin-bottom: 3rem;
            text-align: center;
        }
        
        h1 {
            font-size: 3rem;
            margin-bottom: 0.5rem;
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-fill-color: transparent;
        }
        
        .subtitle {
            font-size: 1.2rem;
            color: #64748B;
            margin-bottom: 1.5rem;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }
        
        .faq-hero {
            position: relative;
            background-color: #fff;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            overflow: hidden;
            margin-bottom: 4rem;
        }
        
        .hero-image {
            width: 100%;
            height: 300px;
            object-fit: cover;
            background: linear-gradient(135deg, #4F46E5, #7C3AED);
            position: relative;
        }
        
        .hero-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(30, 41, 59, 0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            text-align: center;
            padding: 2rem;
        }
        
        .hero-title {
            color: white;
            font-size: 2.5rem;
            margin-bottom: 1rem;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }
        
        .hero-subtitle {
            color: rgba(255, 255, 255, 0.9);
            font-size: 1.25rem;
            max-width: 800px;
        }
        
        .section {
            margin-bottom: 4rem;
        }
        
        .section-title {
            font-size: 2rem;
            margin-bottom: 1.5rem;
            color: var(--dark-color);
            position: relative;
            padding-bottom: 0.5rem;
            display: inline-block;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 60%;
            height: 3px;
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            border-radius: 3px;
        }
        
        .section-content {
            background-color: #fff;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 2rem;
        }
        
        .faq-container {
            margin-top: 2rem;
        }
        
        .faq-item {
            margin-bottom: 1rem;
            border-radius: var(--border-radius);
            background-color: #fff;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
            overflow: hidden;
        }
        
        .faq-question {
            padding: 1.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: pointer;
            font-weight: 600;
            color: var(--dark-color);
            background-color: #fff;
            transition: background-color 0.3s ease;
        }
        
        .faq-question:hover {
            background-color: #F8FAFC;
        }
        
        .faq-question i {
            transform: rotate(0deg);
            transition: transform 0.3s ease;
        }
        
        .faq-answer {
            height: 0;
            overflow: hidden;
            transition: height 0.3s ease;
        }
        
        .faq-answer-inner {
            padding: 0 1.5rem 1.5rem 1.5rem;
            color: #4B5563;
        }
        
        .faq-item.active .faq-question {
            background-color: #F8FAFC;
        }
        
        .faq-item.active .faq-question i {
            transform: rotate(180deg);
        }
        
        .faq-item.active .faq-answer {
            height: auto;
            padding: 0 1.5rem 1.5rem;
        }
        
        .faq-category {
            margin-bottom: 3rem;
        }
        
        .category-title {
            font-size: 1.5rem;
            margin-bottom: 1.5rem;
            color: var(--dark-color);
            position: relative;
            padding-bottom: 0.5rem;
            display: inline-block;
        }
        
        .category-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40%;
            height: 2px;
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            border-radius: 2px;
        }
        
        .search-container {
            margin-bottom: 2rem;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }
        
        .search-input {
            width: 100%;
            padding: 1rem 1.5rem;
            border-radius: 30px;
            border: 1px solid #E2E8F0;
            font-size: 1rem;
            outline: none;
            transition: all 0.3s ease;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }
        
        .search-input:focus {
            border-color: var(--primary-color);
            box-shadow: 0 1px 6px rgba(79, 70, 229, 0.2);
        }
        
        .faq-topics {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            margin-bottom: 2rem;
            justify-content: center;
        }
        
        .faq-topic {
            padding: 0.5rem 1.5rem;
            background-color: #fff;
            border-radius: 20px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
            color: var(--dark-color);
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .faq-topic:hover, .faq-topic.active {
            background-color: var(--primary-color);
            color: white;
            box-shadow: 0 2px 5px rgba(79, 70, 229, 0.2);
        }
        
        .cta-section {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            padding: 3rem 2rem;
            border-radius: var(--border-radius);
            text-align: center;
            margin-top: 2rem;
            color: white;
        }
        
        .cta-title {
            font-size: 2rem;
            margin-bottom: 1rem;
        }
        
        .cta-text {
            margin-bottom: 1.5rem;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
        }
        
        .cta-button {
            display: inline-block;
            background-color: white;
            color: var(--primary-color);
            padding: 0.75rem 2rem;
            border-radius: 30px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        .cta-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
        }
        
        .contact-info {
            text-align: center;
            margin-top: 3rem;
            padding: 2rem;
            background-color: #fff;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
        }
        
        .contact-title {
            font-size: 1.5rem;
            margin-bottom: 1rem;
            color: var(--dark-color);
        }
        
        .contact-text {
            color: #4B5563;
            margin-bottom: 1.5rem;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }
        
        .contact-options {
            display: flex;
            justify-content: center;
            gap: 2rem;
            flex-wrap: wrap;
        }
        
        .contact-option {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 1.5rem;
            background-color: #F8FAFC;
            border-radius: var(--border-radius);
            min-width: 200px;
            transition: all 0.3s ease;
        }
        
        .contact-option:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        
        .contact-icon {
            font-size: 2rem;
            margin-bottom: 1rem;
            color: var(--primary-color);
        }
        
        .contact-label {
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: var(--dark-color);
        }
        
        .contact-value {
            color: #4B5563;
        }
        
        .contact-value a {
            color: var(--primary-color);
            text-decoration: none;
            transition: color 0.3s ease;
        }
        
        .contact-value a:hover {
            color: var(--secondary-color);
        }
        
        @media (max-width: 768px) {
            .container {
                padding: 1rem;
            }
            
            h1 {
                font-size: 2.2rem;
            }
            
            .hero-title {
                font-size: 2rem;
            }
            
            .section-title {
                font-size: 1.8rem;
            }
            
            .hero-image {
                height: 250px;
            }
            
            .contact-options {
                flex-direction: column;
                align-items: center;
            }
            
            .contact-option {
                width: 100%;
                max-width: 300px;
            }
            
            .cta-title {
                font-size: 1.6rem;
            }
            
            .cta-text {
                font-size: 0.95rem;
            }
        }
        
        @media (max-width: 480px) {
            .hero-title {
                font-size: 1.8rem;
            }
            
            .hero-subtitle {
                font-size: 1rem;
            }
            
            .hero-image {
                height: 220px;
            }
            
            .section-title {
                font-size: 1.6rem;
            }
            
            .faq-topics {
                gap: 0.5rem;
            }
            
            .faq-topic {
                padding: 0.4rem 1rem;
                font-size: 0.9rem;
            }
            
            .search-input {
                padding: 0.8rem 1.2rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Frequently Asked Questions</h1>
            <p class="subtitle">Find answers to the most common questions about our AI platform, features, and services.</p>
        </header>
        
        <div class="faq-hero">
            <div class="hero-image"></div>
            <div class="hero-overlay">
                <h2 class="hero-title">How Can We Help You?</h2>
                <p class="hero-subtitle">Browse through our comprehensive FAQ or use the search function to find specific answers quickly.</p>
            </div>
        </div>
        
        <div class="search-container">
            <input type="text" class="search-input" placeholder="Search for questions..." id="faqSearch">
        </div>
        
        <div class="faq-topics">
            <div class="faq-topic active" data-category="all">All Questions</div>
            <div class="faq-topic" data-category="general">General</div>
            <div class="faq-topic" data-category="features">Features & Capabilities</div>
            <div class="faq-topic" data-category="pricing">Pricing & Plans</div>
            <div class="faq-topic" data-category="security">Security & Privacy</div>
            <div class="faq-topic" data-category="technical">Technical Support</div>
        </div>
        
        <section class="section">
            <h2 class="section-title">Frequently Asked Questions</h2>
            <div class="section-content">
                <div class="faq-category" data-category="general">
                    <h3 class="category-title">General Questions</h3>
                    <div class="faq-container">
                        <div class="faq-item active">
                            <div class="faq-question">
                                <span>What is the AI Tools Platform?</span>
                                <i class="fas fa-chevron-down"></i>
                            </div>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    The AI Tools Platform is a comprehensive suite of artificial intelligence solutions designed to help businesses of all sizes leverage the power of AI without requiring specialized technical expertise. Our platform offers tools for natural language processing, predictive analytics, computer vision, conversational AI, and more—all accessible through intuitive interfaces and seamless integrations with your existing systems.
                                </div>
                            </div>
                        </div>
                        
                        <div class="faq-item">
                            <div class="faq-question">
                                <span>How does your AI platform differ from competitors?</span>
                                <i class="fas fa-chevron-down"></i>
                            </div>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    Our AI platform stands out through its combination of powerful capabilities and user-friendly design. Unlike many competitors that require deep technical knowledge, our tools are accessible to users of all skill levels. We also offer more comprehensive integration options, superior customization capabilities, and a more transparent pricing model with no hidden costs. Our dedicated customer success team ensures you get maximum value from the platform, providing personalized guidance and support throughout your AI journey.
                                </div>
                            </div>
                        </div>
                        
                        <div class="faq-item">
                            <div class="faq-question">
                                <span>Do I need to have AI expertise to use your platform?</span>
                                <i class="fas fa-chevron-down"></i>
                            </div>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    No technical expertise is required to use our AI platform. We've designed it with intuitive interfaces and user-friendly tools that enable anyone in your organization to leverage the power of AI. For more advanced customization, we offer no-code builders and integration options that don't require programming knowledge. Our platform democratizes access to AI technology, making it accessible to users regardless of their technical background.
                                </div>
                            </div>
                        </div>
                        
                        <div class="faq-item">
                            <div class="faq-question">
                                <span>How can I get started with the platform?</span>
                                <i class="fas fa-chevron-down"></i>
                            </div>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    Getting started with our AI platform is simple. You can sign up for a free trial on our website, which gives you access to core features for 14 days. Once registered, you'll have access to our quickstart guides, video tutorials, and knowledge base. Our onboarding team will reach out to help you set up your account, understand your specific needs, and guide you through the initial implementation. For enterprise customers, we offer dedicated onboarding services to ensure a smooth transition.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="faq-category" data-category="features">
                    <h3 class="category-title">Features & Capabilities</h3>
                    <div class="faq-container">
                        <div class="faq-item">
                            <div class="faq-question">
                                <span>What specific AI capabilities does your platform offer?</span>
                                <i class="fas fa-chevron-down"></i>
                            </div>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    Our platform offers a comprehensive suite of AI capabilities including: Natural Language Processing (content generation, summarization, sentiment analysis, translation), Predictive Analytics (forecasting, anomaly detection, pattern recognition), Computer Vision (image recognition, object detection, visual search), Conversational AI (chatbots, virtual assistants, voice interfaces), Intelligent Automation (process automation, workflow optimization), and Recommendation Systems (personalized recommendations, content curation). These capabilities are available through various tools and APIs that can be combined to create powerful, custom solutions.
                                </div>
                            </div>
                        </div>
                        
                        <div class="faq-item">
                            <div class="faq-question">
                                <span>Can I customize the AI models for my specific business needs?</span>
                                <i class="fas fa-chevron-down"></i>
                            </div>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    Yes, customization is a core strength of our platform. While our pre-trained models work effectively out of the box, we offer several customization options. Professional and Enterprise plans include the ability to fine-tune models with your own data, create custom workflows, and develop specialized AI solutions for your unique use cases. Enterprise customers also have access to custom model training services where our AI specialists work directly with your team to build bespoke models tailored to your specific requirements.
                                </div>
                            </div>
                        </div>
                        
                        <div class="faq-item">
                            <div class="faq-question">
                                <span>What languages does your natural language processing support?</span>
                                <i class="fas fa-chevron-down"></i>
                            </div>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    Our NLP tools support over 100 languages, with comprehensive capabilities in major languages like English, Spanish, French, German, Chinese, Japanese, and Arabic. Advanced features like sentiment analysis, entity recognition, and content generation are fully supported in 25+ languages. Translation services cover 100+ language pairs with high accuracy. We regularly expand our language support based on customer needs and the latest advancements in multilingual AI.
                                </div>
                            </div>
                        </div>
                        
                        <div class="faq-item">
                            <div class="faq-question">
                                <span>How accurate are your predictive analytics tools?</span>
                                <i class="fas fa-chevron-down"></i>
                            </div>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    The accuracy of our predictive analytics tools varies by use case and data quality, but our customers typically report 80-95% accuracy in forecasting scenarios. Factors affecting accuracy include historical data volume, data quality, and the complexity of the patterns being predicted. Our platform uses ensemble methods and continuous learning to improve accuracy over time. We provide transparency into model confidence and prediction intervals, allowing you to make informed decisions. For specialized use cases, our team can work with you to optimize models for maximum accuracy in your specific context.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="faq-category" data-category="pricing">
                    <h3 class="category-title">Pricing & Plans</h3>
                    <div class="faq-container">
                        <div class="faq-item">
                            <div class="faq-question">
                                <span>How is the platform priced?</span>
                                <i class="fas fa-chevron-down"></i>
                            </div>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    We offer flexible pricing plans designed to scale with your business needs. Our pricing is based on a combination of features accessed and usage volume. The Starter plan begins at $99/month, Professional at $299/month, and Enterprise plans are custom-priced based on specific requirements. We provide transparent pricing with no hidden fees, and our team works with you to ensure you're getting the most value from your investment. You can view detailed pricing information on our website or contact our sales team for a customized quote.
                                </div>
                            </div>
                        </div>
                        
                        <div class="faq-item">
                            <div class="faq-question">
                                <span>Do you offer a free trial?</span>
                                <i class="fas fa-chevron-down"></i>
                            </div>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    Yes, we offer a 14-day free trial that provides access to most of our core features. The trial includes limited usage of our AI tools, allowing you to explore the platform and test capabilities with your own data before committing to a subscription. No credit card is required to start your trial. During the trial period, our onboarding team will help you maximize your experience and answer any questions you may have about the platform.
                                </div>
                            </div>
                        </div>
                        
                        <div class="faq-item">
                            <div class="faq-question">
                                <span>What's included in the Enterprise plan?</span>
                                <i class="fas fa-chevron-down"></i>
                            </div>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    The Enterprise plan includes all features from the Professional plan plus advanced capabilities like custom model training, unlimited API calls, priority access to new features, enhanced security controls, custom SLAs, and a dedicated success manager. Enterprise customers receive 24/7 premium support, quarterly business reviews, and access to our AI specialists for consultation. We also offer custom integrations, dedicated infrastructure options, and compliance packages for regulated industries. Enterprise pricing is customized based on your organization's specific needs and scale.
                                </div>
                            </div>
                        </div>
                        
                        <div class="faq-item">
                            <div class="faq-question">
                                <span>Can I upgrade or downgrade my plan at any time?</span>
                                <i class="fas fa-chevron-down"></i>
                            </div>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    Yes, you can upgrade your plan at any time, and the changes will take effect immediately. When upgrading, you'll only be charged the prorated difference for the remainder of your billing cycle. Downgrades take effect at the end of your current billing cycle. Both upgrades and downgrades can be managed from your account settings or with assistance from our customer success team. We don't lock you into long-term contracts, giving you the flexibility to adjust your plan as your needs change.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="faq-category" data-category="security">
                    <h3 class="category-title">Security & Privacy</h3>
                    <div class="faq-container">
                        <div class="faq-item">
                            <div class="faq-question">
                                <span>How does the AI platform ensure data security and privacy?</span>
                                <i class="fas fa-chevron-down"></i>
                            </div>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    Our AI platform is built with security and privacy at its core. All data is encrypted both in transit and at rest using industry-standard protocols. We comply with GDPR, CCPA, and other regional privacy regulations. Your data is never used to train our models without explicit consent, and you maintain full ownership of your data at all times. We implement strict access controls, regular security audits, and vulnerability testing. Enterprise customers receive additional security features including custom data retention policies, private cloud deployments, and dedicated security reviews.
                                </div>
                            </div>
                        </div>
                        
                        <div class="faq-item">
                            <div class="faq-question">
                                <span>Is my data used to train your AI models?</span>
                                <i class="fas fa-chevron-down"></i>
                            </div>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    No, your data is not used to train our general AI models without your explicit permission. By default, all customer data is isolated and used only to provide the services you've requested. Your inputs may be used to fine-tune your own custom models if you enable this feature, but this customization only affects your instance of the platform. We maintain strict data boundaries between customers. Enterprise customers can opt for complete data isolation with guarantees that their data will never be used for any purpose other than delivering their requested services.
                                </div>
                            </div>
                        </div>
                        
                        <div class="faq-item">
                            <div class="faq-question">
                                <span>Are you compliant with industry regulations?</span>
                                <i class="fas fa-chevron-down"></i>
                            </div>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    Yes, we maintain compliance with major regulations and standards including GDPR, CCPA, HIPAA (for healthcare customers), SOC 2 Type II, and ISO 27001. We regularly undergo independent audits to verify our security practices and compliance status. For industries with specific regulatory requirements, our Enterprise plan offers additional compliance packages with enhanced controls and documentation to support your compliance needs. We provide detailed documentation and assistance for customers undergoing their own compliance audits.
                                </div>
                            </div>
                        </div>
                        
                        <div class="faq-item">
                            <div class="faq-question">
                                <span>Where is my data stored?</span>
                                <i class="fas fa-chevron-down"></i>
                            </div>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    We operate data centers in multiple regions including North America, Europe, and Asia-Pacific. Your data is stored in the region you select during account setup, allowing you to comply with data residency requirements. Enterprise customers can specify exact data storage locations to meet specific regulatory needs. All data centers are SOC 2 compliant and implement robust physical and logical security controls. We don't transfer your data between regions without your explicit consent, and you can monitor data locations through our admin dashboard.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="faq-category" data-category="technical">
                    <h3 class="category-title">Technical Support</h3>
                    <div class="faq-container">
                        <div class="faq-item">
                            <div class="faq-question">
                                <span>What support options are available?</span>
                                <i class="fas fa-chevron-down"></i>
                            </div>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    We offer multiple support channels tailored to your plan level. All customers have access to our comprehensive knowledge base, community forums, and email support. Professional plan customers receive priority email support and phone support during business hours. Enterprise customers enjoy 24/7 premium support with guaranteed response times, a dedicated support team, and optional on-site support for critical issues. We also provide regular webinars, training sessions, and implementation guidance to help you maximize the value of our platform.
                                </div>
                            </div>
                        </div>
                        
                        <div class="faq-item">
                            <div class="faq-question">
                                <span>How quickly can I integrate the platform with my existing systems?</span>
                                <i class="fas fa-chevron-down"></i>
                            </div>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    Integration timeframes vary depending on your systems and requirements, but most customers can achieve basic integration within 1-4 weeks. Simple API integrations can be completed in days, while more complex enterprise implementations may take 1-2 months. We provide comprehensive documentation, SDKs for popular programming languages, and pre-built connectors for common business systems to accelerate integration. Our professional services team is available to assist with custom integrations, and we offer implementation packages specifically designed to minimize time-to-value.
                                </div>
                            </div>
                        </div>
                        
                        <div class="faq-item">
                            <div class="faq-question">
                                <span>What APIs do you offer?</span>
                                <i class="fas fa-chevron-down"></i>
                            </div>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    We offer a comprehensive suite of RESTful APIs that provide programmatic access to all our AI capabilities. These include Natural Language Processing API, Computer Vision API, Predictive Analytics API, Conversational AI API, and more. All APIs follow modern design principles with detailed documentation, consistent error handling, and robust authentication. We provide client libraries for popular programming languages including Python, JavaScript, Java, C#, and Ruby. Our API plans include generous usage limits with options to scale as your needs grow.
                                </div>
                            </div>
                        </div>
                        
                        <div class="faq-item">
                            <div class="faq-question">
                                <span>What is your system uptime guarantee?</span>
                                <i class="fas fa-chevron-down"></i>
                            </div>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    We guarantee 99.9% uptime for our Standard and Professional plans, and up to 99.99% uptime for Enterprise customers with custom SLAs. Our infrastructure is built on redundant systems with automatic failover capabilities to minimize disruptions. We maintain a public status page with real-time information about system performance and scheduled maintenance. In the rare event of service disruptions, we provide transparent communication and appropriate compensation as outlined in our service level agreements. Enterprise customers receive advance notification of planned maintenance and can request maintenance windows that align with their business needs.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <div class="cta-section">
            <h2 class="cta-title">Still Have Questions?</h2>
            <p class="cta-text">Our team is ready to help you find the answers you need and get the most out of our AI platform. Schedule a personalized demo or consultation with our experts.</p>
            <a href="/page/contact" class="cta-button">Contact Our Team</a>
        </div>
        
        <div class="contact-info">
            <h3 class="contact-title">Get in Touch</h3>
            <p class="contact-text">We're here to help you with any questions or concerns about our AI platform. Reach out to us through any of these channels:</p>
            
            <div class="contact-options">
                <div class="contact-option">
                    <div class="contact-icon">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <div class="contact-label">Email Support</div>
                    <div class="contact-value">
                        <a href="mailto:support@aitools-platform.com">support@aitools-platform.com</a>
                    </div>
                </div>
                
                <div class="contact-option">
                    <div class="contact-icon">
                        <i class="fas fa-phone-alt"></i>
                    </div>
                    <div class="contact-label">Phone Support</div>
                    <div class="contact-value">
                        <a href="tel:+18005559876">+1 (800) 555-9876</a>
                    </div>
                </div>
                
                <div class="contact-option">
                    <div class="contact-icon">
                        <i class="fas fa-comment-dots"></i>
                    </div>
                    <div class="contact-label">Live Chat</div>
                    <div class="contact-value">
                        Available 24/7 in your dashboard
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Toggle FAQ items
        const faqItems = document.querySelectorAll('.faq-item');
        faqItems.forEach(item => {
            const question = item.querySelector('.faq-question');
            question.addEventListener('click', () => {
                item.classList.toggle('active');
            });
        });
        
        // Filter FAQ by category
        const topicButtons = document.querySelectorAll('.faq-topic');
        const faqCategories = document.querySelectorAll('.faq-category');
        
        topicButtons.forEach(button => {
            button.addEventListener('click', () => {
                const category = button.getAttribute('data-category');
                
                // Update active button
                topicButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');
                
                // Show/hide categories
                if (category === 'all') {
                    faqCategories.forEach(cat => cat.style.display = 'block');
                } else {
                    faqCategories.forEach(cat => {
                        if (cat.getAttribute('data-category') === category) {
                            cat.style.display = 'block';
                        } else {
                            cat.style.display = 'none';
                        }
                    });
                }
            });
        });
        
        // Search functionality
        const searchInput = document.getElementById('faqSearch');
        searchInput.addEventListener('input', () => {
            const searchTerm = searchInput.value.toLowerCase();
            
            if (searchTerm.length < 2) {
                faqItems.forEach(item => item.style.display = 'block');
                return;
            }
            
            faqItems.forEach(item => {
                const question = item.querySelector('.faq-question span').textContent.toLowerCase();
                const answer = item.querySelector('.faq-answer-inner').textContent.toLowerCase();
                
                if (question.includes(searchTerm) || answer.includes(searchTerm)) {
                    item.style.display = 'block';
                    
                    // Make sure the category is visible
                    const category = item.closest('.faq-category');
                    category.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
            
            // Check if any items are visible in each category
            faqCategories.forEach(category => {
                const visibleItems = category.querySelectorAll('.faq-item[style="display: block;"]');
                if (visibleItems.length === 0) {
                    category.style.display = 'none';
                }
            });
        });
    </script>
    
    <footer style="text-align: center; margin-top: 3rem; padding: 2rem 0; background-color: #1E293B; color: #F8FAFC;">
        <div class="container">
            <p>&copy; <?php echo $currentYear; ?> AI Tools Platform. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>