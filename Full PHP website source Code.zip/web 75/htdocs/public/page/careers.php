
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php include_once ('../../private/favicon.php'); ?>
  <title><?php echo $pageTitle; ?></title>
  <link rel="stylesheet" href="../assets/css/footer.css">
  <style>
    :root {
      --primary: #3b82f6;
      --primary-dark: #2563eb;
      --secondary: #10b981;
      --dark: #1f2937;
      --light: #f9fafb;
      --gray: #6b7280;
      --light-gray: #e5e7eb;
    }
    
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
    }
    
    body {
      background-color: var(--light);
      color: var(--dark);
      line-height: 1.6;
    }
    
    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 2rem;
    }
    
    header {
      background-color: white;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
      padding: 1.5rem 0;
    }
    
    .hero {
      padding: 5rem 0;
      background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
      color: white;
      text-align: center;
    }
    
    .hero h1 {
      font-size: 3rem;
      margin-bottom: 1rem;
    }
    
    .hero p {
      font-size: 1.25rem;
      max-width: 700px;
      margin: 0 auto;
      opacity: 0.9;
    }
    
    .careers-section {
      padding: 4rem 0;
    }
    
    .section-title {
      text-align: center;
      margin-bottom: 3rem;
    }
    
    .section-title h2 {
      font-size: 2.5rem;
      margin-bottom: 1rem;
      color: var(--dark);
    }
    
    .section-title p {
      color: var(--gray);
      max-width: 700px;
      margin: 0 auto;
    }
    
    .job-list {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
      gap: 2rem;
    }
    
    .job-card {
      background-color: white;
      border-radius: 8px;
      overflow: hidden;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
      transition: transform 0.3s, box-shadow 0.3s;
      display: flex;
      flex-direction: column;
    }
    
    .job-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
    }
    
    .job-card-header {
      padding: 1.5rem;
      border-bottom: 1px solid var(--light-gray);
    }
    
    .job-title {
      font-size: 1.25rem;
      font-weight: 600;
      margin-bottom: 0.5rem;
      color: var(--dark);
    }
    
    .job-location {
      display: flex;
      align-items: center;
      color: var(--gray);
      font-size: 0.9rem;
    }
    
    .job-location svg {
      margin-right: 0.5rem;
    }
    
    .job-type {
      display: inline-block;
      padding: 0.25rem 0.75rem;
      border-radius: 999px;
      font-size: 0.75rem;
      font-weight: 500;
      text-transform: uppercase;
      margin-top: 0.75rem;
    }
    
    .job-type.fulltime {
      background-color: #e0f2fe;
      color: #0369a1;
    }
    
    .job-type.remote {
      background-color: #dcfce7;
      color: #15803d;
    }
    
    .job-type.contract {
      background-color: #fef3c7;
      color: #92400e;
    }
    
    .job-card-body {
      padding: 1.5rem;
      flex-grow: 1;
    }
    
    .job-description {
      color: var(--gray);
      margin-bottom: 1.5rem;
    }
    
    .job-meta {
      display: flex;
      justify-content: space-between;
      color: var(--gray);
      font-size: 0.9rem;
    }
    
    .job-card-footer {
      padding: 1.5rem;
      border-top: 1px solid var(--light-gray);
      display: flex;
      justify-content: flex-end;
    }
    
    .btn {
      display: inline-block;
      padding: 0.75rem 1.5rem;
      font-weight: 500;
      border-radius: 0.375rem;
      text-align: center;
      cursor: pointer;
      transition: all 0.3s;
      text-decoration: none;
    }
    
    .btn-primary {
      background-color: var(--primary);
      color: white;
    }
    
    .btn-primary:hover {
      background-color: var(--primary-dark);
    }
    
    .culture-section {
      padding: 4rem 0;
      background-color: white;
    }
    
    .culture-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 2rem;
    }
    
    .culture-card {
      text-align: center;
      padding: 2rem;
    }
    
    .culture-icon {
      width: 64px;
      height: 64px;
      background-color: #dbeafe;
      border-radius: 999px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 1rem;
    }
    
    .culture-card h3 {
      margin-bottom: 1rem;
      color: var(--dark);
    }
    
    .culture-card p {
      color: var(--gray);
    }
    
    
    @media (max-width: 768px) {
      .job-list {
        grid-template-columns: 1fr;
      }
      
      .culture-grid {
        grid-template-columns: 1fr;
      }
      
      .hero h1 {
        font-size: 2.5rem;
      }
    }
  </style>
</head>
<body>
  
  <section class="hero">
    <div class="container">
      <h1>Join Our Team</h1>
      <p>Be part of a team shaping the future of AI tools and technologies. We're looking for passionate individuals who want to make an impact.</p>
    </div>
  </section>
  
  <section class="careers-section">
    <div class="container">
      <div class="section-title">
        <h2>Open Positions</h2>
        <p>Explore current opportunities and find your perfect role in our growing team.</p>
      </div>
      
      <div class="job-list">
        <?php
        // In a real application, you would fetch job data from a database
        $jobs = [
            [
                'id' => 1,
                'title' => 'AI Solutions Architect',
                'location' => 'San Francisco, CA',
                'type' => 'fulltime',
                'type_label' => 'Full-time',
                'description' => 'Design and implement AI solutions for enterprise clients. Collaborate with cross-functional teams to deliver cutting-edge AI products.',
                'posted' => 'March 25, 2025',
                'salary' => '$120K - $160K'
            ],
            [
                'id' => 2,
                'title' => 'Machine Learning Engineer',
                'location' => 'Remote',
                'type' => 'remote',
                'type_label' => 'Remote',
                'description' => 'Develop and optimize machine learning models for our AI platform. Work on cutting-edge algorithms and contribute to our research initiatives.',
                'posted' => 'March 22, 2025',
                'salary' => '$110K - $150K'
            ],
            [
                'id' => 3,
                'title' => 'AI Product Manager',
                'location' => 'New York, NY',
                'type' => 'fulltime',
                'type_label' => 'Full-time',
                'description' => 'Lead the product development lifecycle for our AI tools. Define product vision, gather requirements, and work with engineering teams to deliver exceptional products.',
                'posted' => 'March 18, 2025',
                'salary' => '$100K - $140K'
            ],
            [
                'id' => 4,
                'title' => 'NLP Specialist',
                'location' => 'Austin, TX',
                'type' => 'fulltime',
                'type_label' => 'Full-time',
                'description' => 'Develop and improve natural language processing models for our AI platform. Create innovative solutions for language understanding and generation.',
                'posted' => 'March 15, 2025',
                'salary' => '$115K - $155K'
            ],
            [
                'id' => 5,
                'title' => 'AI Integration Specialist',
                'location' => 'Remote',
                'type' => 'remote',
                'type_label' => 'Remote',
                'description' => 'Help clients integrate our AI tools into their existing workflows and systems. Provide technical support and develop custom integration solutions.',
                'posted' => 'March 10, 2025',
                'salary' => '$90K - $120K'
            ],
            [
                'id' => 6,
                'title' => 'Frontend Developer (AI Tools)',
                'location' => 'Boston, MA',
                'type' => 'contract',
                'type_label' => 'Contract',
                'description' => 'Build intuitive and responsive user interfaces for our AI tools platform. Collaborate with UX designers and backend engineers to create seamless user experiences.',
                'posted' => 'March 8, 2025',
                'salary' => '$80K - $110K'
            ]
        ];

        foreach ($jobs as $job): 
        ?>
        <div class="job-card">
          <div class="job-card-header">
            <h3 class="job-title"><?php echo htmlspecialchars($job['title']); ?></h3>
            <div class="job-location">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                <path d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6z"/>
              </svg>
              <?php echo htmlspecialchars($job['location']); ?>
            </div>
            <span class="job-type <?php echo $job['type']; ?>"><?php echo $job['type_label']; ?></span>
          </div>
          <div class="job-card-body">
            <p class="job-description"><?php echo htmlspecialchars($job['description']); ?></p>
            <div class="job-meta">
              <span>Posted: <?php echo htmlspecialchars($job['posted']); ?></span>
              <span><?php echo htmlspecialchars($job['salary']); ?></span>
            </div>
          </div>
          <div class="job-card-footer">
            <a href="job-detail?id=<?php echo $job['id']; ?>" class="btn btn-primary">View Details</a>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>
  
  <section class="culture-section">
    <div class="container">
      <div class="section-title">
        <h2>Our Culture</h2>
        <p>At AI Tools, we believe in creating an environment where innovation thrives and everyone can contribute their best work.</p>
      </div>
      
      <div class="culture-grid">
        <div class="culture-card">
          <div class="culture-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="#3b82f6" viewBox="0 0 16 16">
              <path d="M15 14s1 0 1-1-1-4-5-4-5 3-5 4 1 1 1 1h8zm-7.978-1A.261.261 0 0 1 7 12.996c.001-.264.167-1.03.76-1.72C8.312 10.629 9.282 10 11 10c1.717 0 2.687.63 3.24 1.276.593.69.758 1.457.76 1.72l-.008.002a.274.274 0 0 1-.014.002H7.022zM11 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4zm3-2a3 3 0 1 1-6 0 3 3 0 0 1 6 0zM6.936 9.28a5.88 5.88 0 0 0-1.23-.247A7.35 7.35 0 0 0 5 9c-4 0-5 3-5 4 0 .667.333 1 1 1h4.216A2.238 2.238 0 0 1 5 13c0-1.01.377-2.042 1.09-2.904.243-.294.526-.569.846-.816zM4.92 10A5.493 5.493 0 0 0 4 13H1c0-.26.164-1.03.76-1.724.545-.636 1.492-1.256 3.16-1.275zM1.5 5.5a3 3 0 1 1 6 0 3 3 0 0 1-6 0zm3-2a2 2 0 1 0 0 4 2 2 0 0 0 0-4z"/>
            </svg>
          </div>
          <h3>Collaborative Teams</h3>
          <p>We work together across disciplines, sharing knowledge and skills to create innovative solutions.</p>
        </div>
        
        <div class="culture-card">
          <div class="culture-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="#3b82f6" viewBox="0 0 16 16">
              <path d="M2 6a6 6 0 1 1 10.174 4.31c-.203.196-.359.4-.453.619l-.762 1.769A.5.5 0 0 1 10.5 13h-5a.5.5 0 0 1-.46-.302l-.761-1.77a1.964 1.964 0 0 0-.453-.618A5.984 5.984 0 0 1 2 6zm3 8.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1l-.224.447a1 1 0 0 1-.894.553H6.618a1 1 0 0 1-.894-.553L5.5 15a.5.5 0 0 1-.5-.5z"/>
            </svg>
          </div>
          <h3>Innovation First</h3>
          <p>We encourage experimentation, creative thinking, and pushing the boundaries of what's possible with AI.</p>
        </div>
        
        <div class="culture-card">
          <div class="culture-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="#3b82f6" viewBox="0 0 16 16">
              <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0zM4.5 7.5a.5.5 0 0 0 0 1h7a.5.5 0 0 0 0-1h-7z"/>
            </svg>
          </div>
          <h3>Work-Life Balance</h3>
          <p>We believe in sustainable work practices that allow our team to thrive both professionally and personally.</p>
        </div>
      </div>
    </div>
  </section>

</body>
</html>