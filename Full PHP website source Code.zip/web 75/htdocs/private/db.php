<?php
/**
 * Database connection handler
 */

// Database connection
function getDbConnection() {
    static $conn = null;
    
    if ($conn === null) {
        try {
            $conn = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                DB_USER,
                DB_PASSWORD,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]
            );
            
            // Set the session time zone to Indian time (UTC+5:30)
            $conn->exec("SET time_zone = '+05:30'");
            
        } catch (PDOException $e) {
            // Log the error but don't display sensitive information
            error_log("Database connection failed: " . $e->getMessage());
            die("A database error occurred. Please try again later.");
        }
    }
    
    return $conn;
}

/**
 * Execute a SELECT query and return the results
 */
function dbSelect($query, $params = []) {
    try {
        $conn = getDbConnection();
        $stmt = $conn->prepare($query);
        $stmt->execute($params);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log("Query error: " . $e->getMessage() . " - Query: " . $query);
        return false;
    }
}

/**
 * Execute a SELECT query and return a single row
 */
function dbSelectOne($query, $params = []) {
    try {
        $conn = getDbConnection();
        $stmt = $conn->prepare($query);
        $stmt->execute($params);
        return $stmt->fetch();
    } catch (PDOException $e) {
        error_log("Query error: " . $e->getMessage() . " - Query: " . $query);
        return false;
    }
}

/**
 * Execute an INSERT, UPDATE, or DELETE query and return the number of affected rows
 */
function dbExecute($query, $params = []) {
    try {
        $conn = getDbConnection();
        $stmt = $conn->prepare($query);
        $stmt->execute($params);
        return $stmt->rowCount();
    } catch (PDOException $e) {
        error_log("Query error: " . $e->getMessage() . " - Query: " . $query);
        return false;
    }
}

/**
 * Insert a record and return the last insert ID
 */
function dbInsert($query, $params = []) {
    try {
        $conn = getDbConnection();
        $stmt = $conn->prepare($query);
        $stmt->execute($params);
        return $conn->lastInsertId();
    } catch (PDOException $e) {
        error_log("Insert error: " . $e->getMessage() . " - Query: " . $query);
        return false;
    }
}

function logToolUsage($userId, $toolId, $details = null) {
    return dbExecute(
        "INSERT INTO tool_usage (user_id, tool_id, details) VALUES (?, ?, ?)",
        [$userId, $toolId, $details]
    );
}

/**
 * Clean up tool usage records older than specified days
 */
function cleanupOldToolUsage($days = 7) {
    return dbExecute(
        "DELETE FROM tool_usage WHERE used_at < DATE_SUB(NOW(), INTERVAL ? DAY)",
        [$days]
    );
}