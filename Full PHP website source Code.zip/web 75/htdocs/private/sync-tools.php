<?php
/**
 * Tool Synchronization Script
 * 
 * This script:
 * 1. Creates necessary database tables if they don't exist
 * 2. Scans the tools directory for tools
 * 3. Updates the database with found tools
 * 4. Extracts icons/SVGs and categories from tool files
 * 5. Fetches corresponding Markdown files from the details directory
 * 6. Maintains a search index for tools
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

// Define tools directory path
define('TOOLS_DIR', PUBLIC_PATH . '/tools/files');
define('TOOLS_DETAILS_DIR', PUBLIC_PATH . '/tools/details');

// Create tables if they don't exist
function createTablesIfNotExist() {
    $queries = [
        // Tools table
        "CREATE TABLE IF NOT EXISTS `tools` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `name` varchar(255) NOT NULL,
            `slug` varchar(255) NOT NULL,
            `description` text,
            `icon` text DEFAULT NULL,
            `icon_type` varchar(50) DEFAULT NULL,
            `file_path` varchar(255) NOT NULL,
            `category` varchar(100) DEFAULT NULL,
            `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `slug` (`slug`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
        
        // Tool statistics table
        "CREATE TABLE IF NOT EXISTS `tool_stats` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `tool_id` int(11) NOT NULL,
            `views` int(11) NOT NULL DEFAULT '0',
            `last_viewed` timestamp NULL DEFAULT NULL,
            PRIMARY KEY (`id`),
            KEY `tool_id` (`tool_id`),
            CONSTRAINT `fk_tool_stats_tool_id` FOREIGN KEY (`tool_id`) REFERENCES `tools` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
        
        // Tool details table
        "CREATE TABLE IF NOT EXISTS `tool_details` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `tool_id` int(11) NOT NULL,
            `markdown_content` longtext NOT NULL,
            `details_file_path` varchar(255) NOT NULL,
            `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `tool_id` (`tool_id`),
            CONSTRAINT `fk_tool_details_tool_id` FOREIGN KEY (`tool_id`) REFERENCES `tools` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
        
        // Search index table
        "CREATE TABLE IF NOT EXISTS `tools_search_index` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `tool_id` int(11) NOT NULL,
            `search_text` text NOT NULL,
            `keywords` text DEFAULT NULL,
            `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `tool_id` (`tool_id`),
            FULLTEXT KEY `search_text` (`search_text`),
            FULLTEXT KEY `keywords` (`keywords`),
            CONSTRAINT `fk_tools_search_index_tool_id` FOREIGN KEY (`tool_id`) REFERENCES `tools` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;"
    ];
    
    foreach ($queries as $query) {
        dbExecute($query);
    }
    
    echo "Tables created or already exist.\n";
}

// Generate a slug from a string
function generateSlug($string) {
    $string = strtolower($string);
    $string = preg_replace('/[^a-z0-9\-]/', '-', $string);
    $string = preg_replace('/-+/', '-', $string);
    $string = trim($string, '-');
    return $string;
}

// Extract tool information from PHP file
function extractToolInfo($filePath) {
    $content = file_get_contents($filePath);
    $info = [
        'name' => basename($filePath, '.php'),
        'description' => '',
        'category' => 'General',
        'icon' => null,
        'icon_type' => null,
        'keywords' => null
    ];
    
    // Extract tool name, description, category, and keywords from comments
    if (preg_match('/\/\*\*\s*\n\s*\*\s*Tool:\s*(.*?)\s*\n\s*\*\s*Description:\s*(.*?)\s*\n\s*(?:\*\s*Category:\s*(.*?)\s*\n)?\s*(?:\*\s*Icon:\s*(.*?)\s*\n)?\s*(?:\*\s*Keywords:\s*(.*?)\s*\n)?\s*\*\//s', $content, $matches)) {
        $info['name'] = trim($matches[1]);
        $info['description'] = trim($matches[2]);
        
        if (isset($matches[3]) && !empty(trim($matches[3]))) {
            $info['category'] = trim($matches[3]);
        }
        
        // Extract icon if available
        if (isset($matches[4]) && !empty(trim($matches[4]))) {
            $iconRaw = trim($matches[4]);
            if (preg_match('/<svg.*<\/svg>/s', $iconRaw, $svgMatches)) {
                $info['icon'] = $svgMatches[0];
                $info['icon_type'] = 'svg';
            } elseif (preg_match('/<i class=["\']([^"\']+)["\']/i', $iconRaw, $iconClassMatches)) {
                $info['icon'] = $iconClassMatches[1];
                $info['icon_type'] = 'class';
            } elseif (preg_match('/[a-zA-Z0-9\-_]+\.(png|jpg|jpeg|gif|webp)/', $iconRaw, $iconFileMatches)) {
                $info['icon'] = $iconFileMatches[0];
                $info['icon_type'] = 'image';
            }
        }
        
        // Extract keywords if available
        if (isset($matches[5]) && !empty(trim($matches[5]))) {
            $info['keywords'] = trim($matches[5]);
        }
    }
    
    // Try to extract SVG from the file content if not found in comments
    if (!$info['icon'] && preg_match('/<svg[^>]*class=["\']tool-icon["\'][^>]*>.*?<\/svg>/s', $content, $svgMatches)) {
        $info['icon'] = $svgMatches[0];
        $info['icon_type'] = 'svg';
    }
    
    $info['slug'] = generateSlug($info['name']);
    $info['file_path'] = str_replace(PUBLIC_PATH, '', $filePath);
    
    return $info;
}

// Get Markdown details for a tool
function getToolDetails($toolSlug) {
    $detailsFilePath = TOOLS_DETAILS_DIR . '/' . $toolSlug . '.md';
    
    // Debug information
    echo "Looking for details file at: {$detailsFilePath}\n";
    
    if (file_exists($detailsFilePath)) {
        $markdownContent = file_get_contents($detailsFilePath);
        return [
            'markdown_content' => $markdownContent,
            'details_file_path' => str_replace(PUBLIC_PATH, '', $detailsFilePath)
        ];
    } else {
        // Try to find files that might match with different casing or variations
        $possibleFiles = glob(TOOLS_DETAILS_DIR . '/*.md', GLOB_NOSORT);
        foreach ($possibleFiles as $file) {
            $fileName = strtolower(basename($file, '.md'));
            if ($fileName == strtolower($toolSlug)) {
                $markdownContent = file_get_contents($file);
                echo "Found alternative match for '{$toolSlug}' at '{$file}'\n";
                return [
                    'markdown_content' => $markdownContent,
                    'details_file_path' => str_replace(PUBLIC_PATH, '', $file)
                ];
            }
        }
        echo "No details file found for tool slug: {$toolSlug}\n";
    }
    return false;
}

// Extract information from markdown content
function extractInfoFromMarkdown($markdown) {
    $info = [
        'features' => [],
        'tags' => []
    ];
    
    // Extract features (look for bullet points)
    if (preg_match_all('/^[\s]*[*-][\s]+(.*?)$/m', $markdown, $matches)) {
        $info['features'] = $matches[1];
    }
    
    // Extract tags (look for #tag or hash-tagged words)
    if (preg_match_all('/#([a-zA-Z0-9_\-]+)/', $markdown, $matches)) {
        $info['tags'] = $matches[1];
    }
    
    return $info;
}

// Create or update search index for a tool
function updateSearchIndex($toolId, $toolInfo, $markdownContent = null) {
    // Prepare search text from tool name, description, and category
    $searchText = $toolInfo['name'] . ' ' . $toolInfo['description'] . ' ' . $toolInfo['category'];
    
    // Add keywords if available
    $keywords = $toolInfo['keywords'] ?? '';
    
    // Add any relevant data from markdown content if available
    if ($markdownContent) {
        // Add the full markdown content to the search text
        $searchText .= ' ' . $markdownContent;
        
        // Extract structured information from markdown
        $extractedInfo = extractInfoFromMarkdown($markdownContent);
        
        // Add features to search text
        if (!empty($extractedInfo['features'])) {
            foreach ($extractedInfo['features'] as $feature) {
                $searchText .= ' ' . $feature;
            }
        }
        
        // Add tags to keywords
        if (!empty($extractedInfo['tags'])) {
            foreach ($extractedInfo['tags'] as $tag) {
                $keywords .= ',' . $tag;
            }
        }
    }
    
    // Check if entry exists
    $existingEntry = dbSelectOne("SELECT id FROM tools_search_index WHERE tool_id = ?", [$toolId]);
    
    if ($existingEntry) {
        // Update existing entry
        dbExecute(
            "UPDATE tools_search_index SET search_text = ?, keywords = ? WHERE tool_id = ?",
            [$searchText, $keywords, $toolId]
        );
        echo "Updated search index for tool ID: {$toolId}\n";
    } else {
        // Insert new entry
        dbInsert(
            "INSERT INTO tools_search_index (tool_id, search_text, keywords) VALUES (?, ?, ?)",
            [$toolId, $searchText, $keywords]
        );
        echo "Created search index for tool ID: {$toolId}\n";
    }
}

// Sync tools directory with database
function syncTools() {
    // At the beginning of the syncTools() function, add:
    echo "Scanning for Markdown files in details directory...\n";
    $mdFiles = glob(TOOLS_DETAILS_DIR . '/*.md');
    echo "Found " . count($mdFiles) . " Markdown files:\n";
    foreach ($mdFiles as $mdFile) {
        echo "  - " . basename($mdFile) . "\n";
    }

    // Create directories if they don't exist
    if (!file_exists(TOOLS_DIR)) {
        mkdir(TOOLS_DIR, 0755, true);
        echo "Tools directory created at " . TOOLS_DIR . "\n";
    }
    
    if (!file_exists(TOOLS_DETAILS_DIR)) {
        mkdir(TOOLS_DETAILS_DIR, 0755, true);
        echo "Tools details directory created at " . TOOLS_DETAILS_DIR . "\n";
    }
    
    $toolFiles = glob(TOOLS_DIR . '/*.php');
    $toolsInDb = [];
    $toolsInDir = [];
    
    // Get existing tools from database
    $existingTools = dbSelect("SELECT id, name, slug, file_path FROM tools");
    foreach ($existingTools as $tool) {
        $toolsInDb[$tool['file_path']] = $tool;
    }
    
    // Process each tool file
    foreach ($toolFiles as $file) {
        $info = extractToolInfo($file);
        $toolsInDir[$info['file_path']] = $info;
        
        // Check if the tool exists in the database
        if (isset($toolsInDb[$info['file_path']])) {
            // Update existing tool
            $toolId = $toolsInDb[$info['file_path']]['id'];
            dbExecute(
                "UPDATE tools SET name = ?, slug = ?, description = ?, icon = ?, icon_type = ?, category = ? WHERE id = ?",
                [$info['name'], $info['slug'], $info['description'], $info['icon'], $info['icon_type'], $info['category'], $toolId]
            );
            echo "Updated tool: " . $info['name'] . "\n";
        } else {
            // Insert new tool
            $toolId = dbInsert(
                "INSERT INTO tools (name, slug, description, icon, icon_type, file_path, category) VALUES (?, ?, ?, ?, ?, ?, ?)",
                [$info['name'], $info['slug'], $info['description'], $info['icon'], $info['icon_type'], $info['file_path'], $info['category']]
            );
            
            // Create stats entry for the new tool
            dbInsert(
                "INSERT INTO tool_stats (tool_id, views) VALUES (?, 0)",
                [$toolId]
            );
            
            echo "Added new tool: " . $info['name'] . "\n";
        }
        
        // Now process the details file
        $details = getToolDetails($info['slug']);
        $markdownContent = null;
        
        if ($details) {
            $markdownContent = $details['markdown_content'];
            // Check if details exist for this tool
            $existingDetails = dbSelectOne("SELECT id FROM tool_details WHERE tool_id = ?", [$toolId]);
            
            if ($existingDetails) {
                // Update existing details
                dbExecute(
                    "UPDATE tool_details SET markdown_content = ?, details_file_path = ? WHERE tool_id = ?",
                    [$details['markdown_content'], $details['details_file_path'], $toolId]
                );
                echo "Updated details for tool: " . $info['name'] . "\n";
            } else {
                // Insert new details
                dbInsert(
                    "INSERT INTO tool_details (tool_id, markdown_content, details_file_path) VALUES (?, ?, ?)",
                    [$toolId, $details['markdown_content'], $details['details_file_path']]
                );
                echo "Added details for tool: " . $info['name'] . "\n";
            }
        } else {
            echo "No valid details file found for tool: " . $info['name'] . "\n";
        }
        
        // Update search index for this tool
        updateSearchIndex($toolId, $info, $markdownContent);
    }
    
    // Find tools that exist in the database but not in the directory
    foreach ($toolsInDb as $path => $tool) {
        if (!isset($toolsInDir[$path])) {
            dbExecute("DELETE FROM tools WHERE id = ?", [$tool['id']]);
            echo "Removed tool: " . $tool['name'] . " (file not found)\n";
            // The details and search index will be removed automatically due to the CASCADE constraint
        }
    }
    
    // Find and remove tool details that don't have corresponding Markdown files
    $toolDetailEntries = dbSelect("SELECT td.id, td.tool_id, td.details_file_path, t.slug 
                                  FROM tool_details td 
                                  JOIN tools t ON td.tool_id = t.id");
    
    foreach ($toolDetailEntries as $detail) {
        $detailsFile = PUBLIC_PATH . $detail['details_file_path'];
        $mdFileShouldExist = TOOLS_DETAILS_DIR . '/' . $detail['slug'] . '.md';
        
        // Check if the details file exists (either at the stored path or the expected path)
        if (!file_exists($detailsFile) && !file_exists($mdFileShouldExist)) {
            dbExecute("DELETE FROM tool_details WHERE id = ?", [$detail['id']]);
            echo "Removed tool details for tool ID: " . $detail['tool_id'] . " (file not found)\n";
        }
    }
    
    echo "Tools synchronization completed.\n";
}

// Main execution
echo "Starting tools synchronization...\n";
createTablesIfNotExist();
syncTools();
echo "Done!\n";