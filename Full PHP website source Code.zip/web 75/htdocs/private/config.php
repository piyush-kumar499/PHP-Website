<?php
/**
 * Website configuration settings
 */

// Enable error reporting in development, disable in production
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Database configuration
define('DB_HOST', 'sql213.alchosting.xyz');
define('DB_NAME', 'alcy_38614778_ai');
define('DB_USER', 'alcy_38614778');
define('DB_PASSWORD', '7ps65rsSFRZ1RBL');

// SMTP Mail Configuration
$CONFIG['smtp_host'] = 'smtp.gmail.com'; 
$CONFIG['smtp_username'] = 'piyushofficial67@gmail.com';  
$CONFIG['smtp_password'] = 'hphghfmaakahsqpt'; 
$CONFIG['smtp_port'] = 587; 
$CONFIG['smtp_secure'] = 'tls';
$CONFIG['smtp_from_email'] = 'piyushofficial67@gmail.com';  
$CONFIG['smtp_from_name'] = 'AI Tools'; 

// Website settings
define('SITE_NAME', 'AI Tools');
define('SITE_URL', 'http://piyush.uca.icu');
define('ADMIN_EMAIL', 'piyushofficial67@gmail.com');

// Security settings
define('SESSION_LIFETIME', 86400); // 24 hours in seconds
define('HASH_COST', 12); // Password hashing cost

// Set up session security
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', 1); // Use 1 for HTTPS, 0 for HTTP
ini_set('session.cookie_samesite', 'Lax');
ini_set('session.gc_maxlifetime', SESSION_LIFETIME);
session_set_cookie_params(SESSION_LIFETIME);

// Define user access levels
define('USER_LEVEL_BASIC', 1);
define('USER_LEVEL_PREMIUM', 2);
define('USER_LEVEL_ADMIN', 3);

// Time zone setting
date_default_timezone_set('UTC');

// Define paths
define('ROOT_PATH', dirname(__DIR__));
define('PUBLIC_PATH', ROOT_PATH . '/public');
define('PRIVATE_PATH', ROOT_PATH . '/private');

// File upload settings
define('MAX_UPLOAD_SIZE', 10 * 1024 * 1024); // 10MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx']);

$CONFIG['site_url'] = 'http://piyush.uca.icu';


$CONFIG['site_name'] = 'AI Tools';  // e.g., "AI Tools"
$CONFIG['company_address'] = '123 Main St, City, India';
$CONFIG['support_email'] = 'piyushofficial67@gmail.com';
$CONFIG['support_name'] = 'AI Tools Team';