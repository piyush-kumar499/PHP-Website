<?php
/**
 * Contact Form Handler Functions
 * Handles all email operations for the contact form
 */

require_once('PHPMailer/class.phpmailer.php');
require_once('PHPMailer/class.smtp.php');

/**
 * Store contact form submission in database
 * 
 * @param string $name Sender's name
 * @param string $email Sender's email
 * @param string $subject Message subject
 * @param string $message Message content
 * @return int|bool Submission ID or false on failure
 */
function storeContactSubmission($name, $email, $subject, $message) {
    // Create table if it doesn't exist (first-time setup)
    createContactSubmissionsTableIfNeeded();
    
    return dbInsert(
        "INSERT INTO contact_submissions (name, email, subject, message, status) VALUES (?, ?, ?, ?, 'new')",
        [$name, $email, $subject, $message]
    );
}

/**
 * Create contact_submissions table if it doesn't exist
 */
function createContactSubmissionsTableIfNeeded() {
    static $tableChecked = false;
    
    if (!$tableChecked) {
        $conn = getDbConnection();
        
        // Check if table exists
        $tableExists = $conn->query("SHOW TABLES LIKE 'contact_submissions'")->rowCount() > 0;
        
        if (!$tableExists) {
            // Create the table
            $conn->exec("
                CREATE TABLE contact_submissions (
                    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(255) NOT NULL,
                    email VARCHAR(255) NOT NULL,
                    subject VARCHAR(255) NOT NULL,
                    message TEXT NOT NULL,
                    status ENUM('new', 'read', 'replied', 'spam') DEFAULT 'new',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ");
        }
        
        $tableChecked = true;
    }
}

/**
 * Send contact form submission to admin/site owner
 * 
 * @param array $formData Form data including name, email, subject, message
 * @return bool True if email sent successfully
 */
function sendContactEmailToAdmin($formData) {
    global $CONFIG;
    
    $subject = "New Contact Form Submission: " . $formData['subject'];
    
    $message = "
    <html>
    <head>
        <style>
            body {font-family: Arial, sans-serif; line-height: 1.6; color: #333;}
            .container {max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 5px;}
            .header {background: linear-gradient(to right, #8e2de2, #4a00e0); color: white; padding: 10px; text-align: center; border-radius: 5px 5px 0 0;}
            .content {padding: 20px;}
            .message-box {background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin: 15px 0;}
            .footer {text-align: center; font-size: 12px; color: #777; margin-top: 20px;}
            .field {margin-bottom: 10px;}
            .field strong {font-weight: bold;}
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h2>New Contact Form Submission</h2>
            </div>
            <div class='content'>
                <p>You have received a new message from your website contact form.</p>
                
                <div class='field'><strong>Name:</strong> " . htmlspecialchars($formData['name']) . "</div>
                <div class='field'><strong>Email:</strong> " . htmlspecialchars($formData['email']) . "</div>
                <div class='field'><strong>Subject:</strong> " . htmlspecialchars($formData['subject']) . "</div>
                
                <div class='message-box'>
                    <strong>Message:</strong><br>
                    " . nl2br(htmlspecialchars($formData['message'])) . "
                </div>
                
                <p>This message was sent on " . date('F j, Y \a\t g:i a') . "</p>
            </div>
            <div class='footer'>
                &copy; " . date('Y') . " " . $CONFIG['site_name'] . ". All rights reserved.
            </div>
        </div>
    </body>
    </html>
    ";
    
    try {
        // Create a new PHPMailer instance
        $mail = new PHPMailer();
        
        // Set mailer to use SMTP
        $mail->IsSMTP();
        
        // Set SMTP settings from config
        $mail->Host = $CONFIG['smtp_host'];
        $mail->SMTPAuth = true;
        $mail->Username = $CONFIG['smtp_username'];
        $mail->Password = $CONFIG['smtp_password'];
        $mail->Port = $CONFIG['smtp_port'];
        
        // Enable encryption if configured
        if ($CONFIG['smtp_secure'] == 'tls') {
            $mail->SMTPSecure = 'tls';
        } elseif ($CONFIG['smtp_secure'] == 'ssl') {
            $mail->SMTPSecure = 'ssl';
        }
        
        // Optional debug level (0-4)
        $mail->SMTPDebug = 0;
        
        // Set who the message is from
        $mail->SetFrom($CONFIG['smtp_from_email'], $CONFIG['smtp_from_name']);
        
        // Set reply-to as the sender's email
        $mail->AddReplyTo($formData['email'], $formData['name']);
        
        // Set who the message is to
        $mail->AddAddress(ADMIN_EMAIL, $CONFIG['site_name'] . ' Admin');
        
        // Set email subject and body
        $mail->Subject = $subject;
        $mail->MsgHTML($message);
        $mail->AltBody = "New Contact Form Submission\n\nName: " . $formData['name'] . 
                        "\nEmail: " . $formData['email'] . 
                        "\nSubject: " . $formData['subject'] . 
                        "\n\nMessage:\n" . $formData['message'];
        
        // Send the message
        if ($mail->Send()) {
            return true;
        } else {
            error_log("Admin contact email error: " . $mail->ErrorInfo);
            return false;
        }
    } catch (Exception $e) {
        error_log("PHPMailer exception (admin contact): " . $e->getMessage());
        return false;
    }
}

/**
 * Send thank you email to the contact form submitter
 * 
 * @param array $formData Form data including name, email, subject
 * @return bool True if email sent successfully
 */
function sendThankYouEmail($formData) {
    global $CONFIG;
    
    $subject = "Thank you for contacting " . $CONFIG['site_name'];
    
    $message = "
    <html>
    <head>
        <style>
            body {font-family: Arial, sans-serif; line-height: 1.6; color: #333;}
            .container {max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 5px;}
            .header {background: linear-gradient(to right, #8e2de2, #4a00e0); color: white; padding: 10px; text-align: center; border-radius: 5px 5px 0 0;}
            .content {padding: 20px;}
            .footer {text-align: center; font-size: 12px; color: #777; margin-top: 20px;}
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h2>Thank You for Contacting Us</h2>
            </div>
            <div class='content'>
                <p>Hello " . htmlspecialchars($formData['name']) . ",</p>
                
                <p>Thank you for reaching out to us. We have received your message regarding <strong>\"" . htmlspecialchars($formData['subject']) . "\"</strong>.</p>
                
                <p>This is an automatic confirmation that we have received your inquiry. A member of our team will review your message and get back to you as soon as possible.</p>
                
                <p>If you have any additional information to provide, please feel free to reply to this email.</p>
                
                <p>Best regards,<br>" . $CONFIG['support_name'] . "</p>
            </div>
            <div class='footer'>
                &copy; " . date('Y') . " " . $CONFIG['site_name'] . ". All rights reserved.<br>
                " . $CONFIG['company_address'] . "
            </div>
        </div>
    </body>
    </html>
    ";
    
    try {
        // Create a new PHPMailer instance
        $mail = new PHPMailer();
        
        // Set mailer to use SMTP
        $mail->IsSMTP();
        
        // Set SMTP settings from config
        $mail->Host = $CONFIG['smtp_host'];
        $mail->SMTPAuth = true;
        $mail->Username = $CONFIG['smtp_username'];
        $mail->Password = $CONFIG['smtp_password'];
        $mail->Port = $CONFIG['smtp_port'];
        
        // Enable encryption if configured
        if ($CONFIG['smtp_secure'] == 'tls') {
            $mail->SMTPSecure = 'tls';
        } elseif ($CONFIG['smtp_secure'] == 'ssl') {
            $mail->SMTPSecure = 'ssl';
        }
        
        // Optional debug level (0-4)
        $mail->SMTPDebug = 0;
        
        // Set who the message is from
        $mail->SetFrom($CONFIG['smtp_from_email'], $CONFIG['support_name']);
        
        // Set who the message is to
        $mail->AddAddress($formData['email'], $formData['name']);
        
        // Set email subject and body
        $mail->Subject = $subject;
        $mail->MsgHTML($message);
        $mail->AltBody = "Thank you for contacting " . $CONFIG['site_name'] . ".\n\n" .
                         "We have received your message regarding \"" . $formData['subject'] . "\".\n\n" .
                         "A member of our team will review your message and get back to you as soon as possible.\n\n" .
                         "Best regards,\n" . $CONFIG['support_name'];
        
        // Send the message
        if ($mail->Send()) {
            return true;
        } else {
            error_log("Thank you email error: " . $mail->ErrorInfo);
            return false;
        }
    } catch (Exception $e) {
        error_log("PHPMailer exception (thank you email): " . $e->getMessage());
        return false;
    }
}