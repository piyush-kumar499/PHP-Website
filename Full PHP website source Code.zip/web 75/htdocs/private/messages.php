<?php
/**
 * Messages System
 * This file contains functions for managing and displaying flash messages
 * across the application.
 * 
 * Usage:
 * - Include this file at the top of your page after session_start()
 * - To add a message: set_success_message(), set_error_message(), etc.
 * - To display messages: include get_messages_html() in your page
 */

// Ensure session is started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Get messages from the session
 *
 * @param bool $clear Whether to clear messages after retrieving (default: false)
 * @return array Array of message objects
 */
function get_messages($clear = false) {
    $messages = [];
    
    if (isset($_SESSION['messages']) && !empty($_SESSION['messages'])) {
        $messages = $_SESSION['messages'];
        
        // Only clear if specifically requested
        if ($clear) {
            $_SESSION['messages'] = [];
        }
    }
    
    return $messages;
}

/**
 * Clear all messages from the session
 *
 * @return void
 */
function clear_messages() {
    $_SESSION['messages'] = [];
}

/**
 * Set a message in the session
 *
 * @param string $type Message type (success, error, warning, info)
 * @param string $message Message text
 * @return void
 */
function set_message($type, $message) {
    if (!isset($_SESSION['messages'])) {
        $_SESSION['messages'] = [];
    }
    
    $_SESSION['messages'][] = [
        'type' => $type,
        'text' => $message
    ];
}

/**
 * Set a success message
 *
 * @param string $message Message text
 * @return void
 */
function set_success_message($message) {
    set_message('success', $message);
}

/**
 * Set an error message
 *
 * @param string $message Message text
 * @return void
 */
function set_error_message($message) {
    set_message('error', $message);
}

/**
 * Set a warning message
 *
 * @param string $message Message text
 * @return void
 */
function set_warning_message($message) {
    set_message('warning', $message);
}

/**
 * Set an info message
 *
 * @param string $message Message text
 * @return void
 */
function set_info_message($message) {
    set_message('info', $message);
}

/**
 * Get HTML for displaying messages
 *
 * @return string HTML for messages
 */
function get_messages_html() {
    $messages = get_messages(true); // Get and clear messages
    
    if (empty($messages)) {
        return '';
    }
    
    $html = '<div class="messages-container">';
    
    foreach ($messages as $message) {
        $html .= '<div class="message message-' . $message['type'] . '" id="flash-message">';
        $html .= '<div class="message-content">' . htmlspecialchars($message['text'], ENT_QUOTES, 'UTF-8') . '</div>';
        $html .= '<button class="message-close">&times;</button>';
        $html .= '</div>';
    }
    
    $html .= '</div>';
    
    // Add CSS
    $html .= '<style>
    /* Message styling */
    .messages-container {
        position: fixed;
        top: 70px; /* Adjust based on your header height */
        left: 0;
        right: 0;
        z-index: 1000;
        display: flex;
        flex-direction: column;
        align-items: center;
        pointer-events: none;
    }

    .message {
        width: 100%;
        max-width: 800px;
        margin-bottom: 10px;
        padding: 12px 20px;
        border-radius: 4px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        animation: slideDown 0.3s ease-out forwards;
        pointer-events: auto;
    }

    .message-content {
        flex-grow: 1;
        font-weight: 500;
    }

    .message-close {
        background: none;
        border: none;
        font-size: 20px;
        cursor: pointer;
        padding: 0;
        margin-left: 10px;
        opacity: 0.7;
        transition: opacity 0.2s;
    }

    .message-close:hover {
        opacity: 1;
    }

    /* Message types */
    .message-success {
        background-color: #d4edda;
        border-left: 4px solid #28a745;
        color: #155724;
    }

    .message-error {
        background-color: #f8d7da;
        border-left: 4px solid #dc3545;
        color: #721c24;
    }

    .message-warning {
        background-color: #fff3cd;
        border-left: 4px solid #ffc107;
        color: #856404;
    }

    .message-info {
        background-color: #d1ecf1;
        border-left: 4px solid #17a2b8;
        color: #0c5460;
    }

    /* Animation for message appearance */
    @keyframes slideDown {
        from {
            transform: translateY(-20px);
            opacity: 0;
        }
        to {
            transform: translateY(0);
            opacity: 1;
        }
    }
    </style>';
    
    // Add JavaScript
    $html .= '<script>
    // Flash message handling
    document.addEventListener("DOMContentLoaded", function() {
        // Get all flash messages
        const flashMessages = document.querySelectorAll(".message");
        
        // Auto-dismiss messages after 5 seconds
        flashMessages.forEach(message => {
            // Set timeout to automatically remove the message
            setTimeout(() => {
                fadeOutAndRemove(message);
            }, 5000);
            
            // Add click event to close button
            const closeBtn = message.querySelector(".message-close");
            if (closeBtn) {
                closeBtn.addEventListener("click", () => {
                    fadeOutAndRemove(message);
                });
            }
        });
        
        // Function to fade out and remove element
        function fadeOutAndRemove(element) {
            element.style.opacity = "1";
            
            // Create fade out animation
            (function fade() {
                if ((element.style.opacity -= 0.1) < 0) {
                    element.remove();
                } else {
                    requestAnimationFrame(fade);
                }
            })();
        }
    });
    </script>';
    
    return $html;
}

/**
 * Redirect with a message
 * This function stores a message and redirects to another page
 *
 * @param string $url URL to redirect to
 * @param string $message Message text
 * @param string $type Message type (success, error, warning, info)
 * @return void
 */
function redirect_with_message($url, $message, $type = 'info') {
    // Set the message
    set_message($type, $message);
    
    // Ensure session data is written before redirect
    session_write_close();
    
    // Redirect
    header("Location: $url");
    exit();
}
?>