<?php
// login_tracker.php
function checkAndRecordLogin() {
    // Skip if no user is logged in
    if (!isset($_SESSION['user_id'])) {
        return;
    }
    
    $userId = $_SESSION['user_id'];
    
    // Check if this is a new login session (not previously recorded)
    // or if the session token has changed (indicating a fresh login)
    if (!isset($_SESSION['login_recorded']) || 
        (isset($_SESSION['previous_session_id']) && $_SESSION['previous_session_id'] != session_id())) {
        
        // Record this login
        $ipAddress = $_SERVER['REMOTE_ADDR'] ?? null;
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? null;
        
        dbExecute(
            "INSERT INTO user_logins (user_id, login_time, ip_address, user_agent) VALUES (?, NOW(), ?, ?)",
            [$userId, $ipAddress, $userAgent]
        );
        
        // Mark this session as having recorded a login
        $_SESSION['login_recorded'] = true;
        
        // Store the current session ID to detect new logins
        $_SESSION['previous_session_id'] = session_id();
    }
}

/**
 * Clean up login history records older than specified days
 * @param int $days Number of days to keep login records for
 * @return bool|int Result of the database operation
 */
function cleanupOldLoginHistory($days = 30) {
    return dbExecute(
        "DELETE FROM user_logins WHERE login_time < DATE_SUB(NOW(), INTERVAL ? DAY)",
        [$days]
    );
}