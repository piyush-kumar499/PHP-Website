<?php
/**
 * OTP-related functions for user verification
 */

require_once('PHPMailer/class.phpmailer.php');
require_once('PHPMailer/class.smtp.php');

/**
 * Generate a random 6-digit OTP
 * @return string 6-digit OTP
 */
function generateOTP() {
    return sprintf('%06d', mt_rand(0, 999999));
}

/**
 * Store OTP in the database
 * @param int $userId User ID
 * @param string $otp Generated OTP
 * @param int $expiryMinutes Minutes until OTP expires (default: 15)
 * @return bool True if stored successfully
 */
function storeOTP($userId, $otp, $expiryMinutes = 15) {
    // Calculate expiry time
    $expiryTime = date('Y-m-d H:i:s', time() + ($expiryMinutes * 60));
    
    // Check if user already has an OTP record
    $existingOTP = dbSelectOne("SELECT * FROM user_otps WHERE user_id = ?", [$userId]);
    
    if ($existingOTP) {
        // Update existing record
        return dbExecute(
            "UPDATE user_otps SET otp = ?, expires_at = ? WHERE user_id = ?",
            [$otp, $expiryTime, $userId]
        );
    } else {
        // Create new record
        return dbInsert(
            "INSERT INTO user_otps (user_id, otp, expires_at) VALUES (?, ?, ?)",
            [$userId, $otp, $expiryTime]
        );
    }
}

/**
 * Send OTP email to user using PHPMailer
 * @param string $email Recipient email address
 * @param string $name Recipient name
 * @param string $otp The OTP to send
 * @return bool True if email sent successfully
 */
function sendOTPEmail($email, $name, $otp) {
    global $CONFIG;
    
    $subject = "Email Verification OTP";
    
    $message = "
    <html>
    <head>
        <style>
            body {font-family: Arial, sans-serif; line-height: 1.6; color: #333;}
            .container {max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 5px;}
            .header {background: linear-gradient(to right, #8e2de2, #4a00e0); color: white; padding: 10px; text-align: center; border-radius: 5px 5px 0 0;}
            .content {padding: 20px;}
            .otp-box {font-size: 24px; text-align: center; padding: 10px; background-color: #f5f5f5; letter-spacing: 5px; margin: 20px 0; border-radius: 5px;}
            .footer {text-align: center; font-size: 12px; color: #777; margin-top: 20px;}
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h2>Email Verification</h2>
            </div>
            <div class='content'>
                <p>Hello $name,</p>
                <p>Thank you for registering with our website. To complete your registration, please use the following One-Time Password (OTP):</p>
                <div class='otp-box'>$otp</div>
                <p>This OTP will expire in 15 minutes. If you did not request this verification, please ignore this email.</p>
                <p>Best regards,<br>Your Website Team</p>
            </div>
            <div class='footer'>
                &copy; " . date('Y') . " Your Website. All rights reserved.
            </div>
        </div>
    </body>
    </html>
    ";
    
    try {
        // Create a new PHPMailer instance
        $mail = new PHPMailer();
        
        // Set mailer to use SMTP
        $mail->IsSMTP();
        
        // Set SMTP settings from config
        $mail->Host = $CONFIG['smtp_host'];
        $mail->SMTPAuth = true;
        $mail->Username = $CONFIG['smtp_username'];
        $mail->Password = $CONFIG['smtp_password'];
        $mail->Port = $CONFIG['smtp_port'];
        
        // Enable encryption if configured
        if ($CONFIG['smtp_secure'] == 'tls') {
            $mail->SMTPSecure = 'tls';
        } elseif ($CONFIG['smtp_secure'] == 'ssl') {
            $mail->SMTPSecure = 'ssl';
        }
        
        // Optional debug level (0-4)
        // 0 = no output, 4 = all output
        $mail->SMTPDebug = 0;
        
        // Set who the message is from
        $mail->SetFrom($CONFIG['smtp_from_email'], $CONFIG['smtp_from_name']);
        
        // Set who the message is to
        $mail->AddAddress($email, $name);
        
        // Set email subject and body
        $mail->Subject = $subject;
        $mail->MsgHTML($message);
        $mail->AltBody = "Your verification code is: $otp";
        
        // Send the message
        if ($mail->Send()) {
            return true;
        } else {
            error_log("Email error: " . $mail->ErrorInfo);
            return false;
        }
    } catch (Exception $e) {
        error_log("PHPMailer exception: " . $e->getMessage());
        return false;
    }
}

/**
 * Verify OTP for a user
 * @param int $userId User ID
 * @param string $otp OTP to verify
 * @return bool|string True if valid, error message if invalid
 */
function verifyOTP($userId, $otp) {
    // Check if user registration has expired
    $user = dbSelectOne("SELECT registration_date, email FROM users WHERE id = ? AND email_verified = 0", [$userId]);
    
    if ($user) {
        $registrationTime = strtotime($user['registration_date']);
        $currentTime = time();
        $expiryTimeMinutes = 10; // 10 minutes
        
        if (($currentTime - $registrationTime) > ($expiryTimeMinutes * 60)) {
            // Delete the user
            dbExecute("DELETE FROM users WHERE id = ?", [$userId]);
            dbExecute("DELETE FROM user_otps WHERE user_id = ?", [$userId]);
            
            return "Your registration has expired. Please register again.";
        }
    }
    
    // Get stored OTP info
    $otpInfo = dbSelectOne("SELECT * FROM user_otps WHERE user_id = ?", [$userId]);
    
    if (!$otpInfo) {
        return "No verification code found. Please request a new one.";
    }
    
    // Check if OTP has expired
    $currentTime = date('Y-m-d H:i:s');
    if ($currentTime > $otpInfo['expires_at']) {
        return "Verification code has expired. Please request a new one.";
    }
    
    // Verify OTP
    if ($otpInfo['otp'] !== $otp) {
        return "Invalid verification code. Please try again.";
    }
    
    // Mark user as verified
    dbExecute("UPDATE users SET email_verified = 1 WHERE id = ?", [$userId]);
    
    // Clear OTP after successful verification
    dbExecute("DELETE FROM user_otps WHERE user_id = ?", [$userId]);
    
    return true;
}

/**
 * Request a new OTP for an existing user
 * @param int $userId User ID
 * @return bool|string True if sent successfully, error message if failed
 */
function resendOTP($userId) {
    // Get user info
    $user = dbSelectOne("SELECT * FROM users WHERE id = ?", [$userId]);
    
    if (!$user) {
        return "User not found.";
    }
    
    // Check if registration has expired
    $registrationTime = strtotime($user['registration_date']);
    $currentTime = time();
    $expiryTimeMinutes = 10; // 10 minutes
    
    if (($currentTime - $registrationTime) > ($expiryTimeMinutes * 60)) {
        // Delete the user
        dbExecute("DELETE FROM users WHERE id = ?", [$userId]);
        dbExecute("DELETE FROM user_otps WHERE user_id = ?", [$userId]);
        
        return "Your registration has expired. Please register again.";
    }
    
    // Check if OTP was recently sent
    $otpInfo = dbSelectOne("SELECT * FROM user_otps WHERE user_id = ?", [$userId]);
    
    if ($otpInfo) {
        $lastSentTime = strtotime($otpInfo['created_at']);
        $currentTime = time();
        
        // If OTP was sent less than 1 minute ago
        if (($currentTime - $lastSentTime) < 60) {
            return "Please wait before requesting a new verification code.";
        }
    }
    
    // Generate and store new OTP
    $otp = generateOTP();
    $stored = storeOTP($userId, $otp);
    
    if (!$stored) {
        return "Failed to generate verification code. Please try again later.";
    }
    
    // Send OTP email
    $sent = sendOTPEmail($user['email'], $user['name'], $otp);
    
    if (!$sent) {
        return "Failed to send verification email. Please try again later.";
    }
    
    return true;
}

/**
 * Track and check OTP resend attempts
 * @param int $userId User ID
 * @param string $email User email
 * @param string $ip User IP address
 * @return array Status information with 'allowed' boolean, 'wait_time' in seconds, and 'attempts' count
 */
function checkOTPResendLimit($userId, $email, $ip) {
    // Get current tracking data if exists
    $identifier = $email ?: $ip; // Use email if available, otherwise IP
    $trackingData = dbSelectOne(
        "SELECT * FROM otp_resend_tracking WHERE identifier = ?",
        [$identifier]
    );
    
    $currentTime = time();
    
    if ($trackingData) {
        // Check if the timeout period is still active
        $lastResendTime = strtotime($trackingData['last_resend']);
        $attempts = $trackingData['attempts'];
        
        // Calculate timeout based on attempts
 $timeout = 0;
   if ($attempts == 1) {
          $timeout = 45;
   } else if ($attempts == 2) {
        $timeout = 70; 
   } else if ($attempts == 3) {
            $timeout = 150;
   } else if ($attempts == 4) {
            $timeout = 300;
   } else if ($attempts >= 5) {
            $timeout = 3600;
     }
        
        // Check if the timeout period has passed
        if (($currentTime - $lastResendTime) < $timeout) {
            $waitTime = $timeout - ($currentTime - $lastResendTime);
            return [
                'allowed' => false,
                'wait_time' => $waitTime,
                'attempts' => $attempts,
                'readable_time' => formatTimeRemaining($waitTime)
            ];
        }
        
        // New code: Reset counter to 0 if user reached max attempts and timeout expired
        if ($attempts >= 5) {
            dbExecute(
                "UPDATE otp_resend_tracking SET attempts = 1, last_resend = NOW() WHERE id = ?",
                [$trackingData['id']]
            );
            
            return [
                'allowed' => true,
                'wait_time' => 0,
                'attempts' => 1
            ];
        }
        
        // Update the attempts count and timestamp
        $newAttempts = $attempts + 1;
        dbExecute(
            "UPDATE otp_resend_tracking SET attempts = ?, last_resend = NOW() WHERE id = ?",
            [$newAttempts, $trackingData['id']]
        );
        
        return [
            'allowed' => true,
            'wait_time' => 0,
            'attempts' => $newAttempts
        ];
    } else {
        // First resend attempt, create tracking record
        dbInsert(
            "INSERT INTO otp_resend_tracking (identifier, user_id, attempts, last_resend) VALUES (?, ?, 1, NOW())",
            [$identifier, $userId]
        );
        
        return [
            'allowed' => true,
            'wait_time' => 0,
            'attempts' => 1
        ];
    }
}

/**
 * Reset OTP resend tracking after successful verification
 * @param string $identifier User email or IP
 * @return void 
 */
function resetOTPResendTracking($identifier) {
    dbExecute(
        "DELETE FROM otp_resend_tracking WHERE identifier = ?",
        [$identifier]
    );
}
?>