<!-- Standard favicons -->
<link rel="icon" type="image/x-icon" href="/assets/images/favicon.ico">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/assets/images/favicon-16x16.png">
<!-- Apple Touch Icon -->
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<!-- Android Chrome -->
<link rel="manifest" href="/site.webmanifest">
<!-- For search engines and social media -->
<meta name="theme-color" content="#ffffff">