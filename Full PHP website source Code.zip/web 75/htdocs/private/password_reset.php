<?php
/**
 * Password reset functions
 */

// This is needed for database functions
require_once('../private/db.php'); // Adjust path if needed

// This is needed for PHPMailer
if (!class_exists('PHPMailer')) {
    require_once('../private/phpmailer/PHPMailer.php'); // Adjust path if needed
}

/**
 * Request a password reset for a user
 * @param string $email User's email address
 * @return bool|string True if successful, error message otherwise
 */
function requestPasswordReset($email) {
    // Clean up expired tokens first
    cleanupExpiredResetTokens();
    
    // Check if email exists
    $user = dbSelectOne("SELECT * FROM users WHERE email = ?", [$email]);
    
    if (!$user) {
        // Don't reveal if email exists or not for security
        return true;
    }
    
    // Generate a unique token
    $token = bin2hex(random_bytes(32));
    $expires = date('Y-m-d H:i:s', time() + (15 * 60)); // 15 minutes from now
    
    // Store the token in the database
    $exists = dbSelectOne("SELECT * FROM password_resets WHERE user_id = ?", [$user['id']]);
    
    if ($exists) {
        // Update existing token
        $updated = dbExecute(
            "UPDATE password_resets SET token = ?, expires_at = ? WHERE user_id = ?",
            [$token, $expires, $user['id']]
        );
    } else {
        // Create new token
        $updated = dbInsert(
            "INSERT INTO password_resets (user_id, token, expires_at) VALUES (?, ?, ?)",
            [$user['id'], $token, $expires]
        );
    }
    
    if (!$updated) {
        return "Failed to generate reset token. Please try again later.";
    }
    
    // Send the reset email
    $sent = sendPasswordResetEmail($user['email'], $user['name'], $token);
    
    if (!$sent) {
        return "Failed to send reset email. Please try again later.";
    }
    
    return true;
}

/**
 * Send password reset email
 * @param string $email Recipient email address
 * @param string $name Recipient name
 * @param string $token Reset token
 * @return bool True if email sent successfully
 */
function sendPasswordResetEmail($email, $name, $token) {
    global $CONFIG;
    
    $resetLink = $CONFIG['site_url'] . '/reset-password?token=' . $token;
    $subject = $CONFIG['site_name'] . ": Password Reset Request";
    
    // Generate unsubscribe link with user's email encoded
    $unsubscribeEmail = urlencode($email);
    $unsubscribeLink = $CONFIG['site_url'] . '/preferences/email?email=' . $unsubscribeEmail . '&action=unsubscribe&type=security';
    
    // Plain text version - important for spam prevention
    $plainText = "Hello $name,

We received a request to reset your password for your account at " . $CONFIG['site_name'] . ". If you did not make this request, you can ignore this email.

To reset your password, please visit this link:
$resetLink

This link will expire in 15 minutes.

Best regards,
" . $CONFIG['site_name'] . " Team

---
This is an automated message. Please do not reply to this email.
" . $CONFIG['site_url'] . "
" . $CONFIG['company_address'] . "

To unsubscribe from these notifications: $unsubscribeLink
";

    // HTML version with responsive design
    $message = "
    <!DOCTYPE html>
    <html lang=\"en\">
    <head>
        <meta charset=\"UTF-8\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
        <title>Password Reset</title>
    </head>
    <body style=\"font-family: Arial, sans-serif; line-height: 1.6; color: #333; background-color: #f9f9f9; margin: 0; padding: 0;\">
        <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"max-width: 600px; margin: 20px auto; background-color: #ffffff; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);\">
            <tr>
                <td style=\"padding: 20px; text-align: center; background-color: #4a00e0; border-radius: 8px 8px 0 0;\">
                    <h2 style=\"color: white; margin: 0;\">" . htmlspecialchars($CONFIG['site_name']) . " - Password Reset</h2>
                </td>
            </tr>
            <tr>
                <td style=\"padding: 30px;\">
                    <p>Hello " . htmlspecialchars($name) . ",</p>
                    <p>We received a request to reset the password for your account. If you did not make this request, you can safely ignore this email.</p>
                    <p>To reset your password, please click the button below:</p>
                    <p style=\"text-align: center; margin: 25px 0;\">
                        <a href=\"" . htmlspecialchars($resetLink) . "\" style=\"display: inline-block; background-color: #4a00e0; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; font-weight: bold;\">Reset Password</a>
                    </p>
                    <p>Or copy and paste this link into your browser:</p>
                    <p style=\"background-color: #f9f9f9; padding: 10px; border-radius: 4px; word-break: break-all;\">
                        <a href=\"" . htmlspecialchars($resetLink) . "\" style=\"color: #4a00e0; text-decoration: none;\">" . htmlspecialchars($resetLink) . "</a>
                    </p>
                    <p>This link will expire in 15 minutes for security reasons.</p>
                    <p>
                        Best regards,<br>
                        " . htmlspecialchars($CONFIG['site_name']) . " Team
                    </p>
                </td>
            </tr>
            <tr>
                <td style=\"padding: 20px; text-align: center; font-size: 12px; color: #777; background-color: #f9f9f9; border-radius: 0 0 8px 8px;\">
                    <p>&copy; " . date('Y') . " " . htmlspecialchars($CONFIG['site_name']) . ". All rights reserved.</p>
                    <p>" . htmlspecialchars($CONFIG['company_address']) . "</p>
                    <p>This is an automated message. Please do not reply to this email.</p>
                    <p><a href=\"" . htmlspecialchars($unsubscribeLink) . "\" style=\"color: #777; text-decoration: underline;\">Manage email preferences</a></p>
                </td>
            </tr>
        </table>
        <!-- Adding List-Unsubscribe header support in the HTML part -->
        <div style=\"display:none;\">
            <a href=\"" . htmlspecialchars($unsubscribeLink) . "\">Unsubscribe</a>
        </div>
    </body>
    </html>
    ";
    
    try {
        // Create a new PHPMailer instance
        $mail = new PHPMailer(true); // true enables exceptions
        
        // Set mailer to use SMTP
        $mail->isSMTP();
        
        // Set SMTP settings from config
        $mail->Host = $CONFIG['smtp_host'];
        $mail->SMTPAuth = true;
        $mail->Username = $CONFIG['smtp_username'];
        $mail->Password = $CONFIG['smtp_password'];
        $mail->Port = $CONFIG['smtp_port'];
        
        // Enable encryption if configured
        if ($CONFIG['smtp_secure'] == 'tls') {
            $mail->SMTPSecure = 'tls';
        } elseif ($CONFIG['smtp_secure'] == 'ssl') {
            $mail->SMTPSecure = 'ssl';
        }
        
        // Optional debug level (0-4) - set to 2 for troubleshooting, then back to 0
        $mail->SMTPDebug = 0;
        
        // Set email character set
        $mail->CharSet = 'UTF-8';
        
        // Set who the message is from - use consistent from address
        $mail->setFrom($CONFIG['smtp_from_email'], $CONFIG['smtp_from_name']);
        
        // Set Reply-To address
        $mail->addReplyTo($CONFIG['support_email'] ?? $CONFIG['smtp_from_email'], 
                          $CONFIG['support_name'] ?? $CONFIG['smtp_from_name']);
        
        // Set who the message is to
        $mail->addAddress($email, $name);
        
        // Set email priority (1 = High, 3 = Normal, 5 = Low)
        $mail->Priority = 3;
        
        // Add List-Unsubscribe header - this is important for deliverability
        $mail->addCustomHeader('List-Unsubscribe', '<' . $unsubscribeLink . '>, <mailto:' . $CONFIG['support_email'] . '?subject=Unsubscribe&body=Please%20unsubscribe%20me%20from%20all%20emails>');
        $mail->addCustomHeader('List-Unsubscribe-Post', 'List-Unsubscribe=One-Click');
        
        // Set email subject
        $mail->Subject = $subject;
        
        // Set both HTML and plain text versions
        $mail->isHTML(true);
        $mail->Body = $message;
        $mail->AltBody = $plainText;
        
        // Add a Message ID header
        $mail->MessageID = '<' . time() . rand(10000, 99999) . '@' . parse_url($CONFIG['site_url'], PHP_URL_HOST) . '>';
        
        // Send the message
        if ($mail->send()) {
            return true;
        } else {
            error_log("Email error: " . $mail->ErrorInfo);
            return false;
        }
    } catch (Exception $e) {
        error_log("PHPMailer exception: " . $e->getMessage());
        return false;
    }
}

/**
 * Verify password reset token
 * @param string $token Reset token
 * @return bool|array False if invalid, user data if valid
 */
function verifyPasswordResetToken($token) {
    // Clean up expired tokens first
    cleanupExpiredResetTokens();
    
    // Get token info
    $resetInfo = dbSelectOne(
        "SELECT r.*, u.id as user_id, u.name, u.email 
         FROM password_resets r 
         JOIN users u ON r.user_id = u.id 
         WHERE r.token = ?", 
        [$token]
    );
    
    if (!$resetInfo) {
        return false;
    }
    
    // Check if token has expired
    $currentTime = date('Y-m-d H:i:s');
    if ($currentTime > $resetInfo['expires_at']) {
        // Remove this specific expired token
        dbExecute("DELETE FROM password_resets WHERE token = ?", [$token]);
        return false;
    }
    
    return [
        'user_id' => $resetInfo['user_id'],
        'name' => $resetInfo['name'],
        'email' => $resetInfo['email']
    ];
}

/**
 * Clean up expired password reset tokens
 * @return void
 */
function cleanupExpiredResetTokens() {
    $currentTime = date('Y-m-d H:i:s');
    dbExecute("DELETE FROM password_resets WHERE expires_at < ?", [$currentTime]);
}

/**
 * Reset user's password using token
 * @param string $token Reset token
 * @param string $newPassword New password
 * @return bool|string True if successful, error message if failed
 */
function resetPassword($token, $newPassword) {
    // Verify token
    $userData = verifyPasswordResetToken($token);
    
    if (!$userData) {
        return "Invalid or expired reset link. Please request a new one.";
    }
    
    // Hash the new password
    $passwordHash = password_hash($newPassword, PASSWORD_DEFAULT);
    
    // Update the user's password
    $updated = dbExecute(
        "UPDATE users SET password = ? WHERE id = ?",
        [$passwordHash, $userData['user_id']]
    );
    
    if (!$updated) {
        return "Failed to update password. Please try again.";
    }
    
    // Delete the used token
    dbExecute("DELETE FROM password_resets WHERE user_id = ?", [$userData['user_id']]);
    
    return true;
}