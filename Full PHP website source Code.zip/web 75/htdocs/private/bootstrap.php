<?php
/**
 * Application Bootstrap File
 * 
 * This file serves as the central initialization point for the application
 * and handles including all necessary configuration and library files.
 */

// Define the application root path
if (!defined('APP_ROOT')) {
    define('APP_ROOT', dirname(__DIR__));
}

// Use APP_ROOT to include files with absolute paths
require_once APP_ROOT . '/private/config.php';  
require_once APP_ROOT . '/private/db.php';
require_once APP_ROOT . '/private/auth.php';

// Other application-wide initialization can go here
// ...