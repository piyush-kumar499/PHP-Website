<?php
/**
 * Authentication functions
 */

require_once('../private/email_otp.php');
require_once('password_reset.php');

/**
 * Register a new user
 * @param string $name User's full name
 * @param string $email User's email address
 * @param string $password User's password
 * @return bool|string|array True on success, error message on failure, or user data with OTP status
 */
function registerUser($name, $email, $password) {
    // Check if email already exists
    $existingUser = dbSelectOne("SELECT * FROM users WHERE email = ?", [$email]);
    
    if ($existingUser) {
        return "Email address is already registered. Please use a different email or login.";
    }
    
    // Hash the password
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    
    // Generate registration date
    $registrationDate = date('Y-m-d H:i:s');
    
    // Insert the new user
    $userId = dbInsert(
        "INSERT INTO users (name, email, password, registration_date, last_login, email_verified) VALUES (?, ?, ?, ?, ?, 0)",
        [$name, $email, $passwordHash, $registrationDate, $registrationDate]
    );
    
    if (!$userId) {
        return "Registration failed. Please try again later.";
    }
    
    // Set temporary session variables
    $_SESSION['temp_user_id'] = $userId;
    $_SESSION['temp_user_name'] = $name;
    $_SESSION['temp_user_email'] = $email;
    $_SESSION['needs_verification'] = true;
    
    // Return user data for OTP verification
    return [
        'user_id' => $userId,
        'user_name' => $name,
        'user_email' => $email,
        'requires_verification' => true
    ];
}

/**
 * Request OTP for email verification
 * @param int $userId User ID or null to use session data
 * @return bool|array Success status and any relevant messages
 */
function requestVerificationOTP($userId = null) {
    // If userId not provided, try to get from session
    if ($userId === null) {
        if (isset($_SESSION['temp_user_id'])) {
            $userId = $_SESSION['temp_user_id'];
        } elseif (isset($_SESSION['pending_verification_email'])) {
            // Get user ID by email
            $user = dbSelectOne("SELECT id, name, email FROM users WHERE email = ? AND email_verified = 0", 
                [$_SESSION['pending_verification_email']]);
            
            if ($user) {
                $userId = $user['id'];
                $_SESSION['temp_user_id'] = $userId;
                $_SESSION['temp_user_name'] = $user['name'];
                $_SESSION['temp_user_email'] = $user['email'];
            } else {
                return [
                    'success' => false,
                    'message' => 'Invalid verification request.'
                ];
            }
        } else {
            return [
                'success' => false,
                'message' => 'No user identified for verification.'
            ];
        }
    }
    
    // Get user data
    $user = dbSelectOne("SELECT name, email FROM users WHERE id = ?", [$userId]);
    
    if (!$user) {
        return [
            'success' => false,
            'message' => 'User not found.'
        ];
    }
    
    // Generate and store OTP
    $otp = generateOTP();
    $stored = storeOTP($userId, $otp);
    
    if (!$stored) {
        return [
            'success' => false,
            'message' => 'Could not generate verification code. Please try again.'
        ];
    }
    
    // Send OTP email
    $sent = sendOTPEmail($user['email'], $user['name'], $otp);
    
    if (!$sent) {
        return [
            'success' => false,
            'message' => 'Could not send verification email. Please try again.'
        ];
    }
    
    return [
        'success' => true,
        'message' => 'Verification code sent to your email.',
        'user_email' => $user['email']
    ];
}

/**
 * Complete user registration after OTP verification
 * @param int $userId User ID
 * @return void
 */
function completeRegistration($userId) {
    // Update user as verified
    dbExecute("UPDATE users SET email_verified = 1 WHERE id = ?", [$userId]);
    
    // Clear temporary session data
    unset($_SESSION['temp_user_id']);
    unset($_SESSION['temp_user_name']);
    unset($_SESSION['temp_user_email']);
    unset($_SESSION['needs_verification']);
    unset($_SESSION['pending_verification_email']);
    
    // Get user data
    $user = dbSelectOne("SELECT * FROM users WHERE id = ?", [$userId]);
    
    if (!$user) {
        return;
    }
    
    // Set session variables for logged in user
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['logged_in'] = true;
}

/**
 * Check if a user is blocked due to too many failed login attempts
 * @param string $email User's email address
 * @param string $ip User's IP address
 * @return array Status information with 'blocked' boolean and 'time_remaining' in seconds
 */
function checkLoginBlock($email, $ip) {
    // First, check based on email address
    $emailBlockData = dbSelectOne(
        "SELECT * FROM login_attempts WHERE identifier = ? AND type = 'email' AND is_blocked = 1",
        [$email]
    );
    
    if ($emailBlockData) {
        $blockTime = strtotime($emailBlockData['block_expires']);
        $currentTime = time();
        
        if ($blockTime > $currentTime) {
            $timeRemaining = $blockTime - $currentTime;
            return [
                'blocked' => true,
                'time_remaining' => $timeRemaining,
                'readable_time' => formatTimeRemaining($timeRemaining)
            ];
        } else {
            // Block has expired, update the database
            dbExecute(
                "UPDATE login_attempts SET is_blocked = 0, attempt_count = 0 WHERE id = ?",
                [$emailBlockData['id']]
            );
        }
    }
    
    // Then, check based on IP address
    $ipBlockData = dbSelectOne(
        "SELECT * FROM login_attempts WHERE identifier = ? AND type = 'ip' AND is_blocked = 1",
        [$ip]
    );
    
    if ($ipBlockData) {
        $blockTime = strtotime($ipBlockData['block_expires']);
        $currentTime = time();
        
        if ($blockTime > $currentTime) {
            $timeRemaining = $blockTime - $currentTime;
            return [
                'blocked' => true,
                'time_remaining' => $timeRemaining,
                'readable_time' => formatTimeRemaining($timeRemaining)
            ];
        } else {
            // Block has expired, update the database
            dbExecute(
                "UPDATE login_attempts SET is_blocked = 0, attempt_count = 0 WHERE id = ?",
                [$ipBlockData['id']]
            );
        }
    }
    
    // No active blocks found
    return ['blocked' => false, 'time_remaining' => 0];
}

/**
 * Format time remaining in a human-readable format
 * @param int $seconds Time remaining in seconds
 * @return string Formatted time string
 */
function formatTimeRemaining($seconds) {
    $hours = floor($seconds / 3600);
    $minutes = floor(($seconds % 3600) / 60);
    $secs = $seconds % 60;
    
    if ($hours > 0) {
        return sprintf("%d hour%s %d minute%s", 
            $hours, ($hours == 1) ? '' : 's',
            $minutes, ($minutes == 1) ? '' : 's'
        );
    } elseif ($minutes > 0) {
        return sprintf("%d minute%s %d second%s", 
            $minutes, ($minutes == 1) ? '' : 's',
            $secs, ($secs == 1) ? '' : 's'
        );
    } else {
        return sprintf("%d second%s", $secs, ($secs == 1) ? '' : 's');
    }
}

/**
 * Record a failed login attempt
 * @param string $email User's email address
 * @param string $ip User's IP address
 * @return void
 */
function recordFailedLoginAttempt($email, $ip) {
    // Record for email
    $emailAttempt = dbSelectOne(
        "SELECT * FROM login_attempts WHERE identifier = ? AND type = 'email'",
        [$email]
    );
    
    if ($emailAttempt) {
        $newCount = $emailAttempt['attempt_count'] + 1;
        $isBlocked = ($newCount >= 5) ? 1 : 0;
        $blockExpires = null;
        
        if ($isBlocked) {
            $blockExpires = date('Y-m-d H:i:s', time() + (2 * 60 * 60)); // 2 hours from now
        }
        
        dbExecute(
            "UPDATE login_attempts SET attempt_count = ?, last_attempt = NOW(), is_blocked = ?, block_expires = ? WHERE id = ?",
            [$newCount, $isBlocked, $blockExpires, $emailAttempt['id']]
        );
    } else {
        dbInsert(
            "INSERT INTO login_attempts (identifier, type, attempt_count, last_attempt, is_blocked) VALUES (?, 'email', 1, NOW(), 0)",
            [$email]
        );
    }
    
    // Record for IP
    $ipAttempt = dbSelectOne(
        "SELECT * FROM login_attempts WHERE identifier = ? AND type = 'ip'",
        [$ip]
    );
    
    if ($ipAttempt) {
        $newCount = $ipAttempt['attempt_count'] + 1;
        $isBlocked = ($newCount >= 5) ? 1 : 0;
        $blockExpires = null;
        
        if ($isBlocked) {
            $blockExpires = date('Y-m-d H:i:s', time() + (2 * 60 * 60)); // 2 hours from now
        }
        
        dbExecute(
            "UPDATE login_attempts SET attempt_count = ?, last_attempt = NOW(), is_blocked = ?, block_expires = ? WHERE id = ?",
            [$newCount, $isBlocked, $blockExpires, $ipAttempt['id']]
        );
    } else {
        dbInsert(
            "INSERT INTO login_attempts (identifier, type, attempt_count, last_attempt, is_blocked) VALUES (?, 'ip', 1, NOW(), 0)",
            [$ip]
        );
    }
}

/**
 * Reset login attempts counter after successful login
 * @param string $email User's email address
 * @param string $ip User's IP address
 * @return void
 */
function resetLoginAttempts($email, $ip) {
    dbExecute(
        "UPDATE login_attempts SET attempt_count = 0, is_blocked = 0, block_expires = NULL WHERE identifier = ? AND type = 'email'",
        [$email]
    );
    
    dbExecute(
        "UPDATE login_attempts SET attempt_count = 0, is_blocked = 0, block_expires = NULL WHERE identifier = ? AND type = 'ip'",
        [$ip]
    );
}

/**
 * Login a user
 * @param string $email User's email address
 * @param string $password User's password
 * @param string $ip User's IP address
 * @return bool|string|array True on success, error message on failure, or block info if blocked
 */
function loginUser($email, $password, $ip) {
    // Check if user is blocked
    $blockStatus = checkLoginBlock($email, $ip);
    if ($blockStatus['blocked']) {
        return [
            'blocked' => true,
            'time_remaining' => $blockStatus['time_remaining'],
            'readable_time' => $blockStatus['readable_time']
        ];
    }
    
    // Check and delete expired unverified users
    $isDeleted = deleteExpiredUnverifiedUser($email);
    if ($isDeleted) {
        return "Your registration has expired. Please register again.";
    }

    // Get user by email
    $user = dbSelectOne("SELECT * FROM users WHERE email = ?", [$email]);
    
    if (!$user) {
        recordFailedLoginAttempt($email, $ip);
        return "Invalid email or password.";
    }
    
    // Verify password
    if (!password_verify($password, $user['password'])) {
        recordFailedLoginAttempt($email, $ip);
        return "Invalid email or password.";
    }
    
    // Reset login attempts on successful login
    resetLoginAttempts($email, $ip);
    
    // Check if email is verified
    if (!$user['email_verified']) {
        // Store temp session data for verification
        $_SESSION['temp_user_id'] = $user['id'];
        $_SESSION['temp_user_name'] = $user['name'];
        $_SESSION['temp_user_email'] = $user['email'];
        $_SESSION['pending_verification_email'] = $user['email'];
        
        // Return verification required status - this will trigger the popup
        return [
            'requires_verification' => true,
            'user_id' => $user['id'],
            'message' => "Email verification required."
        ];
    }
    
    // Update last login timestamp
    $currentTime = date('Y-m-d H:i:s');
    dbExecute("UPDATE users SET last_login = ? WHERE id = ?", [$currentTime, $user['id']]);
    
    // Set session variables
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['logged_in'] = true;
    
    return true;
}

/**
 * Logout the current user
 */
function logoutUser() {
    // Unset all session variables
    $_SESSION = [];
    
    // Destroy the session
    session_destroy();
    
    // Delete the session cookie
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params["path"],
            $params["domain"],
            $params["secure"],
            $params["httponly"]
        );
    }
}

/**
 * Check if a user is logged in
 * @return bool True if user is logged in, false otherwise
 */
function isLoggedIn() {
    return isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;
}

/**
 * Check if a user is in OTP verification mode
 * @return bool True if user is in OTP verification mode
 */
function isInVerificationMode() {
    return isset($_SESSION['temp_user_id']) && !empty($_SESSION['temp_user_id']);
}

/**
 * Get temporary user data during verification
 * @return array|null Temporary user data or null if not in verification
 */
function getVerificationUser() {
    if (!isInVerificationMode()) {
        return null;
    }
    
    return [
        'id' => $_SESSION['temp_user_id'],
        'name' => $_SESSION['temp_user_name'],
        'email' => $_SESSION['temp_user_email']
    ];
}

/**
 * Get current user data
 * @return array|null User data array or null if not logged in
 */
function getCurrentUser() {
    if (!isLoggedIn()) {
        return null;
    }
    
    return [
        'id' => $_SESSION['user_id'],
        'name' => $_SESSION['user_name'],
        'email' => $_SESSION['user_email']
    ];
}

/**
 * Require user to be logged in, redirect to login page if not
 */
function requireLogin() {
    if (!isLoggedIn()) {
        header("Location: login.php");
        exit();
    }
}

/**
 * Verify CSRF token
 * @param string $token The token from the form
 * @return bool True if token is valid, false otherwise
 */
function verifyCSRFToken($token) {
    if (!isset($_SESSION['csrf_token'])) {
        error_log("CSRF token missing in session.");
        return false;
    }
    
    if (!hash_equals($_SESSION['csrf_token'], $token)) {
        error_log("CSRF token mismatch. Expected: " . $_SESSION['csrf_token'] . " Received: " . $token);
        return false;
    }
    
    return true;
}

/**
 * Generate a CSRF token and store it in the session if it doesn't exist
 * @return string The generated or existing token
 */
function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) { // Generate only if not set
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify user's password
 * 
 * @param int $userId User ID
 * @param string $password Plain text password to verify
 * @return bool True if password is correct, false otherwise
 */
function verifyPassword($userId, $password) {
    // Get the user's stored password hash from database
    $user = dbSelectOne("SELECT password FROM users WHERE id = ?", [$userId]);
    
    if (!$user) {
        return false;
    }
    
    // Verify the password against the stored hash
    return password_verify($password, $user['password']);
}

/**
 * Check and delete unverified users who registered more than 10 minutes ago
 * @param string $email User's email (optional)
 * @return boolean True if user was deleted, false otherwise
 */
function deleteExpiredUnverifiedUser($email = null) {
    $expiryTimeMinutes = 10; // 10 minutes expiry time
    
    if ($email !== null) {
        // Check specific user
        $user = dbSelectOne(
            "SELECT id, registration_date FROM users WHERE email = ? AND email_verified = 0",
            [$email]
        );
        
        if ($user) {
            $registrationTime = strtotime($user['registration_date']);
            $currentTime = time();
            
            if (($currentTime - $registrationTime) > ($expiryTimeMinutes * 60)) {
                // User registration has expired, delete the user
                dbExecute("DELETE FROM users WHERE id = ?", [$user['id']]);
                
                // Also delete any OTP records
                dbExecute("DELETE FROM user_otps WHERE user_id = ?", [$user['id']]);
                
                return true;
            }
        }
    } else {
        // Batch cleanup of all expired unverified users
        $expiryTimestamp = date('Y-m-d H:i:s', time() - ($expiryTimeMinutes * 60));
        
        // Get expired user IDs first
        $expiredUsers = dbSelect(
            "SELECT id FROM users WHERE email_verified = 0 AND registration_date < ?",
            [$expiryTimestamp]
        );
        
        if ($expiredUsers) {
            foreach ($expiredUsers as $user) {
                // Delete OTP records for each expired user
                dbExecute("DELETE FROM user_otps WHERE user_id = ?", [$user['id']]);
            }
            
            // Then delete all expired users in one query
            dbExecute(
                "DELETE FROM users WHERE email_verified = 0 AND registration_date < ?",
                [$expiryTimestamp]
            );
            
            return true;
        }
    }
    
    return false;
}